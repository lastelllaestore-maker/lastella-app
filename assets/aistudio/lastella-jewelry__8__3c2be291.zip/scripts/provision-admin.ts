import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import config from '../firebase-applet-config.json' with { type: 'json' };

const app = initializeApp(config);
const auth = getAuth(app);
const db = getFirestore(app, config.firestoreDatabaseId);

/**
 * LASTELLA Jewellery Administrator Role Provisioning Script
 * 
 * Safely provisions an administrator account by creating an authoritative role document
 * in `/admins/{uid}` and validating custom claims.
 * 
 * Usage:
 *   npx tsx scripts/provision-admin.ts <adminEmail> <adminPassword>
 * 
 * Example:
 *   npx tsx scripts/provision-admin.ts lastelllaestore@gmail.com yourAdminPassword
 */
async function provisionAdmin() {
  const email = process.argv[2] || 'lastelllaestore@gmail.com';
  const password = process.argv[3];

  if (!password) {
    console.error('Error: Please provide the admin password as the second argument:');
    console.error('  npx tsx scripts/provision-admin.ts lastelllaestore@gmail.com <password>');
    process.exit(1);
  }

  console.log(`Authenticating as administrator candidate: ${email}...`);
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    const uid = cred.user.uid;
    console.log(`Authenticated with Firebase Auth! User UID: ${uid}`);

    // Create role document in /admins/{uid}
    const adminDocRef = doc(db, 'admins', uid);
    const existing = await getDoc(adminDocRef);

    if (existing.exists() && existing.data()?.role === 'admin') {
      console.log(`✅ Administrator role document already exists for UID: ${uid}`);
    } else {
      await setDoc(adminDocRef, {
        uid,
        email,
        role: 'admin',
        provisionedAt: new Date().toISOString(),
        note: 'Authorized LASTELLA Store Administrator',
      });
      console.log(`✅ Successfully provisioned /admins/${uid} document in Cloud Firestore!`);
    }

    console.log('\n======================================================');
    console.log('🎉 Admin Migration Completed Successfully!');
    console.log(`Administrator UID: ${uid}`);
    console.log(`Role Document: /admins/${uid}`);
    console.log('Rules Access: exists(/databases/$(database)/documents/admins/$(request.auth.uid)) -> GRANTED');
    console.log('======================================================');
  } catch (err: any) {
    console.error('Failed to provision admin:', err?.message || err);
    process.exit(1);
  }
}

provisionAdmin().catch(console.error);
