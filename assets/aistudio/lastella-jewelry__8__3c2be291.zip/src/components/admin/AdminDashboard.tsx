import React, { useState, useEffect, useRef } from 'react';
import { useStore, AdminSubTab } from '../../context/StoreContext';
import { Product, ProductCategory, ProductVariant, Order, OrderStatus, StoreSettings } from '../../types';
import { firebaseService } from '../../services/firebaseService';
import { uploadProductImageToCloudinary, getOptimizedImageUrl } from '../../services/cloudinaryService';
import { getCategoryTranslation } from '../../i18n/translations';
import {
  translateProductNameToArabic,
  translateSizeToArabic,
  translateColorToArabic,
} from '../../services/translationService';
import { filterWarrantyFeatures } from '../../utils/warrantySanitizer';
import {
  ShieldCheck,
  Plus,
  Edit,
  Trash2,
  Package,
  ShoppingBag,
  Sliders,
  CheckCircle,
  MessageCircle,
  Truck,
  Image as ImageIcon,
  Save,
  X,
  Sparkles,
  Search,
  Lock,
  LogOut,
  KeyRound,
  Eye,
  EyeOff,
  ArrowRight,
  TrendingUp,
  MapPin,
  Phone,
  Calendar,
  Clock,
  ChevronDown,
  Filter,
  Minus,
  Check,
  Store,
  AlertTriangle,
  Upload,
  Loader2,
  Mail,
  Landmark,
  CheckCircle2,
  Languages,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    products,
    refreshProducts,
    adminOrders: orders,
    refreshOrders,
    settings,
    updateSettings,
    refreshSettings,
    formatOMR,
    setCurrentTab,
    showToast,
    isAdminAuthenticated,
    adminUser,
    loginAdminWithCredentials,
    loginAdmin,
    changeAdminPassword,
    logoutAdmin,
    setIsAdminLoginOpen,
    adminSubTab,
    setAdminSubTab,
    isAddProductModalOpen,
    setIsAddProductModalOpen,
    language,
    isFirestoreQuotaExceeded,
    firestoreUpgradeUrl,
  } = useStore();

  const isAr = language === 'ar';

  // Inline Lock Screen State
  const [inlineAuthMode, setInlineAuthMode] = useState<'credentials' | 'passcode'>('credentials');
  const [inlineEmail, setInlineEmail] = useState('lastelllaestore@gmail.com');
  const [inlinePassword, setInlinePassword] = useState('');
  const [inlinePasscode, setInlinePasscode] = useState('');
  const [inlineShowPasscode, setInlineShowPasscode] = useState(false);
  const [inlineError, setInlineError] = useState('');
  const [inlineLoading, setInlineLoading] = useState(false);

  // Product Form State (Add / Edit)
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const [formName, setFormName] = useState('');
  const [formArabicName, setFormArabicName] = useState('');
  const [isArabicManuallyEdited, setIsArabicManuallyEdited] = useState(false);
  const [isTranslatingArabic, setIsTranslatingArabic] = useState(false);
  const translationTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const [formCategory, setFormCategory] = useState<ProductCategory>('Necklaces');
  const [formPrice, setFormPrice] = useState('1.100');
  const [formOriginalPrice, setFormOriginalPrice] = useState('');
  const [formImages, setFormImages] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formInStock, setFormInStock] = useState(true);
  const [formIsBestSeller, setFormIsBestSeller] = useState(false);
  const [formIsNewArrival, setFormIsNewArrival] = useState(false);
  const [formRingSizes, setFormRingSizes] = useState('');
  
  // Dynamic Product Variants (+ Add Variant System)
  const [formVariants, setFormVariants] = useState<{
    id: string;
    sizeEn: string;
    sizeAr: string;
    colorEn: string;
    colorAr: string;
    available: boolean;
    sizeArManual?: boolean;
    colorArManual?: boolean;
  }[]>([]);
  const [formCareNote, setFormCareNote] = useState('');

  const handleAddVariant = () => {
    const newVariant = {
      id: `var_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      sizeEn: '',
      sizeAr: '',
      colorEn: '',
      colorAr: '',
      available: true,
      sizeArManual: false,
      colorArManual: false,
    };
    setFormVariants((prev) => [...prev, newVariant]);
  };

  const handleUpdateVariant = (
    id: string,
    field: 'sizeEn' | 'sizeAr' | 'colorEn' | 'colorAr' | 'available',
    val: any
  ) => {
    setFormVariants((prev) =>
      prev.map((v) => {
        if (v.id !== id) return v;

        if (field === 'sizeEn') {
          const newSizeEn = String(val);
          const autoAr = !v.sizeArManual ? translateSizeToArabic(newSizeEn) : v.sizeAr;
          return {
            ...v,
            sizeEn: newSizeEn,
            sizeAr: autoAr,
          };
        }

        if (field === 'sizeAr') {
          return {
            ...v,
            sizeAr: String(val),
            sizeArManual: true,
          };
        }

        if (field === 'colorEn') {
          const newColorEn = String(val);
          const autoAr = !v.colorArManual ? translateColorToArabic(newColorEn) : v.colorAr;
          return {
            ...v,
            colorEn: newColorEn,
            colorAr: autoAr,
          };
        }

        if (field === 'colorAr') {
          return {
            ...v,
            colorAr: String(val),
            colorArManual: true,
          };
        }

        if (field === 'available') {
          return {
            ...v,
            available: Boolean(val),
          };
        }

        return v;
      })
    );
  };

  const handleDeleteVariant = (id: string) => {
    setFormVariants((prev) => prev.filter((v) => v.id !== id));
  };

  const handleRegenerateVariantField = (id: string, field: 'size' | 'color') => {
    setFormVariants((prev) =>
      prev.map((v) => {
        if (v.id !== id) return v;
        if (field === 'size') {
          return {
            ...v,
            sizeAr: translateSizeToArabic(v.sizeEn),
            sizeArManual: false,
          };
        }
        if (field === 'color') {
          return {
            ...v,
            colorAr: translateColorToArabic(v.colorEn),
            colorArManual: false,
          };
        }
        return v;
      })
    );
  };

  const createEmptyProductDraft = () => {
    setEditingProduct(null);
    setFormName('');
    setFormArabicName('');
    setIsArabicManuallyEdited(false);
    setIsTranslatingArabic(false);
    if (translationTimeoutRef.current) {
      clearTimeout(translationTimeoutRef.current);
    }
    setFormCategory('Necklaces');
    setFormPrice('1.100');
    setFormOriginalPrice('');
    setFormImages('');
    setFormDescription('');
    setFormInStock(true);
    setFormIsBestSeller(false);
    setFormIsNewArrival(false);
    setFormRingSizes('');
    setFormVariants([]);
    setFormCareNote('');
    setCloudinaryStatus('ready');
    setCloudinaryError(null);
    setUploadProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [cloudinaryStatus, setCloudinaryStatus] = useState<'ready' | 'uploading' | 'success' | 'error'>('ready');
  const [cloudinaryError, setCloudinaryError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate JPG, JPEG, PNG, WebP
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const isImage = file.type && validTypes.includes(file.type.toLowerCase());
    const hasValidExt = /\.(jpe?g|png|webp)$/i.test(file.name || '');

    if (!isImage && !hasValidExt) {
      showToast(isAr ? 'يرجى اختيار ملف صورة صالح (JPG, JPEG, PNG, WebP).' : 'Please select a valid image file (JPG, JPEG, PNG, WebP).');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Admin authorization check: Must be authenticated store administrator
    if (!isAdminAuthenticated) {
      showToast(
        isAr
          ? 'يتطلب رفع الصور تسجيل الدخول كمدير معتمد للمتجر...'
          : 'Image upload requires authenticated store admin...'
      );
      setIsAdminLoginOpen(true);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsUploadingImage(true);
    setCloudinaryStatus('uploading');
    setCloudinaryError(null);
    setUploadProgress(10);

    try {
      // Direct Cloudinary upload with real-time progress
      const secureUrl = await uploadProductImageToCloudinary(file, (pct) => {
        setUploadProgress(pct);
      });

      if (!secureUrl || typeof secureUrl !== 'string' || !secureUrl.startsWith('https://')) {
        throw new Error('Cloudinary returned an invalid or empty HTTPS URL');
      }

      // Append clean HTTPS secure_url to product images (one per line)
      setFormImages((prev) => {
        const trimmed = prev.trim();
        return trimmed ? `${secureUrl}\n${trimmed}` : secureUrl;
      });

      setUploadProgress(100);
      setCloudinaryStatus('success');
      showToast(isAr ? 'تم رفع الصورة بنجاح عبر Cloudinary ✓' : 'Image uploaded ✓');

      // Reset badge state to ready after 4s
      setTimeout(() => {
        setCloudinaryStatus('ready');
      }, 4000);
    } catch (err) {
      console.error('[Cloudinary Upload Error]:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      setCloudinaryStatus('error');
      setCloudinaryError(errMsg);
      setUploadProgress(null);
      showToast(isAr ? `فشل رفع الصورة: ${errMsg}` : `Upload failed: ${errMsg}`);
    } finally {
      setIsUploadingImage(false);
      setTimeout(() => setUploadProgress(null), 1500);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Order status filter & search
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('All');
  const [searchOrderQuery, setSearchOrderQuery] = useState('');

  // Product search & category filter
  const [searchProductQuery, setSearchProductQuery] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('All');

  // Store Settings Form
  const [settingPhone, setSettingPhone] = useState(settings.storePhone || '');
  const [settingWa, setSettingWa] = useState(settings.whatsappNumber || '');
  const [settingAnnouncement, setSettingAnnouncement] = useState(settings.announcementText || '');
  const [settingHomePrice, setSettingHomePrice] = useState(
    (settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2.0).toString()
  );
  const [settingOfficePrice, setSettingOfficePrice] = useState(
    (settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1.0).toString()
  );
  // Bank Transfer Configuration
  const [settingBankName, setSettingBankName] = useState(settings.bankName || 'Bank Muscat');
  const [settingAccountName, setSettingAccountName] = useState(settings.accountName || 'LASTELLA JEWELRY');
  const [settingAccountNumber, setSettingAccountNumber] = useState(settings.accountNumber || '');
  const [settingBankIban, setSettingBankIban] = useState(settings.bankIban || '');
  const [settingBankInstructions, setSettingBankInstructions] = useState(
    settings.bankTransferInstructions ||
      'Please transfer the exact order amount to our bank account. Include your Order Number in the remarks.'
  );
  const [settingBankInstructionsAr, setSettingBankInstructionsAr] = useState(
    settings.bankTransferInstructionsAr ||
      'يرجى تحويل مبلغ الطلب بدقة إلى الحساب البنكي، مع كتابة رقم الطلب في خانة الملاحظات/الوصف عند التحويل.'
  );

  // Security Credentials Form
  const [currentPasscode, setCurrentPasscode] = useState('');
  const [newPasscode, setNewPasscode] = useState('');
  const [confirmPasscode, setConfirmPasscode] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Keep settings form inputs synchronized with latest settings state
  useEffect(() => {
    setSettingPhone(settings.storePhone || '');
    setSettingWa(settings.whatsappNumber || '');
    setSettingAnnouncement(settings.announcementText || '');
    setSettingHomePrice((settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2.0).toString());
    setSettingOfficePrice((settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1.0).toString());
    setSettingBankName(settings.bankName || 'Bank Muscat');
    setSettingAccountName(settings.accountName || 'LASTELLA JEWELRY');
    setSettingAccountNumber(settings.accountNumber || '');
    setSettingBankIban(settings.bankIban || '');
    setSettingBankInstructions(
      settings.bankTransferInstructions ||
        'Please transfer the exact order amount to our bank account. Include your Order Number in the remarks.'
    );
    setSettingBankInstructionsAr(
      settings.bankTransferInstructionsAr ||
        'يرجى تحويل مبلغ الطلب بدقة إلى الحساب البنكي، مع كتابة رقم الطلب في خانة الملاحظات/الوصف عند التحويل.'
    );
  }, [settings]);

  // Sync with global isAddProductModalOpen trigger
  useEffect(() => {
    if (isAddProductModalOpen) {
      handleOpenAddProduct();
      setIsAddProductModalOpen(false);
    }
  }, [isAddProductModalOpen]);

  // Metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const activeOrdersCount = orders.filter(
    (o) => o.status !== 'Delivered' && o.status !== 'Cancelled'
  ).length;

  const handleOpenAddProduct = () => {
    createEmptyProductDraft();
    setIsProductModalOpen(true);
  };

  const handleCloseProductModal = () => {
    setIsProductModalOpen(false);
    createEmptyProductDraft();
  };

  const handleOpenEditProduct = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name || '');
    setFormArabicName(p.arabicName || '');
    setIsArabicManuallyEdited(true); // Preserve existing Arabic name, don't auto-overwrite
    setIsTranslatingArabic(false);
    if (translationTimeoutRef.current) {
      clearTimeout(translationTimeoutRef.current);
    }
    setFormCategory(p.category || 'Necklaces');
    // Requirement 2: Do not overwrite prices when editing existing products
    setFormPrice(p.price !== undefined && p.price !== null ? p.price.toString() : '1.100');
    setFormOriginalPrice(p.originalPrice !== undefined && p.originalPrice !== null ? p.originalPrice.toString() : '');
    setFormImages(p.images && p.images.length > 0 ? p.images.join('\n') : '');
    setFormDescription(p.description || '');
    // Requirement 4: Available for Sale checkbox (true unless explicitly false)
    setFormInStock(p.inStock !== false);
    setFormIsBestSeller(!!p.isBestSeller);
    setFormIsNewArrival(!!p.isNewArrival);
    setFormRingSizes(p.sizes ? p.sizes.join(', ') : '');
    
    // Migrate or load variants
    if (p.variants && p.variants.length > 0) {
      setFormVariants(
        p.variants.map((v) => ({
          id: v.id || `var_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          sizeEn: v.sizeEn || '',
          sizeAr: v.sizeAr || (v.sizeEn ? translateSizeToArabic(v.sizeEn) : ''),
          colorEn: v.colorEn || '',
          colorAr: v.colorAr || (v.colorEn ? translateColorToArabic(v.colorEn) : ''),
          available: v.available !== false,
          sizeArManual: true,
          colorArManual: true,
        }))
      );
    } else if ((p.sizes && p.sizes.length > 0) || (p.colors && p.colors.length > 0)) {
      // Migrate legacy sizes and colors into editable variant items
      const legacyVariants: {
        id: string;
        sizeEn: string;
        sizeAr: string;
        colorEn: string;
        colorAr: string;
        available: boolean;
        sizeArManual?: boolean;
        colorArManual?: boolean;
      }[] = [];
      const sizes = p.sizes && p.sizes.length > 0 ? p.sizes.map(String) : [''];
      const colors = p.colors && p.colors.length > 0 ? p.colors : [''];

      sizes.forEach((sz) => {
        colors.forEach((clr) => {
          if (!sz && !clr) return;
          legacyVariants.push({
            id: `var_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            sizeEn: sz,
            sizeAr: sz ? translateSizeToArabic(sz) : '',
            colorEn: clr,
            colorAr: clr ? translateColorToArabic(clr) : '',
            available: p.inStock !== false,
            sizeArManual: false,
            colorArManual: false,
          });
        });
      });
      setFormVariants(legacyVariants);
    } else {
      setFormVariants([]);
    }
    setFormCareNote(p.careInstructions || '');
    setCloudinaryStatus('ready');
    setCloudinaryError(null);
    setUploadProgress(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setIsProductModalOpen(true);
  };

  // Requirement 1: Debounced automatic Arabic product name translation
  const handleEnglishNameChange = (val: string) => {
    setFormName(val);

    // If user hasn't manually edited the Arabic name, auto-translate with debounce
    if (!isArabicManuallyEdited) {
      if (translationTimeoutRef.current) {
        clearTimeout(translationTimeoutRef.current);
      }

      const trimmed = val.trim();
      if (!trimmed) {
        setFormArabicName('');
        setIsTranslatingArabic(false);
        return;
      }

      setIsTranslatingArabic(true);
      translationTimeoutRef.current = setTimeout(async () => {
        try {
          const ar = await translateProductNameToArabic(trimmed);
          if (!isArabicManuallyEdited && ar) {
            setFormArabicName(ar);
          }
        } catch (err) {
          console.warn('[AdminDashboard] Auto-translation fallback:', err);
        } finally {
          setIsTranslatingArabic(false);
        }
      }, 500);
    }
  };

  const handleArabicNameChange = (val: string) => {
    setIsArabicManuallyEdited(true);
    setFormArabicName(val);
  };

  const handleManualReTranslate = async () => {
    const trimmed = formName.trim();
    if (!trimmed) return;
    setIsTranslatingArabic(true);
    try {
      const ar = await translateProductNameToArabic(trimmed);
      if (ar) {
        setFormArabicName(ar);
        setIsArabicManuallyEdited(false);
      }
    } catch (err) {
      console.warn('[AdminDashboard] Manual re-translate error:', err);
    } finally {
      setIsTranslatingArabic(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const imageList = formImages
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    // Validate duplicate variants (Requirement 4)
    const seenCombos = new Set<string>();
    for (const v of formVariants) {
      const s = (v.sizeEn || '').trim().toLowerCase();
      const c = (v.colorEn || '').trim().toLowerCase();
      if (s || c) {
        const comboKey = `${s}__${c}`;
        if (seenCombos.has(comboKey)) {
          showToast(
            isAr
              ? `تنبيه: يوجد خيار مكرر للمقاس واللون (${v.sizeEn || ''} - ${v.colorEn || ''})`
              : `Warning: Duplicate variant combination (${v.sizeEn || ''} - ${v.colorEn || ''})`
          );
          return;
        }
        seenCombos.add(comboKey);
      }
    }

    // Clean variants: filter out completely blank entries (neither size nor color)
    const cleanedVariants: ProductVariant[] = formVariants
      .map((v) => ({
        id: v.id,
        sizeEn: v.sizeEn.trim() || undefined,
        sizeAr: v.sizeAr.trim() || (v.sizeEn.trim() ? translateSizeToArabic(v.sizeEn.trim()) : undefined),
        colorEn: v.colorEn.trim() || undefined,
        colorAr: v.colorAr.trim() || (v.colorEn.trim() ? translateColorToArabic(v.colorEn.trim()) : undefined),
        available: v.available,
      }))
      .filter((v) => v.sizeEn || v.colorEn);

    // Derived legacy fields for backward compatibility
    const derivedSizes = Array.from(new Set(cleanedVariants.filter((v) => v.sizeEn).map((v) => v.sizeEn!)));
    const derivedColors = Array.from(new Set(cleanedVariants.filter((v) => v.colorEn).map((v) => v.colorEn!)));

    // Requirement 2: Store price as numeric value 1.1, not string "1.100"
    const parsedPrice = parseFloat(formPrice);
    const finalPrice = !isNaN(parsedPrice) && parsedPrice >= 0 ? parsedPrice : 1.1;

    // Requirement 4: Availability checkbox controls inStock.
    // Preserve existing stockCount if available, or 999 if new; 0 if out of stock
    const existingStock = editingProduct?.stockCount;
    const finalStockCount = formInStock 
      ? (existingStock !== undefined && existingStock > 0 ? existingStock : 999) 
      : 0;

    const productPayload = {
      name: formName.trim(),
      // Requirement 1: Save actual translated Arabic name in existing Firestore product document
      arabicName: formArabicName.trim(),
      category: formCategory,
      price: finalPrice,
      originalPrice: formOriginalPrice ? parseFloat(formOriginalPrice) : undefined,
      images: imageList,
      description: formDescription.trim(),
      features: editingProduct?.features
        ? filterWarrantyFeatures(editingProduct.features)
        : [
            'Everyday Wear',
            'Color Resistant',
            'Water Resistant',
            'Hypoallergenic',
          ],
      variants: cleanedVariants.length > 0 ? cleanedVariants : undefined,
      sizes: derivedSizes.length > 0 ? derivedSizes : undefined,
      colors: derivedColors.length > 0 ? derivedColors : undefined,
      // Requirement 3: Remove material field from form, but preserve existing material property if present
      materials: editingProduct?.materials || undefined,
      isBestSeller: formIsBestSeller,
      isNewArrival: formIsNewArrival,
      inStock: formInStock,
      stockCount: finalStockCount,
      rating: editingProduct ? editingProduct.rating : 5.0,
      reviewCount: editingProduct ? editingProduct.reviewCount : 1,
      careInstructions: formCareNote.trim(),
      sku: editingProduct ? editingProduct.sku : `LST-${Math.floor(100 + Math.random() * 900)}`,
    };

    try {
      if (editingProduct) {
        await firebaseService.updateProduct({
          ...editingProduct,
          ...productPayload,
        });
        showToast(isAr ? 'تم تحديث بيانات المنتج بنجاح في قاعدة البيانات! ✨' : 'Product updated in Firestore! ✨');
      } else {
        await firebaseService.addProduct(productPayload);
        showToast(isAr ? 'تمت إضافة القطعة الجديدة لكتالوج لاستيلا! 💎' : 'New product added to LASTELLA Firestore! 💎');
      }
      handleCloseProductModal();
    } catch (err: any) {
      console.error('[AdminDashboard] Save product error:', err);
      showToast(isAr ? `فشل حفظ المنتج: ${err?.message || 'خطأ'}` : `Failed to save product: ${err?.message || 'Error'}`);
    }
  };

  const confirmDeleteProduct = async () => {
    if (productToDelete) {
      try {
        await firebaseService.deleteProduct(productToDelete.id);
        showToast(isAr ? 'تم حذف القطعة من الكتالوج نهائياً.' : 'Product deleted from Firestore.');
        setProductToDelete(null);
      } catch (err: any) {
        console.error('[AdminDashboard] Delete product error:', err);
        showToast(isAr ? `فشل حذف المنتج: ${err?.message || 'خطأ'}` : `Failed to delete product: ${err?.message || 'Error'}`);
      }
    }
  };

  // Requirement 4: 1-Tap Availability Toggle for fast inventory management
  const handleToggleAvailability = async (product: Product) => {
    const nextInStock = product.inStock === false;
    const nextStockCount = nextInStock ? (product.stockCount && product.stockCount > 0 ? product.stockCount : 999) : 0;
    try {
      await firebaseService.updateProduct({
        ...product,
        inStock: nextInStock,
        stockCount: nextStockCount,
      });
      showToast(
        isAr
          ? `${product.arabicName || product.name}: تم تغيير الحالة إلى (${nextInStock ? 'متوفر للبيع' : 'غير متوفر'})`
          : `${product.name}: ${nextInStock ? 'marked Available for Sale' : 'marked Out of Stock'}`
      );
    } catch (err: any) {
      showToast(`Availability update failed: ${err?.message || 'Error'}`);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await firebaseService.updateOrderStatus(orderId, newStatus);
      showToast(isAr ? `تم تحديث حالة الطلب إلى: ${newStatus}` : `Order status updated to: ${newStatus}`);
    } catch (err: any) {
      showToast(`Order status update failed: ${err?.message || 'Error'}`);
    }
  };

  const handleUpdatePaymentStatus = async (
    orderId: string,
    newPaymentStatus: 'Pending Payment' | 'Paid' | 'Payment Verified' | 'Refunded'
  ) => {
    try {
      await firebaseService.updateOrderPaymentStatus(orderId, newPaymentStatus);
      showToast(
        isAr
          ? `تم تحديث حالة الدفع إلى: ${newPaymentStatus === 'Payment Verified' ? 'تم التحقق من الدفع' : newPaymentStatus}`
          : `Payment status updated to: ${newPaymentStatus}`
      );
    } catch (err: any) {
      showToast(`Payment status update failed: ${err?.message || 'Error'}`);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedHome = parseFloat(settingHomePrice);
    const parsedOffice = parseFloat(settingOfficePrice);

    // 1. If admin is updating their Firebase Authentication password/passcode
    if (newPasscode.trim()) {
      if (newPasscode.trim().length < 6) {
        showToast(
          isAr
            ? 'يجب أن تتكون كلمة المرور الجديدة من 6 أحرف أو أرقام على الأقل.'
            : 'New password must be at least 6 characters long.'
        );
        return;
      }
      if (newPasscode.trim() !== confirmPasscode.trim()) {
        showToast(
          isAr
            ? 'كلمتا المرور غير متطابقتين. يرجى التأكد وإعادة المحاولة.'
            : 'New passwords do not match. Please verify.'
        );
        return;
      }
      if (!currentPasscode.trim()) {
        showToast(
          isAr
            ? 'يرجى إدخال كلمة المرور الحالية لتأكيد هويتك وتحديث بيانات الدخول.'
            : 'Current password is required to verify identity and update credentials.'
        );
        return;
      }

      setIsChangingPassword(true);
      try {
        const res = await changeAdminPassword(currentPasscode.trim(), newPasscode.trim());
        if (!res.success) {
          showToast(`Password update failed: ${res.error}`);
          setIsChangingPassword(false);
          return;
        }
        setCurrentPasscode('');
        setNewPasscode('');
        setConfirmPasscode('');
        showToast(
          isAr
            ? 'تم تحديث كلمة المرور في خوادم Firebase بنجاح ✓ تم إلغاء الرمز القديم!'
            : 'Admin credentials updated in Firebase Auth ✓ Old passcode revoked!'
        );
      } catch (err: any) {
        showToast(`Failed to update password: ${err?.message || 'Error'}`);
        setIsChangingPassword(false);
        return;
      } finally {
        setIsChangingPassword(false);
      }
    }

    // 2. Save store configuration & bank transfer credentials to Firestore
    const cleanWa = settingWa.replace(/[^0-9]/g, '');
    const updatedSettings: StoreSettings = {
      ...settings,
      storePhone: settingPhone.trim(),
      whatsappNumber: cleanWa || settings.whatsappNumber,
      displayWhatsApp: settingPhone.trim() || (cleanWa ? `+${cleanWa}` : settings.displayWhatsApp),
      announcementText: settingAnnouncement.trim(),
      homeDeliveryPrice: !isNaN(parsedHome) ? Math.max(0, parsedHome) : 2.0,
      officeDeliveryPrice: !isNaN(parsedOffice) ? Math.max(0, parsedOffice) : 1.0,
      bankName: settingBankName.trim() || 'Bank Muscat',
      accountName: settingAccountName.trim() || 'LASTELLA JEWELRY',
      accountNumber: settingAccountNumber.trim(),
      bankIban: settingBankIban.trim(),
      bankTransferInstructions: settingBankInstructions.trim(),
      bankTransferInstructionsAr: settingBankInstructionsAr.trim(),
    };

    try {
      await updateSettings(updatedSettings);
      showToast(
        isAr
          ? 'تم حفظ إعدادات المتجر وبيانات الحساب البنكي في السحابة بنجاح! ⚙️'
          : 'Store settings & Bank transfer details saved to Firestore! ⚙️'
      );
    } catch (err: any) {
      showToast(`Settings save failed: ${err?.message || 'Error'}`);
    }
  };

  const filteredOrders = orders.filter((o) => {
    if (!o) return false;
    const matchesStatus = orderStatusFilter === 'All' || o.status === orderStatusFilter;
    const query = (searchOrderQuery || '').trim().toLowerCase();
    const matchesSearch =
      !query ||
      (o.orderNumber && o.orderNumber.toLowerCase().includes(query)) ||
      (o.customer?.name && o.customer.name.toLowerCase().includes(query)) ||
      (o.customer?.phone && o.customer.phone.includes(searchOrderQuery));
    return matchesStatus && matchesSearch;
  });

  const filteredProducts = products.filter((p) => {
    if (!p) return false;
    const matchesCategory =
      productCategoryFilter === 'All'
        ? true
        : productCategoryFilter === 'New Arrivals'
        ? !!p.isNewArrival
        : productCategoryFilter === 'Best Selling'
        ? !!p.isBestSeller
        : p.category === productCategoryFilter;
    const query = (searchProductQuery || '').trim().toLowerCase();
    const matchesSearch =
      !query ||
      (p.name && p.name.toLowerCase().includes(query)) ||
      (p.arabicName && p.arabicName.toLowerCase().includes(query)) ||
      (p.sku && p.sku.toLowerCase().includes(query));
    return matchesCategory && matchesSearch;
  });

  // If user is not authenticated as admin, show secure lock screen
  if (!isAdminAuthenticated) {
    const handleCredentialsSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setInlineError('');

      const cleanEmail = inlineEmail.trim().toLowerCase();
      if (!cleanEmail) {
        setInlineError(isAr ? 'الرجاء إدخال البريد الإلكتروني للمدير' : 'Please enter manager email');
        return;
      }

      if (!inlinePassword) {
        setInlineError(isAr ? 'الرجاء إدخال كلمة المرور' : 'Please enter password');
        return;
      }

      setInlineLoading(true);
      try {
        const res = await loginAdminWithCredentials(cleanEmail, inlinePassword);
        if (!res.success) {
          setInlineError(res.error || (isAr ? 'تم رفض الوصول: بيانات الدخول غير صحيحة' : 'Access Denied: Invalid credentials'));
        } else {
          setInlineError('');
          setInlinePassword('');
        }
      } catch (err: any) {
        setInlineError(err?.message || (isAr ? 'تم رفض الوصول' : 'Access Denied'));
      } finally {
        setInlineLoading(false);
      }
    };

    const handlePasscodeSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setInlineError('');
      if (!inlinePasscode.trim()) {
        setInlineError(isAr ? 'الرجاء إدخال رمز المرور السري للمدير' : 'Please enter manager passcode');
        return;
      }
      setInlineLoading(true);
      try {
        const res = await loginAdmin(inlinePasscode);
        if (!res.success) {
          setInlineError(res.error || (isAr ? 'رمز المرور غير صحيح. تم رفض الوصول.' : 'Incorrect passcode. Access Denied.'));
        } else {
          setInlinePasscode('');
          setInlineError('');
        }
      } catch (err: any) {
        setInlineError(err?.message || (isAr ? 'رمز المرور غير صحيح' : 'Access Denied'));
      } finally {
        setInlineLoading(false);
      }
    };

    return (
      <div
        className="min-h-[70vh] flex items-center justify-center py-6 px-4 animate-in fade-in duration-200"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        <div className="bg-white max-w-md w-full rounded-3xl p-5 sm:p-8 border border-[#FCE4EC] shadow-xl text-center space-y-5">
          <div className="w-16 h-16 rounded-3xl bg-[#FFF0F4] border border-[#FCE4EC] mx-auto flex items-center justify-center text-[#832F47] shadow-xs">
            <Lock className="w-8 h-8 text-[#832F47]" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059] font-bold">
              {isAr ? 'منطقة محمية ومخصصة للإدارة' : 'RESTRICTED ACCESS'}
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-1">
              {isAr ? 'بوابة إدارة بوتيك لاستيلا' : 'Admin & Staff Portal'}
            </h2>
            <p className="text-xs text-stone-500 mt-1.5 leading-relaxed">
              {isAr
                ? 'تحتوي لوحة التحكم على بيانات طلبات الزبائن، كتالوج المجوهرات، والأسعار. يرجى تسجيل الدخول كمدير معتمد للمتابعة.'
                : 'This dashboard contains private store orders, customer contact information, and catalog management. Please sign in as authorized manager to proceed.'}
            </p>
          </div>

          {/* Mode Switcher */}
          <div className="p-1 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl flex gap-1">
            <button
              type="button"
              onClick={() => {
                setInlineAuthMode('credentials');
                setInlineError('');
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                inlineAuthMode === 'credentials'
                  ? 'bg-white text-[#832F47] shadow-xs border border-[#FCE4EC]'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{isAr ? 'البريد وكلمة المرور' : 'Email & Password'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setInlineAuthMode('passcode');
                setInlineError('');
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                inlineAuthMode === 'passcode'
                  ? 'bg-white text-[#832F47] shadow-xs border border-[#FCE4EC]'
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isAr ? 'رمز المرور PIN' : 'Passcode PIN'}</span>
            </button>
          </div>

          {inlineAuthMode === 'credentials' ? (
            <form onSubmit={handleCredentialsSubmit} className="space-y-4 text-start">
              <div>
                <label className="block text-xs font-semibold text-[#3B252E] mb-1.5 flex items-center justify-between">
                  <span>{isAr ? 'البريد الإلكتروني المعتمد' : 'Authorized Admin Email'}</span>
                  <span className="text-[10px] text-emerald-700 font-normal">
                    lastelllaestore@gmail.com
                  </span>
                </label>
                <div className="relative">
                  <Mail
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type="email"
                    required
                    value={inlineEmail}
                    onChange={(e) => {
                      setInlineEmail(e.target.value);
                      if (inlineError) setInlineError('');
                    }}
                    placeholder="lastelllaestore@gmail.com"
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-3' : 'pl-10 pr-3'
                    } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#3B252E] mb-1.5">
                  {isAr ? 'كلمة المرور' : 'Password'}
                </label>
                <div className="relative">
                  <Lock
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type={inlineShowPasscode ? 'text' : 'password'}
                    required
                    value={inlinePassword}
                    onChange={(e) => {
                      setInlinePassword(e.target.value);
                      if (inlineError) setInlineError('');
                    }}
                    placeholder={isAr ? 'أدخل كلمة المرور...' : 'Enter password...'}
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => setInlineShowPasscode(!inlineShowPasscode)}
                    className={`absolute ${
                      isAr ? 'left-3.5' : 'right-3.5'
                    } top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer`}
                  >
                    {inlineShowPasscode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {inlineError && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5">
                  <span>⚠️</span>
                  <span>{inlineError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={inlineLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-semibold text-xs tracking-wider uppercase shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 min-h-[44px]"
              >
                {inlineLoading ? (
                  <span>{isAr ? 'جاري التحقق...' : 'Verifying...'}</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isAr ? 'تسجيل دخول الإدارة' : 'Admin Sign In'}</span>
                    <ArrowRight className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setCurrentTab('home')}
                className="w-full py-2.5 text-xs text-stone-500 hover:text-[#832F47] font-medium transition-colors text-center block cursor-pointer"
              >
                {isAr ? '← العودة إلى متجر المجوهرات' : '← Return to Customer Boutique'}
              </button>
            </form>
          ) : (
            <form onSubmit={handlePasscodeSubmit} className="space-y-4 text-start">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-[#3B252E]">
                    {isAr ? 'رمز مرور المدير (PIN)' : 'Manager Passcode'}
                  </label>
                </div>
                <div className="relative">
                  <KeyRound
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type={inlineShowPasscode ? 'text' : 'password'}
                    required
                    autoFocus
                    value={inlinePasscode}
                    onChange={(e) => {
                      setInlinePasscode(e.target.value);
                      if (inlineError) setInlineError('');
                    }}
                    placeholder={isAr ? 'أدخل رمز مرور المدير...' : 'Enter manager passcode...'}
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } py-3 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => setInlineShowPasscode(!inlineShowPasscode)}
                    className={`absolute ${
                      isAr ? 'left-3.5' : 'right-3.5'
                    } top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer`}
                  >
                    {inlineShowPasscode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {inlineError && (
                  <p className="text-[11px] text-rose-600 font-medium mt-1.5 flex items-center gap-1">
                    <span>⚠️</span> {inlineError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={inlineLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-semibold text-xs tracking-wider uppercase shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 min-h-[44px]"
              >
                {inlineLoading ? (
                  <span>{isAr ? 'جاري التحقق...' : 'Verifying...'}</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isAr ? 'فتح بوابة الإدارة' : 'Unlock Management Portal'}</span>
                    <ArrowRight className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setCurrentTab('home')}
                className="w-full py-2.5 text-xs text-stone-500 hover:text-[#832F47] font-medium transition-colors text-center block cursor-pointer"
              >
                {isAr ? '← العودة إلى متجر المجوهرات' : '← Return to Customer Boutique'}
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className="space-y-3 sm:space-y-5 pb-28 animate-in fade-in duration-200 max-w-5xl mx-auto px-1 sm:px-4"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* ========================================================= */}
      {/* 1. CANONICAL HEADER (DESKTOP & MOBILE RESPONSIVE)         */}
      {/* ========================================================= */}
      <div className="bg-gradient-to-r from-[#832F47] via-[#6F263B] to-[#5B2333] text-white rounded-3xl p-3 sm:p-5 border border-[#E57390]/30 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-[#C5A059]/25 text-[#FDE8EE] flex items-center justify-center border border-[#C5A059]/40 shrink-0">
            <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-[#C5A059]" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="font-serif text-base sm:text-xl font-bold tracking-wide text-white truncate">
                {isAr ? 'لوحة تحكم وإدارة لاستيلا' : 'LASTELLA Admin'}
              </h1>
              <span className="text-[10px] bg-[#C5A059] text-white font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full shadow-2xs">
                {isAr ? 'لوحة الإدارة الموحدة' : 'ADMIN PANEL'}
              </span>
              {adminUser ? (
                <span className="text-[10px] bg-emerald-500/25 text-emerald-200 border border-emerald-400/40 font-semibold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span>✓</span>
                  <span className="truncate max-w-[150px]">{adminUser.email || 'lastelllaestore@gmail.com'}</span>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsAdminLoginOpen(true)}
                  className="text-[10px] bg-white/20 hover:bg-white/30 active:scale-95 text-white font-semibold px-2.5 py-0.5 rounded-full border border-white/30 transition-all cursor-pointer flex items-center gap-1"
                >
                  <span>🔐</span>
                  <span>{isAr ? 'تسجيل دخول الإدارة' : 'Admin Login'}</span>
                </button>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-white/85 truncate">
              {isAr
                ? 'الكتالوج المباشر، تعديل المنتجات، وطلبات سلطنة عُمان'
                : 'Live Storefront Catalog, Product Editing & Oman Orders'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 pt-1 sm:pt-0 border-t sm:border-t-0 border-white/10 shrink-0">
          {/* Back to Storefront */}
          <button
            type="button"
            id="btn-admin-back-storefront"
            onClick={() => setCurrentTab('home')}
            className="flex-1 sm:flex-initial px-4 py-2.5 bg-white/15 hover:bg-white/25 active:bg-white/30 border border-white/25 text-white rounded-full text-xs font-semibold tracking-wider transition-all text-center min-h-[40px] flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
            title={isAr ? 'العودة إلى متجر المجوهرات' : 'Back to Storefront'}
          >
            <Store className="w-3.5 h-3.5" />
            <span>{isAr ? '← العودة للمتجر' : '← Back to Storefront'}</span>
          </button>

          {/* Lock / Logout */}
          <button
            type="button"
            id="btn-admin-lock-logout"
            onClick={logoutAdmin}
            className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#FDE7ED] text-[#832F47] hover:bg-white active:bg-white/90 rounded-full text-xs font-bold tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-xs min-h-[40px] cursor-pointer active:scale-95"
            title={isAr ? 'قفل جلسة الإدارة' : 'Lock / Logout Admin'}
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isAr ? 'قفل / خروج' : 'Lock / Logout'}</span>
          </button>
        </div>
      </div>

      {/* Quota Exceeded Admin Alert */}
      {isFirestoreQuotaExceeded && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3 sm:p-4 text-amber-900 text-xs sm:text-sm space-y-2">
          <div className="flex items-center gap-2 font-bold text-amber-800">
            <span className="text-base">⚠️</span>
            <span>{isAr ? 'تنبيه: تم استنفاد حصة القراءة اليومية لقاعدة بيانات فايربيس (Quota Exceeded)' : 'Notice: Daily Firestore Free Tier Read Quota Exceeded'}</span>
          </div>
          <p className="text-amber-800/90 text-xs leading-relaxed">
            {isAr
              ? 'وصل مشروع فايربيس إلى الحد الأقصى للقراءات اليومية في الخطة المجانية (Spark Free Tier). يعمل المتجر حالياً ببيانات التخزين المحلي المؤقتة لمنع توقف التطبيق. ستتم إعادة ضبط الحصة اليومية تلقائياً مع بداية اليوم الجديد، أو يمكنك ترقية الخطة من لوحة تحكم Firebase.'
              : 'The Firebase project has reached its free tier daily read limit. The boutique is currently running on local cached data. Firebase resets the quota automatically at midnight Pacific Time, or you can upgrade to Blaze plan in Firebase Console.'}
          </p>
          <a
            href={firestoreUpgradeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
          >
            <span>{isAr ? 'فتح ترقية الحصة في Firebase Console' : 'Open Firebase Upgrade Dialog'}</span>
            <span>↗</span>
          </a>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. DASHBOARD METRICS (COMPACT 2-COL ON MOBILE, 4-COL LG)  */}
      {/* ========================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3.5">
        {/* Metric 1: Total Revenue */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-[#FCE4EC] shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[9px] sm:text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider truncate">
              {isAr ? 'إجمالي المبيعات' : 'Total Revenue'}
            </span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          </div>
          <p className="font-serif font-bold text-sm sm:text-xl text-[#832F47] my-1 truncate">
            {formatOMR(totalRevenue)}
          </p>
          <span className="text-[9px] sm:text-[10px] text-stone-500 font-medium truncate">
            {isAr ? 'مبيعات سلطنة عُمان' : 'Live Oman Orders'}
          </span>
        </div>

        {/* Metric 2: Total Orders */}
        <button
          type="button"
          id="metric-total-orders"
          onClick={() => setAdminSubTab('orders')}
          className={`bg-white rounded-2xl p-3 sm:p-4 border transition-all text-start flex flex-col justify-between cursor-pointer group active:scale-98 ${
            adminSubTab === 'orders'
              ? 'border-[#E57390] ring-2 ring-[#FFF0F4] shadow-xs'
              : 'border-[#FCE4EC] hover:border-[#E57390]'
          }`}
        >
          <div className="flex items-center justify-between w-full">
            <span className="text-[9px] sm:text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider truncate">
              {isAr ? 'إجمالي الطلبات' : 'Total Orders'}
            </span>
            <span className="text-[9px] sm:text-[10px] text-[#832F47] font-semibold underline group-hover:text-[#E57390] shrink-0">
              {isAr ? 'عرض' : 'View'}
            </span>
          </div>
          <p className="font-serif font-bold text-sm sm:text-xl text-[#3B252E] my-1">
            {orders.length}
          </p>
          <span className="text-[9px] sm:text-[10px] text-stone-400 font-normal truncate">
            {isAr ? 'إدارة الطلبات' : 'Manage orders'}
          </span>
        </button>

        {/* Metric 3: Active Dispatch */}
        <button
          type="button"
          id="metric-active-dispatch"
          onClick={() => {
            setAdminSubTab('orders');
            setOrderStatusFilter('Preparing');
          }}
          className={`bg-white rounded-2xl p-3 sm:p-4 border transition-all text-start flex flex-col justify-between cursor-pointer group active:scale-98 ${
            adminSubTab === 'orders' && orderStatusFilter === 'Preparing'
              ? 'border-[#E57390] ring-2 ring-[#FFF0F4] shadow-xs'
              : 'border-[#FCE4EC] hover:border-[#E57390]'
          }`}
        >
          <div className="flex items-center justify-between w-full">
            <span className="text-[9px] sm:text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider truncate">
              {isAr ? 'قيد التجهيز' : 'Active Dispatch'}
            </span>
            <span className="text-[9px] sm:text-[10px] text-[#C5A059] font-semibold shrink-0">
              {isAr ? 'تجهيز' : 'Active'}
            </span>
          </div>
          <p className="font-serif font-bold text-sm sm:text-xl text-[#832F47] my-1">
            {activeOrdersCount}
          </p>
          <span className="text-[9px] sm:text-[10px] text-[#C5A059] font-medium flex items-center gap-1 truncate">
            <Truck className="w-3 h-3 shrink-0" />
            {isAr ? 'قيد التغليف والتوصيل' : 'In Transit'}
          </span>
        </button>

        {/* Metric 4: Total Products */}
        <button
          type="button"
          id="metric-total-products"
          onClick={() => setAdminSubTab('products')}
          className={`bg-white rounded-2xl p-3 sm:p-4 border transition-all text-start flex flex-col justify-between cursor-pointer group active:scale-98 ${
            adminSubTab === 'products'
              ? 'border-[#E57390] ring-2 ring-[#FFF0F4] shadow-xs'
              : 'border-[#FCE4EC] hover:border-[#E57390]'
          }`}
        >
          <div className="flex items-center justify-between w-full">
            <span className="text-[9px] sm:text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider truncate">
              {isAr ? 'إجمالي المنتجات' : 'Total Products'}
            </span>
            <span className="text-[9px] sm:text-[10px] text-[#E57390] font-bold underline shrink-0">
              {isAr ? 'تعديل' : 'Edit'}
            </span>
          </div>
          <p className="font-serif font-bold text-sm sm:text-xl text-[#3B252E] my-1">
            {products.length}
          </p>
          <span className="text-[9px] sm:text-[10px] text-emerald-600 font-medium truncate">
            {isAr ? 'إدارة الكتالوج والمخزون' : 'Manage catalog'}
          </span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* 3. ADMIN NAVIGATION (ORDERS, PRODUCTS, ADD, SETTINGS)      */}
      {/* ========================================================= */}
      <div className="sticky top-[72px] sm:top-[76px] z-30 bg-[#FFF9FB]/95 backdrop-blur-md py-1 -mx-1 px-1">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar sm:grid sm:grid-cols-4 bg-white p-1 rounded-2xl border border-[#FCE4EC] shadow-xs">
          {/* Tab 1: Orders */}
          <button
            type="button"
            id="tab-admin-orders"
            onClick={() => setAdminSubTab('orders')}
            className={`min-w-[95px] sm:min-w-0 flex-1 py-2 sm:py-2.5 px-2 sm:px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer shrink-0 ${
              adminSubTab === 'orders'
                ? 'bg-[#E57390] text-white shadow-xs'
                : 'text-stone-600 hover:text-[#832F47] hover:bg-[#FFF9FB]'
            }`}
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">{isAr ? `الطلبات (${orders.length})` : `Orders (${orders.length})`}</span>
          </button>

          {/* Tab 2: Products */}
          <button
            type="button"
            id="tab-admin-products"
            onClick={() => setAdminSubTab('products')}
            className={`min-w-[95px] sm:min-w-0 flex-1 py-2 sm:py-2.5 px-2 sm:px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer shrink-0 ${
              adminSubTab === 'products'
                ? 'bg-[#E57390] text-white shadow-xs'
                : 'text-stone-600 hover:text-[#832F47] hover:bg-[#FFF9FB]'
            }`}
          >
            <Package className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">{isAr ? `المنتجات (${products.length})` : `Products (${products.length})`}</span>
          </button>

          {/* Tab 3: Add Product (Direct Action) */}
          <button
            type="button"
            id="tab-admin-add-product"
            onClick={() => {
              setAdminSubTab('products');
              handleOpenAddProduct();
            }}
            className="min-w-[105px] sm:min-w-0 flex-1 py-2 sm:py-2.5 px-2 sm:px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer shrink-0 bg-[#FFF0F4] hover:bg-[#FDE7ED] text-[#832F47] border border-[#FCE4EC] hover:border-[#E57390] active:scale-98"
          >
            <Plus className="w-4 h-4 text-[#E57390] shrink-0" />
            <span className="whitespace-nowrap text-[#832F47]">{isAr ? '+ إضافة منتج' : '+ Add Product'}</span>
          </button>

          {/* Tab 4: Settings */}
          <button
            type="button"
            id="tab-admin-settings"
            onClick={() => setAdminSubTab('settings')}
            className={`min-w-[95px] sm:min-w-0 flex-1 py-2 sm:py-2.5 px-2 sm:px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer shrink-0 ${
              adminSubTab === 'settings'
                ? 'bg-[#E57390] text-white shadow-xs'
                : 'text-stone-600 hover:text-[#832F47] hover:bg-[#FFF9FB]'
            }`}
          >
            <Sliders className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">{isAr ? 'الإعدادات' : 'Settings'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: ORDERS MANAGEMENT (RESPONSIVE CARDS)               */}
      {/* ========================================================= */}
      {adminSubTab === 'orders' && (
        <div className="space-y-3 sm:space-y-4">
          {/* Search & Status Filter Bar */}
          <div className="bg-white rounded-2xl p-3 border border-[#FCE4EC] space-y-2.5 shadow-2xs">
            <div className="relative">
              <Search
                className={`w-4 h-4 text-stone-400 absolute ${
                  isAr ? 'right-3' : 'left-3'
                } top-1/2 -translate-y-1/2`}
              />
              <input
                type="text"
                placeholder={isAr ? 'البحث عن طلب برقم الطلب، اسم الزبونة، أو الهاتف...' : 'Search orders by #, customer name, phone...'}
                value={searchOrderQuery}
                onChange={(e) => setSearchOrderQuery(e.target.value)}
                className={`w-full text-xs ${
                  isAr ? 'pr-9 pl-3' : 'pl-9 pr-3'
                } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]`}
              />
            </div>

            {/* Scrollable Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5 -mx-1 px-1">
              {[
                { id: 'All', label: isAr ? 'الكل' : 'All' },
                { id: 'Order Placed', label: isAr ? 'تم الاستلام' : 'Order Placed' },
                { id: 'Order Confirmed', label: isAr ? 'تم التأكيد' : 'Order Confirmed' },
                { id: 'Preparing', label: isAr ? 'قيد التجهيز' : 'Preparing' },
                { id: 'Out for Delivery', label: isAr ? 'خرج للتوصيل' : 'Out for Delivery' },
                { id: 'Delivered', label: isAr ? 'تم التوصيل' : 'Delivered' },
                { id: 'Cancelled', label: isAr ? 'ملغي' : 'Cancelled' },
              ].map((st) => {
                const isSelected = orderStatusFilter === st.id;
                return (
                  <button
                    key={st.id}
                    onClick={() => setOrderStatusFilter(st.id)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all shrink-0 min-h-[34px] cursor-pointer ${
                      isSelected
                        ? 'bg-[#E57390] text-white shadow-xs'
                        : 'bg-[#FFF0F4] text-stone-600 border border-[#FCE4EC] hover:bg-[#FCE4EC]'
                    }`}
                  >
                    {st.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Orders Responsive Card List */}
          <div className="space-y-3">
            {filteredOrders.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-3xl border border-[#FCE4EC] p-6 text-stone-500 text-xs">
                {isAr
                  ? 'لا توجد طلبات تطابق الفلتر أو كلمة البحث المحددة.'
                  : 'No orders match the current filter or search term.'}
              </div>
            ) : (
              filteredOrders.map((order) => {
                const customer = order.customer || ({} as any);
                const customerName = customer.name || (order as any).customerName || (isAr ? 'زبونة لاستيلا' : 'LASTELLA Customer');
                const customerPhone = customer.phone || (order as any).phone || '';
                const customerWa = customer.whatsapp || (order as any).whatsapp || customerPhone;
                const cleanPhone = customerPhone ? String(customerPhone).replace(/[^0-9]/g, '') : '';
                const cleanWa = customerWa ? String(customerWa).replace(/[^0-9]/g, '') : '';
                const deliveryAddressBrief = customer.city
                  ? `${customer.city}، ${customer.area || ''} (${customer.detailedAddress || customer.address || ''})`
                  : customer.area
                  ? `${customer.area}${customer.governorate ? `، ${customer.governorate}` : ''} (${customer.address || ''})`
                  : customer.address || (isAr ? 'العنوان غير محدد' : 'Address not specified');
                const deliveryMethodText =
                  order.deliveryMethod === 'office'
                    ? isAr
                      ? 'استلام من المكتب (1.000 ر.ع)'
                      : 'Office Delivery (1.000 OMR)'
                    : isAr
                    ? 'توصيل للمنزل (2.000 ر.ع)'
                    : 'Home Delivery (2.000 OMR)';
                const deliveryFeeText = formatOMR(
                  order.deliveryCharge !== undefined
                    ? order.deliveryCharge
                    : order.deliveryMethod === 'office'
                    ? 1.0
                    : 2.0
                );
                const waMessage = `مرحباً ${customerName}! 💎 بخصوص طلبكِ من مجوهرات لاستيلا #${order.orderNumber}:\nحالة الطلب: (${order.status})\nطريقة التوصيل: ${deliveryMethodText}\nرسوم التوصيل: ${deliveryFeeText}\nعنوان التوصيل: ${deliveryAddressBrief}\nالمجموع الكلي: ${formatOMR(order.total)}\nشاكرين لكِ تسوقك معنا!`;

                return (
                  <div
                    key={order.id}
                    className="bg-white rounded-2xl sm:rounded-3xl border border-[#FCE4EC] p-3.5 sm:p-5 shadow-2xs space-y-3"
                  >
                    {/* Header Row: Order Number, Date, Status & Payment Status */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#FDE7ED]">
                      <div className="flex items-center justify-between sm:justify-start gap-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-sm sm:text-base text-[#832F47]">
                            #{order.orderNumber}
                          </span>
                          <span className="text-[10px] sm:text-xs text-stone-400 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-stone-400" />
                            {new Date(order.createdAt).toLocaleDateString()}{' '}
                            {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC]">
                            {order.status}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                              order.paymentStatus === 'Paid' || order.paymentStatus === 'Payment Verified'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}
                          >
                            {order.paymentStatus === 'Paid' || order.paymentStatus === 'Payment Verified'
                              ? isAr ? 'تم التحقق من الدفع ✓' : 'Payment Verified ✓'
                              : isAr ? 'بانتظار التحويل' : 'Pending Payment'}
                          </span>
                        </div>
                      </div>

                      {/* Status & Payment Actions (Touch-Friendly) */}
                      <div className="flex items-center justify-between sm:justify-end gap-2 bg-[#FFF9FB] sm:bg-transparent p-2 sm:p-0 rounded-xl sm:rounded-none flex-wrap">
                        {order.paymentStatus !== 'Payment Verified' && order.paymentStatus !== 'Paid' ? (
                          <button
                            type="button"
                            onClick={() => handleUpdatePaymentStatus(order.id, 'Payment Verified')}
                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 shadow-2xs transition-all active:scale-95 cursor-pointer"
                            title={isAr ? 'تأكيد استلام التحويل البنكي' : 'Confirm Bank Transfer Received'}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تأكيد استلام الدفع' : 'Confirm Payment'}</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleUpdatePaymentStatus(order.id, 'Pending Payment')}
                            className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg text-[10px] font-medium transition-colors"
                            title={isAr ? 'إرجاع إلى بانتظار الدفع' : 'Mark as Pending Payment'}
                          >
                            {isAr ? 'إلغاء التحقق' : 'Reset Payment'}
                          </button>
                        )}

                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-semibold text-[#832F47] sm:text-stone-500">
                            {isAr ? 'الحالة:' : 'Status:'}
                          </span>
                          <div className="relative">
                            <select
                              value={order.status}
                              onChange={(e) =>
                                handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)
                              }
                              className={`text-xs font-semibold bg-white sm:bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC] rounded-xl px-3 py-2 ${
                                isAr ? 'pl-7 pr-3' : 'pr-7 pl-3'
                              } focus:outline-hidden appearance-none cursor-pointer min-h-[38px] shadow-2xs`}
                            >
                              <option value="Order Placed">{isAr ? 'تم استلام الطلب' : 'Order Placed'}</option>
                              <option value="Order Confirmed">{isAr ? 'تم التأكيد' : 'Order Confirmed'}</option>
                              <option value="Preparing">{isAr ? 'قيد التجهيز' : 'Preparing'}</option>
                              <option value="Out for Delivery">{isAr ? 'خرج للتوصيل' : 'Out for Delivery'}</option>
                              <option value="Delivered">{isAr ? 'تم التوصيل' : 'Delivered'}</option>
                              <option value="Cancelled">{isAr ? 'ملغي' : 'Cancelled'}</option>
                            </select>
                            <ChevronDown
                              className={`w-3.5 h-3.5 text-[#832F47] absolute ${
                                isAr ? 'left-2' : 'right-2'
                              } top-1/2 -translate-y-1/2 pointer-events-none`}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Customer & Destination Cardlets */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs">
                      {/* Customer Info */}
                      <div className="bg-[#FFF9FB] rounded-xl p-3 border border-[#FDE7ED] space-y-1.5">
                        <span className="text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider block">
                          {isAr ? 'بيانات الزبونة' : 'Customer Contact'}
                        </span>
                        <p className="font-semibold text-stone-800 text-xs">
                          {customerName}
                        </p>
                        <div className="flex items-center gap-2 pt-0.5 flex-wrap">
                          {cleanPhone ? (
                            <a
                              href={`tel:${cleanPhone}`}
                              className="inline-flex items-center gap-1 text-[11px] text-[#832F47] font-medium hover:underline bg-white px-2 py-1 rounded-lg border border-[#FCE4EC]"
                            >
                              <Phone className="w-3 h-3 text-[#E57390]" />
                              <span>{customerPhone}</span>
                            </a>
                          ) : customerPhone ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-stone-600 bg-white px-2 py-1 rounded-lg border border-[#FCE4EC]">
                              <Phone className="w-3 h-3 text-stone-400" />
                              <span>{customerPhone}</span>
                            </span>
                          ) : null}
                          {cleanWa && (
                            <a
                              href={`https://wa.me/${cleanWa}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] text-[#25D366] font-medium hover:underline bg-white px-2 py-1 rounded-lg border border-[#FCE4EC]"
                            >
                              <MessageCircle className="w-3 h-3 text-[#25D366]" />
                              <span>WhatsApp</span>
                            </a>
                          )}
                        </div>
                      </div>

                      {/* Delivery Address */}
                      <div className="bg-[#FFF9FB] rounded-xl p-3 border border-[#FDE7ED] space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider">
                            {isAr ? 'عنوان التوصيل في عُمان' : 'Delivery Destination'}
                          </span>
                          <span className="text-[10px] font-bold text-[#832F47] bg-white px-2 py-0.5 rounded-md border border-[#FCE4EC]">
                            {order.deliveryMethod === 'office'
                              ? isAr ? 'استلام من المكتب' : 'Office'
                              : isAr ? 'توصيل للمنزل' : 'Home'}
                            {' • '}
                            {formatOMR(
                              order.deliveryCharge !== undefined
                                ? order.deliveryCharge
                                : order.deliveryMethod === 'office'
                                ? 1.0
                                : 2.0
                            )}
                          </span>
                        </div>
                        <div className="text-stone-700 flex items-start gap-1.5 pt-1 text-xs">
                          <MapPin className="w-3.5 h-3.5 text-[#E57390] shrink-0 mt-0.5" />
                          <div className="space-y-1 w-full text-xs">
                            {customer.city ? (
                              <>
                                <div className="grid grid-cols-2 gap-2 text-[11px]">
                                  <div>
                                    <span className="text-[10px] text-stone-400 block font-medium">
                                      {isAr ? 'المدينة:' : 'City:'}
                                    </span>
                                    <span className="font-semibold text-[#3B252E]">{customer.city}</span>
                                  </div>
                                  <div>
                                    <span className="text-[10px] text-stone-400 block font-medium">
                                      {isAr ? 'المنطقة:' : 'Area:'}
                                    </span>
                                    <span className="font-semibold text-[#3B252E]">{customer.area}</span>
                                  </div>
                                </div>
                                <div>
                                  <span className="text-[10px] text-stone-400 block font-medium">
                                    {isAr ? 'العنوان التفصيلي:' : 'Detailed Address:'}
                                  </span>
                                  <p className="text-stone-600 text-[11px] leading-relaxed break-words whitespace-pre-line bg-white/70 p-2 rounded-lg border border-[#FDE7ED]">
                                    {customer.detailedAddress || customer.address}
                                  </p>
                                </div>
                              </>
                            ) : customer.area || customer.address ? (
                              <div>
                                <span className="font-semibold text-[#3B252E]">
                                  {customer.area}{customer.governorate ? `, ${customer.governorate}` : ''}
                                </span>
                                <p className="text-stone-600 text-[11px] leading-relaxed break-words">
                                  {customer.address}
                                </p>
                              </div>
                            ) : (
                              <p className="text-stone-500 text-[11px] italic">
                                {(order as any).address || (isAr ? 'العنوان غير محدد' : 'Address not specified')}
                              </p>
                            )}
                          </div>
                        </div>
                        {order.notes && (
                          <p className="text-[11px] text-stone-500 italic pt-1 border-t border-[#FCE4EC]">
                            {isAr ? 'ملاحظة:' : 'Note:'} "{order.notes}"
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Order Items List */}
                    {(() => {
                      const orderItems = Array.isArray(order.items) ? order.items : [];
                      return (
                        <div className="bg-stone-50/70 rounded-xl p-3 border border-[#FCE4EC] space-y-2">
                          <span className="text-[10px] font-serif font-bold text-[#C5A059] uppercase tracking-wider block">
                            {isAr ? `قطع المجوهرات (${orderItems.length})` : `Order Items (${orderItems.length})`}
                          </span>
                          {orderItems.length === 0 ? (
                            <p className="text-stone-400 text-[11px] italic">
                              {isAr ? 'لا توجد تفاصيل قطع مسجلة' : 'No items recorded'}
                            </p>
                          ) : (
                            <div className="divide-y divide-[#FCE4EC]">
                              {orderItems.map((it, idx) => {
                                const itemName = isAr
                                  ? it.product?.arabicName || it.product?.name || (it as any).name || 'قطعة مجوهرات'
                                  : it.product?.name || (it as any).name || 'Jewelry Item';
                                const itemPrice = it.product?.price !== undefined ? it.product.price : ((it as any).price || 0);
                                const itemQty = it.quantity || 1;
                                return (
                                  <div key={idx} className="py-1.5 first:pt-0 last:pb-0 flex items-center justify-between text-xs gap-2">
                                    <div className="flex items-center gap-2 min-w-0">
                                      <span className="w-5 h-5 rounded-full bg-[#E57390] text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                                        {itemQty}
                                      </span>
                                      <span className="text-stone-800 truncate font-medium">
                                        {itemName}
                                        {it.selectedSize ? ` (${isAr ? 'مقاس' : 'Size'}: ${it.selectedSize})` : ''}
                                        {it.selectedColor
                                          ? ` (${isAr ? 'اللون' : 'Color'}: ${
                                              it.selectedColor === 'Gold'
                                                ? isAr
                                                  ? 'ذهبي'
                                                  : 'Gold'
                                                : it.selectedColor === 'Silver'
                                                ? isAr
                                                  ? 'فضي'
                                                  : 'Silver'
                                                : it.selectedColor
                                            })`
                                          : ''}
                                      </span>
                                    </div>
                                    <span className="font-serif font-bold text-[#832F47] shrink-0">
                                      {formatOMR(itemPrice * itemQty)}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })()}

                    {/* Bottom Row: Total Price & WhatsApp Action Button */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-2 border-t border-[#FDE7ED]">
                      <div className="flex items-baseline justify-between sm:justify-start gap-3">
                        <span className="text-xs text-stone-500">{isAr ? 'إجمالي الطلب:' : 'Total Order Amount:'}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-base sm:text-lg text-[#832F47]">
                            {formatOMR(order.total)}
                          </span>
                          <span className="text-[10px] bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC] px-2 py-0.5 rounded-md font-semibold">
                            {order.paymentMethod === 'bank_transfer'
                              ? isAr ? 'تحويل بنكي' : 'Bank Transfer'
                              : order.paymentMethod}
                          </span>
                        </div>
                      </div>

                      <a
                        href={`https://wa.me/${cleanWa || cleanPhone}?text=${encodeURIComponent(waMessage)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto px-4 py-2.5 bg-[#25D366] hover:bg-[#20BE5C] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors min-h-[40px]"
                      >
                        <MessageCircle className="w-4 h-4 fill-white" />
                        <span>{isAr ? 'تحديث الزبونة عبر الواتساب' : 'Update Customer via WhatsApp'}</span>
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: PRODUCTS CATALOG (RESPONSIVE CARDS & EDIT BUTTONS) */}
      {/* ========================================================= */}
      {adminSubTab === 'products' && (
        <div className="space-y-3 sm:space-y-4">
          {/* Header & Prominent Add Button */}
          <div className="bg-white rounded-2xl p-3.5 border border-[#FCE4EC] shadow-2xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div>
                <h3 className="font-serif font-bold text-sm sm:text-base text-[#832F47]">
                  {isAr ? `كتالوج المجوهرات وتعديل الأسعار (${filteredProducts.length})` : `JEWELRY CATALOG & EDIT (${filteredProducts.length})`}
                </h3>
                <p className="text-[11px] text-stone-500">
                  {isAr
                    ? 'اضغطي على "تعديل" لتغيير بيانات أي قطعة، السعر، أو إضافة صور'
                    : 'Tap "Edit" on any jewelry item to update price, stock, or photos'}
                </p>
              </div>

              <button
                id="btn-admin-add-product"
                onClick={handleOpenAddProduct}
                className="w-full sm:w-auto px-4 py-3 bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white text-xs font-bold tracking-wider uppercase rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all min-h-[44px] cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? '+ إضافة قطعة مجوهرات جديدة' : '+ Add New Jewelry Piece'}</span>
              </button>
            </div>

            {/* Search and Category Filter */}
            <div className="space-y-2 pt-1 border-t border-[#FCE4EC]">
              <div className="relative">
                <Search
                  className={`w-4 h-4 text-stone-400 absolute ${
                    isAr ? 'right-3' : 'left-3'
                  } top-1/2 -translate-y-1/2`}
                />
                <input
                  type="text"
                  placeholder={isAr ? 'البحث بالاسم العربي، الإنجليزي، أو كود القطعة (SKU)...' : 'Search by jewelry name, Arabic title, SKU...'}
                  value={searchProductQuery}
                  onChange={(e) => setSearchProductQuery(e.target.value)}
                  className={`w-full text-xs ${
                    isAr ? 'pr-9 pl-3' : 'pl-9 pr-3'
                  } py-2 bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]`}
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5 -mx-1 px-1">
                {[
                  'All',
                  'New Arrivals',
                  'Necklaces',
                  'Bracelets',
                  'Bangles',
                  'Anklets',
                  'Rings',
                  'Brand Boxes',
                  'Best Selling',
                ].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setProductCategoryFilter(cat)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all shrink-0 min-h-[32px] cursor-pointer ${
                      productCategoryFilter === cat
                        ? 'bg-[#E57390] text-white shadow-xs'
                        : 'bg-[#FFF0F4] text-stone-600 border border-[#FCE4EC] hover:bg-[#FCE4EC]'
                    }`}
                  >
                    {cat === 'All' ? (isAr ? 'الكل' : 'All') : getCategoryTranslation(cat as any, language)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Product Cards List (Adaptive Grid) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl sm:rounded-3xl border border-[#FCE4EC] p-3.5 sm:p-4 shadow-2xs flex flex-col justify-between space-y-3"
              >
                {/* Top: Product Image + Info */}
                <div className="flex items-start gap-3">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#FFF0F4] shrink-0 border border-[#FCE4EC] relative">
                    <img
                      src={getOptimizedImageUrl(product.images[0], 200, 'auto', 'fit')}
                      alt=""
                      className="w-full h-full object-cover"
                      loading="eager"
                      decoding="async"
                      width={80}
                      height={80}
                    />
                    {product.inStock === false && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-2xs flex items-center justify-center">
                        <span className="text-[9px] font-bold text-white uppercase bg-rose-600 px-1.5 py-0.5 rounded-sm">
                          {isAr ? 'نفذ' : 'Out of Stock'}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-[#C5A059] truncate">
                        {product.category}
                      </span>
                      {product.sku && (
                        <span className="text-[9px] font-mono text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded-md">
                          {product.sku}
                        </span>
                      )}
                    </div>

                    <h4 className="font-serif text-xs font-bold text-[#3B252E] line-clamp-1">
                      {isAr ? product.arabicName || product.name : product.name}
                    </h4>
                    {product.arabicName && !isAr && (
                      <p className="text-[11px] text-stone-500 line-clamp-1 font-arabic" dir="rtl">
                        {product.arabicName}
                      </p>
                    )}

                    <div className="flex items-baseline gap-1.5 pt-0.5">
                      <span className="font-serif font-bold text-xs sm:text-sm text-[#832F47]">
                        {formatOMR(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-[10px] text-stone-400 line-through">
                          {formatOMR(product.originalPrice)}
                        </span>
                      )}
                    </div>

                    {/* Compact Variants Summary (Variants, Sizes & Colors) */}
                    {product.variants && product.variants.length > 0 ? (
                      <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-stone-600 bg-[#FFF9FB] px-2 py-1 rounded-lg border border-[#FCE4EC]/70 mt-1">
                        <span className="font-semibold text-[#832F47]">
                          {product.variants.length} {isAr ? 'خيارات' : 'variants'}
                        </span>
                        <span className="text-stone-300">•</span>
                        <span className="text-emerald-700 font-medium">
                          {product.variants.filter((v) => v.available !== false).length} {isAr ? 'متوفر' : 'available'}
                        </span>
                        {product.variants.some((v) => v.available === false) && (
                          <>
                            <span className="text-stone-300">•</span>
                            <span className="text-rose-600 font-medium">
                              {product.variants.filter((v) => v.available === false).length} {isAr ? 'غير متوفر' : 'out of stock'}
                            </span>
                          </>
                        )}
                      </div>
                    ) : ((product.sizes && product.sizes.length > 0) || (product.colors && product.colors.length > 0)) && (
                      <div className="flex items-center gap-1.5 flex-wrap text-[10px] text-stone-600 bg-[#FFF9FB] px-2 py-0.5 rounded-lg border border-[#FCE4EC]/70 mt-1">
                        {product.sizes && product.sizes.length > 0 && (
                          <span className="truncate">
                            <strong className="text-[#832F47]">{isAr ? 'المقاسات: ' : 'Sizes: '}</strong>
                            {product.sizes.length > 3 && product.sizes.every((s) => !isNaN(Number(s)))
                              ? `${product.sizes[0]}–${product.sizes[product.sizes.length - 1]}`
                              : product.sizes.join(' / ')}
                          </span>
                        )}
                        {product.sizes && product.sizes.length > 0 && product.colors && product.colors.length > 0 && (
                          <span className="text-stone-300">•</span>
                        )}
                        {product.colors && product.colors.length > 0 && (
                          <span className="truncate">
                            <strong className="text-[#832F47]">{isAr ? 'الألوان: ' : 'Colors: '}</strong>
                            {product.colors
                              .map((c) => (c === 'Gold' ? (isAr ? 'ذهبي' : 'Gold') : c === 'Silver' ? (isAr ? 'فضي' : 'Silver') : c))
                              .join(', ')}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Product Availability Toggle (1-Tap Fast Toggle) */}
                <div className="bg-[#FFF9FB] rounded-xl p-2 border border-[#FCE4EC] flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-semibold text-stone-600">
                      {isAr ? 'الحالة:' : 'Status:'}
                    </span>
                    {product.inStock !== false ? (
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-700" />
                        <span>{isAr ? 'متوفر للبيع' : 'Available'}</span>
                      </span>
                    ) : (
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 flex items-center gap-1">
                        <X className="w-3 h-3 text-rose-700" />
                        <span>{isAr ? 'غير متوفر (نفد)' : 'Out of Stock'}</span>
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleAvailability(product)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-2xs active:scale-95 cursor-pointer flex items-center gap-1 ${
                      product.inStock !== false
                        ? 'bg-white border border-rose-200 text-rose-700 hover:bg-rose-50'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700'
                    }`}
                    title={
                      product.inStock !== false
                        ? (isAr ? 'تغيير إلى غير متوفر' : 'Mark as Out of Stock')
                        : (isAr ? 'تغيير إلى متوفر للبيع' : 'Mark as Available')
                    }
                  >
                    {product.inStock !== false ? (
                      <>
                        <X className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تعطيل البيع' : 'Set Out of Stock'}</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إتاحة للبيع' : 'Set Available'}</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Badges & Actions (Large, Prominent Edit & Delete Buttons) */}
                <div className="space-y-2 pt-2 border-t border-[#FDE7ED] text-xs">
                  <div className="flex items-center gap-1 flex-wrap">
                    {product.isBestSeller && (
                      <span className="text-[8px] font-bold bg-[#E57390] text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                        {isAr ? 'الأكثر مبيعاً' : 'Best Seller'}
                      </span>
                    )}
                    {product.isNewArrival && (
                      <span className="text-[8px] font-bold bg-[#C5A059] text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                        {isAr ? 'جديد' : 'New'}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {/* Primary Edit Button - Touch-Friendly 42px */}
                    <button
                      type="button"
                      id={`btn-edit-product-${product.id}`}
                      onClick={() => handleOpenEditProduct(product)}
                      className="w-full py-2.5 px-2.5 rounded-xl bg-[#FFF0F4] hover:bg-[#FDE7ED] active:bg-[#FCE4EC] text-[#832F47] font-bold text-xs transition-all flex items-center justify-center gap-1.5 border border-[#FCE4EC] min-h-[42px] cursor-pointer shadow-2xs active:scale-95"
                      title={isAr ? 'تعديل بيانات وسعر وصور القطعة' : 'Edit Product'}
                    >
                      <Edit className="w-3.5 h-3.5 text-[#E57390] shrink-0" />
                      <span className="truncate">{isAr ? 'تعديل المنتج' : 'Edit Product'}</span>
                    </button>

                    {/* Delete Button - Touch-Friendly 42px */}
                    <button
                      type="button"
                      id={`btn-delete-product-${product.id}`}
                      onClick={() => setProductToDelete(product)}
                      className="w-full py-2.5 px-2.5 rounded-xl bg-white hover:bg-rose-50 active:bg-rose-100 text-stone-600 hover:text-rose-600 font-semibold text-xs transition-all flex items-center justify-center gap-1.5 border border-stone-200 hover:border-rose-200 min-h-[42px] cursor-pointer shadow-2xs active:scale-95"
                      title={isAr ? 'حذف القطعة من الكتالوج' : 'Delete Product'}
                    >
                      <Trash2 className="w-3.5 h-3.5 text-stone-400 hover:text-rose-600 shrink-0" />
                      <span className="truncate">{isAr ? 'حذف' : 'Delete'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: BOUTIQUE SETTINGS (RESPONSIVE FORM)                */}
      {/* ========================================================= */}
      {adminSubTab === 'settings' && (
        <form
          onSubmit={handleSaveSettings}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 border border-[#FCE4EC] shadow-2xs space-y-4"
        >
          <div className="border-b border-[#FCE4EC] pb-3">
            <h3 className="font-serif font-bold text-sm sm:text-base text-[#832F47]">
              {isAr ? 'إعدادات المتجر وأسعار التوصيل في سلطنة عُمان' : 'STORE CONFIGURATION & OMAN DELIVERY RATES'}
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              {isAr
                ? 'تحديد رقم واتساب الطلبات الرسمي، هاتف الدعم، ورسوم الشحن لكافة المحافظات'
                : 'Set your official WhatsApp order hotline and Oman domestic shipping fees'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="bg-[#FFF9FB] p-3 rounded-2xl border border-[#FCE4EC] space-y-1">
              <label className="block text-xs font-semibold text-[#3B252E]">
                {isAr ? 'هاتف خدمة الزبائن / البوتيك' : 'Store Phone / Support Hotline'}
              </label>
              <input
                type="text"
                value={settingPhone}
                onChange={(e) => setSettingPhone(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div className="bg-[#FFF9FB] p-3 rounded-2xl border border-[#FCE4EC] space-y-1">
              <label className="block text-xs font-semibold text-[#3B252E]">
                {isAr ? 'رقم الواتساب الرسمي للطلبات (مثال: 96894882311)' : 'Official WhatsApp Number (e.g. 96894882311)'}
              </label>
              <input
                type="text"
                value={settingWa}
                onChange={(e) => setSettingWa(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div className="bg-[#FFF9FB] p-3 rounded-2xl border border-[#FCE4EC] space-y-1">
              <label className="block text-xs font-semibold text-[#3B252E]">
                {isAr ? 'سعر التوصيل للمنزل (ر.ع)' : 'Home Delivery Rate (OMR)'}
              </label>
              <input
                type="number"
                step="0.100"
                value={settingHomePrice}
                onChange={(e) => setSettingHomePrice(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div className="bg-[#FFF9FB] p-3 rounded-2xl border border-[#FCE4EC] space-y-1">
              <label className="block text-xs font-semibold text-[#3B252E]">
                {isAr ? 'سعر الاستلام من المكتب (ر.ع)' : 'Office Delivery Rate (OMR)'}
              </label>
              <input
                type="number"
                step="0.100"
                value={settingOfficePrice}
                onChange={(e) => setSettingOfficePrice(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>
          </div>

          {/* Bank Transfer Configuration Card */}
          <div className="bg-[#FFF9FB] p-4 rounded-2xl border border-[#FCE4EC] space-y-3">
            <div className="flex items-center gap-2">
              <Landmark className="w-4 h-4 text-[#832F47]" />
              <h4 className="text-xs font-bold text-[#832F47]">
                {isAr ? 'إعدادات الحساب البنكي المعتمد للتحويل (Bank Transfer)' : 'Official Bank Transfer Account Settings'}
              </h4>
            </div>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              {isAr
                ? 'التحويل البنكي هو طريقة الدفع الحصرية المعتمدة في متجر لاستيلا. يتم حفظ هذه البيانات في فايربيس وعرضها للزبائن فور إتمام الطلب.'
                : 'Bank Transfer is the exclusive payment method for LASTELLA. These details are stored in Firestore and displayed to customers during checkout and on order receipt.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'اسم البنك' : 'Bank Name'}
                </label>
                <input
                  type="text"
                  value={settingBankName}
                  onChange={(e) => setSettingBankName(e.target.value)}
                  placeholder="e.g. Bank Muscat"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'اسم صاحب الحساب' : 'Account Holder Name'}
                </label>
                <input
                  type="text"
                  value={settingAccountName}
                  onChange={(e) => setSettingAccountName(e.target.value)}
                  placeholder="e.g. LASTELLA JEWELRY"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'رقم الحساب البنكي' : 'Bank Account Number'}
                </label>
                <input
                  type="text"
                  value={settingAccountNumber}
                  onChange={(e) => setSettingAccountNumber(e.target.value)}
                  placeholder="e.g. 0423012345670019"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'رقم الآيبان الدولي (IBAN - اختياري)' : 'IBAN (Optional)'}
                </label>
                <input
                  type="text"
                  value={settingBankIban}
                  onChange={(e) => setSettingBankIban(e.target.value)}
                  placeholder="e.g. OM45BMUS0423012345670019"
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-mono"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'تعليمات التحويل للزبونة (باللغة العربية)' : 'Transfer Instructions (Arabic)'}
                </label>
                <textarea
                  rows={2}
                  value={settingBankInstructionsAr}
                  onChange={(e) => setSettingBankInstructionsAr(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="block text-xs font-semibold text-[#3B252E]">
                  {isAr ? 'تعليمات التحويل للزبونة (باللغة الإنجليزية)' : 'Transfer Instructions (English)'}
                </label>
                <textarea
                  rows={2}
                  value={settingBankInstructions}
                  onChange={(e) => setSettingBankInstructions(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                />
              </div>
            </div>
          </div>

          <div className="bg-[#FFF9FB] p-3 rounded-2xl border border-[#FCE4EC] space-y-1">
            <label className="block text-xs font-semibold text-[#3B252E]">
              {isAr ? 'نص شريط الإعلانات العلوي' : 'Top Announcement Bar Text'}
            </label>
            <input
              type="text"
              value={settingAnnouncement}
              onChange={(e) => setSettingAnnouncement(e.target.value)}
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
            />
          </div>

          <div className="bg-[#FFF9FB] p-4 rounded-2xl border border-[#FCE4EC] space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#832F47]" />
              <h4 className="text-xs font-bold text-[#832F47]">
                {isAr ? 'أمان حساب المدير وكلمة المرور (Firebase Auth)' : 'Admin Security & Credentials (Firebase Auth)'}
              </h4>
            </div>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              {isAr
                ? 'لحماية المتجر والبيانات، يتم التحقق من بيانات المدير عبر خوادم Firebase المشفرة. لتغيير كلمة المرور، يرجى ملء الحقول أدناه:'
                : 'Manager credentials are authenticated securely via Firebase Authentication. To update your passcode or password, enter your current and new credentials below:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-[#3B252E]">
                  {isAr ? 'كلمة المرور الحالية' : 'Current Password'}
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPass ? 'text' : 'password'}
                    value={currentPasscode}
                    onChange={(e) => setCurrentPasscode(e.target.value)}
                    placeholder="••••••"
                    className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-mono pr-8"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPass(!showCurrentPass)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                  >
                    {showCurrentPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-[#3B252E]">
                  {isAr ? 'كلمة المرور الجديدة' : 'New Password (min 6)'}
                </label>
                <div className="relative">
                  <input
                    type={showNewPass ? 'text' : 'password'}
                    value={newPasscode}
                    onChange={(e) => setNewPasscode(e.target.value)}
                    placeholder="••••••"
                    className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-mono pr-8"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                  >
                    {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-[#3B252E]">
                  {isAr ? 'تأكيد كلمة المرور الجديدة' : 'Confirm New Password'}
                </label>
                <input
                  type={showNewPass ? 'text' : 'password'}
                  value={confirmPasscode}
                  onChange={(e) => setConfirmPasscode(e.target.value)}
                  placeholder="••••••"
                  className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-mono"
                />
              </div>
            </div>
            <p className="text-[10px] text-stone-400">
              {isAr
                ? 'اتركي حقول كلمة المرور فارغة إذا كنتِ ترغبين فقط بتعديل أسعار التوصيل أو معلومات المتجر.'
                : 'Leave password fields empty if you only wish to update delivery rates or store contact info.'}
            </p>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isChangingPassword}
              className="w-full sm:w-auto px-6 py-3 bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white text-xs font-bold tracking-widest uppercase rounded-2xl shadow-xs transition-all flex items-center justify-center gap-2 min-h-[44px] cursor-pointer disabled:opacity-50"
            >
              {isChangingPassword ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isAr ? 'جاري تحديث البيانات...' : 'Updating credentials...'}</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{isAr ? 'حفظ إعدادات المتجر' : 'Save Boutique Settings'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* ========================================================= */}
      {/* PRODUCT ADD / EDIT MODAL (RESPONSIVE FULL DIALOG)         */}
      {/* ========================================================= */}
      {isProductModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in"
          dir={isAr ? 'rtl' : 'ltr'}
        >
          <div className="bg-[#FFF9FB] w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 bg-white border-b border-[#FCE4EC] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#FFF0F4] text-[#832F47] flex items-center justify-center border border-[#FCE4EC]">
                  <Package className="w-4 h-4" />
                </div>
                <h3 className="font-serif font-bold text-sm tracking-wide text-[#832F47]">
                  {editingProduct
                    ? isAr
                      ? `تعديل قطعة المجوهرات: ${editingProduct.arabicName || editingProduct.name}`
                      : `Edit Jewelry Product: ${editingProduct.name}`
                    : isAr
                    ? 'إضافة قطعة مجوهرات جديدة'
                    : 'Add New Jewelry Product'}
                </h3>
              </div>
              <button
                type="button"
                onClick={handleCloseProductModal}
                className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-[#FFF0F4] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveProduct} className="flex flex-col flex-1 min-h-0">
              <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-3.5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-[#3B252E] mb-1">
                      {isAr ? 'اسم المنتج بالإنجليزية (EN) *' : 'Product Name (EN) *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={(e) => handleEnglishNameChange(e.target.value)}
                      placeholder="e.g. LASTELLA Royal Solitaire Ring"
                      className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1 flex-wrap gap-1">
                      <label className="block font-semibold text-[#3B252E]">
                        {isAr ? 'اسم المنتج بالعربية *' : 'Arabic Name'}
                      </label>
                      <div className="flex items-center gap-1.5">
                        {isTranslatingArabic && (
                          <span className="text-[10px] font-semibold text-[#832F47] flex items-center gap-1">
                            <Loader2 className="w-3 h-3 animate-spin text-[#E57390]" />
                            {isAr ? 'جاري الترجمة...' : 'Translating...'}
                          </span>
                        )}
                        {!isTranslatingArabic && formArabicName && !isArabicManuallyEdited && (
                          <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5 text-emerald-600" />
                            {isAr ? 'مترجم تلقائياً' : 'Auto-translated'}
                          </span>
                        )}
                        {!isTranslatingArabic && isArabicManuallyEdited && formArabicName && (
                          <span className="text-[10px] font-semibold text-stone-600 bg-stone-100 border border-stone-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Edit className="w-2.5 h-2.5 text-stone-500" />
                            {isAr ? 'تعديل يدوي' : 'Manual Edit'}
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={handleManualReTranslate}
                          disabled={!formName.trim() || isTranslatingArabic}
                          className="text-[10px] text-[#832F47] hover:text-[#E57390] bg-[#FFF0F4] hover:bg-[#FCE4EC] active:scale-95 border border-[#FCE4EC] px-2 py-0.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer disabled:opacity-40"
                          title={isAr ? 'إعادة الترجمة التلقائية من الاسم الإنجليزي' : 'Re-translate from English'}
                        >
                          <Languages className="w-3 h-3" />
                          <span>{isAr ? 'إعادة ترجمة' : 'Re-translate'}</span>
                        </button>
                      </div>
                    </div>
                    <input
                      type="text"
                      value={formArabicName}
                      onChange={(e) => handleArabicNameChange(e.target.value)}
                      placeholder="مثال: خاتم سوليتير ملكي مطلي ذهب 18"
                      className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-[#3B252E] mb-1">
                      {isAr ? 'القسم *' : 'Category *'}
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as ProductCategory)}
                      className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl font-semibold text-[#3B252E] focus:outline-hidden focus:border-[#E57390]"
                    >
                      <option value="Necklaces">{isAr ? 'عقود وسلاسل [ Necklaces ]' : 'Necklaces'}</option>
                      <option value="Bracelets">{isAr ? 'أساور [ Bracelets ]' : 'Bracelets'}</option>
                      <option value="Bangles">{isAr ? 'بناجر [ Bangles ]' : 'Bangles'}</option>
                      <option value="Anklets">{isAr ? 'خلاخل [ Anklets ]' : 'Anklets'}</option>
                      <option value="Rings">{isAr ? 'خواتم [ Rings ]' : 'Rings'}</option>
                      <option value="Brand Boxes">{isAr ? 'علب الماركة [ Brand Boxes ]' : 'Brand Boxes'}</option>
                      {/* Legacy categories for compatibility */}
                      <option value="Jewelry Sets">{isAr ? 'أطقم فاخرة [ Jewelry Sets ]' : 'Jewelry Sets'}</option>
                      <option value="Combos">{isAr ? 'بكجات وتنسيقات [ Combos ]' : 'Combos'}</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block font-semibold text-[#3B252E]">
                        {isAr ? 'السعر (ر.ع) *' : 'Price (OMR) *'}
                      </label>
                      <span className="text-[10px] text-[#832F47] font-semibold bg-[#FFF0F4] px-1.5 py-0.5 rounded border border-[#FCE4EC]">
                        {isAr ? 'افتراضي 1.100' : 'Default 1.100'}
                      </span>
                    </div>
                    <input
                      type="number"
                      step="0.050"
                      required
                      value={formPrice}
                      onChange={(e) => setFormPrice(e.target.value)}
                      placeholder="1.100"
                      className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-[#3B252E] mb-1">
                      {isAr ? 'السعر الأصلي (قبل الخصم)' : 'Original Price (OMR)'}
                    </label>
                    <input
                      type="number"
                      step="0.050"
                      value={formOriginalPrice}
                      onChange={(e) => setFormOriginalPrice(e.target.value)}
                      placeholder={isAr ? 'اختياري (مثال: 2.500)' : 'Optional (e.g. 2.500)'}
                      className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                    />
                  </div>
                </div>

                {/* Cloudinary Image Upload Section */}
                <div className="bg-[#FFF9FB] p-3 sm:p-3.5 rounded-2xl border border-[#FCE4EC] space-y-2.5">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <span className="font-semibold text-xs text-[#3B252E] block">
                        {isAr ? 'رفع صور المجوهرات (Cloudinary)' : 'Cloudinary Image Upload'}
                      </span>
                      <span className="text-[10px] text-stone-500">
                        {isAr ? 'صيغ مدعومة: JPG, PNG, WebP (ضغط تلقائي 1200px)' : 'Supported: JPG, PNG, WebP (auto-optimized)'}
                      </span>
                    </div>

                    {/* Status indicator badge */}
                    <div className="flex items-center gap-1.5">
                      {cloudinaryStatus === 'ready' && (
                        <span className="text-[10px] font-semibold text-[#832F47] bg-white px-2.5 py-1 rounded-full border border-[#FCE4EC] shadow-2xs">
                          {isAr ? 'جاهز للرفع' : 'Ready'}
                        </span>
                      )}
                      {cloudinaryStatus === 'uploading' && (
                        <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-full border border-sky-200 shadow-2xs flex items-center gap-1">
                          <Loader2 className="w-3 h-3 animate-spin text-sky-600" />
                          <span>{uploadProgress !== null ? `Uploading... ${uploadProgress}%` : (isAr ? 'جاري الرفع...' : 'Uploading...')}</span>
                        </span>
                      )}
                      {cloudinaryStatus === 'success' && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 shadow-2xs flex items-center gap-1">
                          <CheckCircle className="w-3 h-3 text-emerald-600" />
                          <span>{isAr ? 'تم رفع الصورة ✓' : 'Image uploaded ✓'}</span>
                        </span>
                      )}
                      {cloudinaryStatus === 'error' && (
                        <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200 shadow-2xs flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-rose-600" />
                          <span>{isAr ? 'فشل الرفع' : 'Upload failed'}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Hidden Native File Input (compatible with Android/Capacitor photo picker) */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/jpg"
                    className="sr-only"
                    onChange={handleImageUpload}
                    disabled={isUploadingImage}
                    tabIndex={-1}
                    aria-hidden="true"
                  />

                  {/* Touch-Friendly Upload Trigger Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingImage}
                    className="w-full py-3 px-4 bg-white hover:bg-[#FFF0F4] active:bg-[#FCE4EC] text-[#832F47] rounded-xl border border-[#FCE4EC] hover:border-[#E57390] text-xs font-bold transition-all shadow-2xs active:scale-98 cursor-pointer disabled:opacity-60 flex items-center justify-center gap-2 min-h-[44px]"
                  >
                    {isUploadingImage ? (
                      <Loader2 className="w-4 h-4 animate-spin text-[#E57390]" />
                    ) : (
                      <Upload className="w-4 h-4 text-[#E57390]" />
                    )}
                    <span>
                      {isUploadingImage
                        ? (isAr ? `جاري الرفع لـ Cloudinary (${uploadProgress || 10}%)...` : `Uploading to Cloudinary (${uploadProgress || 10}%)...`)
                        : (isAr ? '📁 اختيار صورة من الجهاز والرفع إلى Cloudinary' : '📁 Upload Photo from Device to Cloudinary')}
                    </span>
                  </button>

                  {/* Visual Progress Bar while Uploading */}
                  {isUploadingImage && uploadProgress !== null && (
                    <div className="w-full bg-white rounded-full h-2 overflow-hidden border border-[#FCE4EC]">
                      <div
                        className="bg-gradient-to-r from-[#E57390] to-[#832F47] h-full transition-all duration-200"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  )}

                  {/* Error Message banner */}
                  {cloudinaryStatus === 'error' && cloudinaryError && (
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2 animate-in fade-in">
                      <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span className="flex-1 text-[11px] font-medium">{cloudinaryError}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setCloudinaryStatus('ready');
                          setCloudinaryError(null);
                        }}
                        className="text-[10px] text-rose-700 hover:underline shrink-0"
                      >
                        {isAr ? 'إغلاق' : 'Dismiss'}
                      </button>
                    </div>
                  )}

                  {/* Manual Image URLs fallback */}
                  <div className="pt-1">
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                      {isAr ? 'روابط صور المنتج (رابط HTTPS واحد في كل سطر):' : 'Image URLs (one HTTPS URL per line):'}
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={formImages}
                      onChange={(e) => setFormImages(e.target.value)}
                      placeholder={isAr ? 'https://example.com/image.jpg (أو اضغطي زر الرفع أعلاه)' : 'https://example.com/image.jpg (or use upload button above)'}
                      className="w-full px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl font-mono text-[11px] focus:outline-hidden focus:border-[#E57390]"
                    />
                  </div>

                  {/* Image thumbnails preview */}
                  <div className="flex items-center gap-2 pt-1 overflow-x-auto no-scrollbar">
                    {formImages
                      .split('\n')
                      .map((s) => s.trim())
                      .filter(Boolean)
                      .slice(0, 5)
                      .map((imgUrl, i) => (
                        <div
                          key={i}
                          className="w-14 h-14 rounded-xl overflow-hidden border border-[#FCE4EC] bg-white shrink-0 relative"
                        >
                          <img
                            src={imgUrl}
                            alt=""
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                        </div>
                      ))}
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#3B252E] mb-1">
                    {isAr ? 'وصف القطعة والتفاصيل' : 'Description'}
                  </label>
                  <textarea
                    rows={2}
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                  />
                </div>

                {/* Requirement 4: Available for Sale Checkbox (Replaces Initial Stock Count; Material field removed) */}
                <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-[#FCE4EC] shadow-2xs space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={formInStock}
                        onChange={(e) => setFormInStock(e.target.checked)}
                        className="w-5 h-5 rounded-md accent-[#E57390] text-[#E57390] focus:ring-[#E57390] cursor-pointer"
                      />
                      <span className="font-bold text-xs sm:text-sm text-[#3B252E]">
                        {isAr ? 'متوفر للبيع في المتجر' : 'Available for Sale'}
                      </span>
                    </label>

                    {formInStock ? (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1 shadow-2xs shrink-0">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{isAr ? 'متوفر للطلب' : 'In Stock'}</span>
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-1 rounded-full flex items-center gap-1 shadow-2xs shrink-0">
                        <X className="w-3.5 h-3.5 text-rose-600" />
                        <span>{isAr ? 'نفد (غير متوفر)' : 'Out of Stock'}</span>
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-stone-500 leading-relaxed ps-8">
                    {isAr
                      ? 'عند التحديد، تتاح هذه القطعة فوراً للزبائن للشراء والطلب دون تحديد سقف للكمية. وعند إلغاء التحديد تظهر كنفدت من المخزون.'
                      : 'When checked, this jewelry item is immediately available for purchase with no stock limit. Uncheck to mark Out of Stock.'}
                  </p>
                </div>

                <div>
                  <label className="block font-semibold text-[#3B252E] mb-1">
                    {isAr ? 'إرشادات العناية الخاصة (اختياري)' : 'Care Instructions / Notes (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={formCareNote}
                    onChange={(e) => setFormCareNote(e.target.value)}
                    placeholder={isAr ? 'مثال: تجنب الرش المباشر للعطور المركزة' : 'e.g. Avoid direct perfume spray'}
                    className="w-full px-3 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
                  />
                </div>

                {/* Product Variants: Dynamic "+ Add Variant" System */}
                <div className="space-y-3 pt-3 border-t border-[#FCE4EC]">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <label className="block font-bold text-[#3B252E] text-xs uppercase tracking-wider">
                          {isAr ? 'خيارات المنتج (Product Variants)' : 'Product Variants'}
                        </label>
                        <span className="text-[10px] text-[#832F47] font-semibold bg-[#FFF0F4] px-2 py-0.5 rounded-full border border-[#FCE4EC]">
                          {formVariants.length} {isAr ? 'خيارات' : 'variants'}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        {isAr
                          ? 'أضيفي خيارات المقاس واللون المتاحة للقطعة مع الترجمة التلقائية الفورية وحفظ التوفر.'
                          : 'Add selectable size & color combinations with instant Arabic auto-translation.'}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddVariant}
                      className="px-3 py-1.5 bg-[#E57390] hover:bg-[#D45E7C] active:scale-95 text-white text-xs font-bold rounded-xl shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isAr ? '+ إضافة خيار (Add Variant)' : '+ Add Variant'}</span>
                    </button>
                  </div>

                  {/* Empty state when no variants are created */}
                  {formVariants.length === 0 && (
                    <div className="text-center py-5 px-4 bg-white rounded-2xl border border-dashed border-[#FCE4EC] text-stone-500 space-y-1">
                      <p className="text-xs font-semibold text-[#3B252E]">
                        {isAr
                          ? 'لا توجد خيارات مضافة بعد (قطعة بمقاس/لون موحد)'
                          : 'No variants created yet (standard single piece)'}
                      </p>
                      <p className="text-[11px] text-stone-400">
                        {isAr
                          ? 'للقطع التي لا تتطلب تحديد مقاس أو لون، استخدمي خيار "متوفر للبيع" أعلاه دون الحاجة لإنشاء خيارات.'
                          : 'For pieces without selectable options, the product availability checkbox above controls purchasing.'}
                      </p>
                    </div>
                  )}

                  {/* Unlimited Editable Variant Cards */}
                  {formVariants.length > 0 && (
                    <div className="space-y-2.5">
                      {formVariants.map((variant, index) => {
                        const s = (variant.sizeEn || '').trim().toLowerCase();
                        const c = (variant.colorEn || '').trim().toLowerCase();
                        const isDuplicate = Boolean(
                          (s || c) &&
                          formVariants.some(
                            (other, oIdx) =>
                              oIdx !== index &&
                              (other.sizeEn || '').trim().toLowerCase() === s &&
                              (other.colorEn || '').trim().toLowerCase() === c
                          )
                        );

                        return (
                          <div
                            key={variant.id}
                            className={`p-3 sm:p-3.5 rounded-2xl border transition-all ${
                              isDuplicate
                                ? 'bg-rose-50/50 border-rose-300 shadow-2xs'
                                : 'bg-white border-[#FCE4EC] hover:border-[#E57390]/50 shadow-2xs'
                            }`}
                          >
                            {/* Card Header */}
                            <div className="flex items-center justify-between mb-2.5 pb-1.5 border-b border-[#FCE4EC]/70 flex-wrap gap-2">
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-[#FFF0F4] text-[#832F47] text-[10px] font-bold flex items-center justify-center border border-[#FCE4EC]">
                                  {index + 1}
                                </span>
                                <span className="font-bold text-xs text-[#3B252E]">
                                  {isAr ? `الخيار #${index + 1}` : `Variant #${index + 1}`}
                                </span>
                                {isDuplicate && (
                                  <span className="text-[10px] font-bold text-rose-600 bg-rose-100/90 px-2 py-0.5 rounded-full flex items-center gap-1">
                                    <AlertTriangle className="w-3 h-3 text-rose-600" />
                                    <span>{isAr ? 'تركيبة مكررة!' : 'Duplicate combination!'}</span>
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-3">
                                {/* Available Checkbox */}
                                <label className="flex items-center gap-1.5 cursor-pointer select-none text-xs">
                                  <input
                                    type="checkbox"
                                    checked={variant.available !== false}
                                    onChange={(e) =>
                                      handleUpdateVariant(variant.id, 'available', e.target.checked)
                                    }
                                    className="w-4 h-4 rounded-md accent-[#E57390] text-[#E57390] focus:ring-[#E57390] cursor-pointer"
                                  />
                                  <span
                                    className={`font-semibold text-xs ${
                                      variant.available !== false
                                        ? 'text-emerald-700'
                                        : 'text-stone-400 line-through'
                                    }`}
                                  >
                                    {variant.available !== false
                                      ? isAr
                                        ? 'متوفر'
                                        : 'Available'
                                      : isAr
                                      ? 'غير متوفر'
                                      : 'Unavailable'}
                                  </span>
                                </label>

                                {/* Delete Variant Trash Button */}
                                <button
                                  type="button"
                                  onClick={() => handleDeleteVariant(variant.id)}
                                  className="p-1 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                  title={isAr ? 'حذف هذا الخيار' : 'Delete variant'}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* 4 Responsive Input Fields */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                              {/* SIZE (EN) */}
                              <div>
                                <label className="block text-[11px] font-bold text-[#832F47] uppercase tracking-wider mb-1">
                                  {isAr ? 'المقاس SIZE (EN)' : 'SIZE (EN)'}
                                </label>
                                <input
                                  type="text"
                                  value={variant.sizeEn}
                                  onChange={(e) =>
                                    handleUpdateVariant(variant.id, 'sizeEn', e.target.value)
                                  }
                                  placeholder="e.g. 5, 14, Small"
                                  className="w-full px-3 py-2 text-xs bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-medium"
                                />
                              </div>

                              {/* COLOR (EN) */}
                              <div>
                                <label className="block text-[11px] font-bold text-[#832F47] uppercase tracking-wider mb-1">
                                  {isAr ? 'اللون COLOR (EN)' : 'COLOR (EN)'}
                                </label>
                                <input
                                  type="text"
                                  value={variant.colorEn}
                                  onChange={(e) =>
                                    handleUpdateVariant(variant.id, 'colorEn', e.target.value)
                                  }
                                  placeholder="e.g. Gold, Silver, Pink"
                                  className="w-full px-3 py-2 text-xs bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-medium"
                                />
                              </div>

                              {/* SIZE (AR) */}
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[11px] font-bold text-[#832F47] uppercase tracking-wider">
                                    {isAr ? 'المقاس SIZE (AR)' : 'SIZE (AR)'}
                                  </label>
                                  {variant.sizeArManual ? (
                                    <button
                                      type="button"
                                      onClick={() => handleRegenerateVariantField(variant.id, 'size')}
                                      className="text-[9px] text-[#E57390] hover:text-[#832F47] hover:underline font-medium cursor-pointer"
                                      title={isAr ? 'إعادة التوليد التلقائي' : 'Regenerate automatically'}
                                    >
                                      {isAr ? 'تعديل يدوي (توليد ↺)' : 'Manual (Reset ↺)'}
                                    </button>
                                  ) : variant.sizeAr ? (
                                    <span className="text-[9px] text-emerald-600 font-medium">
                                      {isAr ? 'تلقائي' : 'Auto'}
                                    </span>
                                  ) : null}
                                </div>
                                <input
                                  type="text"
                                  value={variant.sizeAr}
                                  onChange={(e) =>
                                    handleUpdateVariant(variant.id, 'sizeAr', e.target.value)
                                  }
                                  placeholder={isAr ? 'مثال: ٥، ١٤، صغير' : 'e.g. ٥, ١٤, صغير'}
                                  className="w-full px-3 py-2 text-xs bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-medium"
                                />
                              </div>

                              {/* COLOR (AR) */}
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <label className="block text-[11px] font-bold text-[#832F47] uppercase tracking-wider">
                                    {isAr ? 'اللون COLOR (AR)' : 'COLOR (AR)'}
                                  </label>
                                  {variant.colorArManual ? (
                                    <button
                                      type="button"
                                      onClick={() => handleRegenerateVariantField(variant.id, 'color')}
                                      className="text-[9px] text-[#E57390] hover:text-[#832F47] hover:underline font-medium cursor-pointer"
                                      title={isAr ? 'إعادة التوليد التلقائي' : 'Regenerate automatically'}
                                    >
                                      {isAr ? 'تعديل يدوي (توليد ↺)' : 'Manual (Reset ↺)'}
                                    </button>
                                  ) : variant.colorAr ? (
                                    <span className="text-[9px] text-emerald-600 font-medium">
                                      {isAr ? 'تلقائي' : 'Auto'}
                                    </span>
                                  ) : null}
                                </div>
                                <input
                                  type="text"
                                  value={variant.colorAr}
                                  onChange={(e) =>
                                    handleUpdateVariant(variant.id, 'colorAr', e.target.value)
                                  }
                                  placeholder={isAr ? 'مثال: ذهبي، فضي، وردي' : 'e.g. ذهبي, فضي'}
                                  className="w-full px-3 py-2 text-xs bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] font-medium"
                                />
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsBestSeller}
                      onChange={(e) => setFormIsBestSeller(e.target.checked)}
                      className="w-4 h-4 accent-[#E57390]"
                    />
                    <span className="font-semibold text-[#3B252E]">
                      {isAr ? 'تمييز كأكثر مبيعاً' : 'Mark as Best Seller'}
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsNewArrival}
                      onChange={(e) => setFormIsNewArrival(e.target.checked)}
                      className="w-4 h-4 accent-[#E57390]"
                    />
                    <span className="font-semibold text-[#3B252E]">
                      {isAr ? 'تمييز كوصلنا حديثاً' : 'Mark as New Arrival'}
                    </span>
                  </label>
                </div>
              </div>

              {/* Sticky Footer Bar */}
              <div className="p-3 sm:p-4 bg-white border-t border-[#FCE4EC] flex items-center justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCloseProductModal}
                  className="px-4 py-2.5 text-stone-500 font-semibold hover:text-stone-800 transition-colors min-h-[44px] cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-bold tracking-wider uppercase rounded-full shadow-xs transition-colors min-h-[44px] cursor-pointer"
                >
                  {editingProduct
                    ? isAr
                      ? 'حفظ التعديلات'
                      : 'Save Changes'
                    : isAr
                    ? 'إضافة القطعة للكتالوج'
                    : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* DELETE PRODUCT CONFIRMATION MODAL (SAFE FOR ANDROID APK)  */}
      {/* ========================================================= */}
      {productToDelete && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
          dir={isAr ? 'rtl' : 'ltr'}
        >
          <div className="bg-white w-full max-w-sm rounded-3xl p-5 sm:p-6 border border-[#FCE4EC] shadow-2xl text-center space-y-4 my-auto">
            <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 mx-auto flex items-center justify-center border border-rose-100">
              <AlertTriangle className="w-7 h-7 text-rose-600" />
            </div>

            <div>
              <h3 className="font-serif text-base sm:text-lg font-bold text-[#3B252E]">
                {isAr ? 'تأكيد حذف القطعة' : 'Confirm Delete Product'}
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                {isAr
                  ? `هل أنتِ متأكدة من حذف "${productToDelete.arabicName || productToDelete.name}" نهائياً من كتالوج المتجر؟`
                  : `Are you sure you want to delete "${productToDelete.name}" from the store catalog?`}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="flex-1 py-3 rounded-xl border border-stone-200 text-stone-600 font-semibold text-xs hover:bg-stone-50 transition-colors min-h-[44px] cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={confirmDeleteProduct}
                className="flex-1 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-colors shadow-xs min-h-[44px] cursor-pointer"
              >
                {isAr ? 'حذف نهائياً' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
