import React from 'react';
import { ShieldCheck, Droplets, Sparkles, Clock, Truck, Award } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export const TrustBadges: React.FC = () => {
  const { language, t, settings } = useStore();
  const isAr = language === 'ar';

  const homeRate = settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2;
  const officeRate = settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1;

  const badges = [
    {
      icon: <Award className="w-5 h-5 text-[#C5A059]" />,
      title: isAr ? 'صياغة متقنة ومختبرة' : 'Premium Craftsmanship',
      desc: isAr ? 'بريق يدوم طويلاً بعناية فائقة' : 'Long-lasting handcrafted luster',
    },
    {
      icon: <Droplets className="w-5 h-5 text-[#E57390]" />,
      title: isAr ? 'مقاوم للماء' : 'Water Resistant',
      desc: isAr ? 'لا يتأثر بالماء أو العرق' : 'Sweat & moisture proof wear',
    },
    {
      icon: <Sparkles className="w-5 h-5 text-[#C5A059]" />,
      title: isAr ? 'مقاوم لتغير اللون' : 'Color Resistant',
      desc: isAr ? 'طلاء ميكرو بالذهب عيار 18' : 'Triple 18K gold micro-coating',
    },
    {
      icon: <Clock className="w-5 h-5 text-[#832F47]" />,
      title: isAr ? 'للاستخدام اليومي' : 'Everyday Wear',
      desc: isAr ? 'ستانلس ستيل طبي لا يصدأ' : 'Tarnish-free stainless steel',
    },
    {
      icon: <Truck className="w-5 h-5 text-[#C5A059]" />,
      title: isAr ? 'توصيل سريع في عُمان' : 'Fast Oman Delivery',
      desc: isAr ? `للمنزل (${homeRate} ر.ع.) / للمكتب (${officeRate} ر.ع.)` : `Home (${homeRate} OMR) / Office (${officeRate} OMR)`,
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-[#E57390]" />,
      title: isAr ? 'آمن ولطيف للبشرة' : 'Hypoallergenic',
      desc: isAr ? 'خالٍ تماماً من النيكل والرصاص' : '100% Nickel & Lead safe',
    },
  ];

  return (
    <div className="py-4">
      <div className="bg-white rounded-3xl border border-[#FCE4EC] p-5 sm:p-6 subtle-card-shadow">
        <div className="text-center max-w-md mx-auto mb-5">
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
            {t('lastellaPromise')}
          </span>
          <h3 className="font-serif text-lg sm:text-xl font-bold text-[#3B252E] mt-0.5">
            {isAr ? 'مجوهرات صُممت لتدوم وترافقكِ كل يوم' : 'Jewelry Crafted to Endure'}
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {badges.map((badge, idx) => (
            <div
              key={idx}
              className="bg-[#FFF8FA] p-3 rounded-2xl border border-[#FCE4EC] flex flex-col items-center text-center group hover:bg-white hover:border-[#F8BBD0] transition-all"
            >
              <div className="w-10 h-10 rounded-full bg-white shadow-xs border border-[#FCE4EC] group-hover:bg-[#FDE7ED] flex items-center justify-center mb-2 transition-colors">
                {badge.icon}
              </div>
              <h4 className="text-xs font-bold text-[#3B252E] tracking-tight mb-0.5">
                {badge.title}
              </h4>
              <p className="text-[10px] text-stone-500 leading-tight">{badge.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
