import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Sparkles, ChevronLeft, ChevronRight, ArrowRight, ArrowLeft } from 'lucide-react';
import { ProductCategory } from '../../types';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

export const HeroBanner: React.FC = () => {
  const { banners, setSelectedCategory, setCurrentTab, language, t } = useStore();
  const [currentIndex, setCurrentIndex] = useState(0);

  const isAr = language === 'ar';
  const bannerList = banners && banners.length > 0 ? banners : [];

  useEffect(() => {
    if (bannerList.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % bannerList.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [bannerList.length]);

  if (bannerList.length === 0) return null;

  const current = bannerList[currentIndex] || bannerList[0];

  const handleCta = () => {
    if (current.categoryLink) {
      setSelectedCategory(current.categoryLink as ProductCategory);
      setCurrentTab('categories');
    } else {
      setSelectedCategory('New Arrivals');
      setCurrentTab('categories');
    }
  };

  const title = isAr
    ? (currentIndex === 0 ? 'بريق يدوم وأناقة لا تنتهي' : 'أطقم هدايا ملكية فاخرة')
    : (current.title || 'Timeless Elegance');

  const subtitle = isAr
    ? (currentIndex === 0 ? 'مجوهرات عصرية مقاومة للماء ومطلية بالذهب عيار 18 وتوصيل سريع في عُمان' : 'اكتشفي علب الهدايا المخملية مع إضاءة LED وأطقم المناسبات الراقية')
    : (current.subtitle || 'Discover Your Perfect Jewelry');

  const tagline = isAr ? 'مجوهرات لاستيلا سلطنة عُمان' : (current.tagline || 'LASTELLA JEWELRY OMAN');

  return (
    <div className="relative w-full rounded-3xl overflow-hidden shadow-xs border border-[#FCE4EC] bg-[#FFF0F4]">
      {/* Background Image with Luxury Tint */}
      <div className="relative h-[340px] sm:h-[400px] md:h-[440px] w-full overflow-hidden">
        <img
          src={getOptimizedImageUrl(current.imageUrl, 800, 'auto', 'fill')}
          alt={title}
          className="w-full h-full object-cover object-center transition-all duration-700 scale-105"
          loading="eager"
          decoding="async"
          fetchPriority="high"
        />
        {/* Soft Pink to Luminous Rose Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#2D161F]/90 via-[#2D161F]/40 to-transparent" />
        <div className={`absolute inset-0 ${isAr ? 'bg-gradient-to-l from-[#2D161F]/70' : 'bg-gradient-to-r from-[#2D161F]/70'} via-transparent to-transparent`} />

        {/* Floating Tag in soft pink pill */}
        {current.badge && (
          <div className="absolute top-4 start-4 z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/95 backdrop-blur-md text-[#832F47] text-[11px] font-bold tracking-wider uppercase border border-[#FCE4EC] shadow-xs">
              <Sparkles className="w-3 h-3 text-[#C5A059]" />
              {isAr ? (currentIndex === 0 ? 'تشكيلة العيد والأعراس' : 'عرض مميز') : current.badge}
            </span>
          </div>
        )}

        {/* Content Container */}
        <div className="absolute inset-0 z-10 flex flex-col justify-end p-4 sm:p-10 max-w-xl text-white text-start">
          <span className="text-[10px] sm:text-xs uppercase tracking-[0.2em] text-[#FDE7ED] font-semibold mb-1 truncate">
            {tagline}
          </span>

          <h2 className="font-serif text-xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight mb-1.5 drop-shadow-xs">
            {title}
          </h2>

          <p className="text-xs sm:text-base text-[#FFF0F4]/90 font-light max-w-md mb-3 sm:mb-6 leading-relaxed line-clamp-2 sm:line-clamp-none">
            {subtitle}
          </p>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <button
              id="btn-hero-shop-now"
              onClick={handleCta}
              className="px-4 sm:px-6 py-2.5 sm:py-3 rounded-full bg-white hover:bg-[#FFF5F7] text-[#832F47] font-bold text-xs sm:text-sm tracking-wider uppercase shadow-md active:scale-95 transition-all flex items-center gap-2 border border-[#FCE4EC] min-h-[40px]"
            >
              <span>{t('shopNow')}</span>
              {isAr ? <ArrowLeft className="w-4 h-4 text-[#832F47]" /> : <ArrowRight className="w-4 h-4 text-[#832F47]" />}
            </button>

            <button
              onClick={() => {
                setSelectedCategory('Brand Boxes');
                setCurrentTab('categories');
              }}
              className="px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-full bg-white/20 backdrop-blur-md text-white border border-white/40 font-semibold text-xs sm:text-sm tracking-wide hover:bg-white/30 active:scale-95 transition-all min-h-[40px]"
            >
              {isAr ? 'علب الهدايا 🎁' : 'Gift Boxes 🎁'}
            </button>
          </div>
        </div>

        {/* Slider Controls */}
        {bannerList.length > 1 && (
          <>
            <button
              onClick={() =>
                setCurrentIndex((prev) => (prev === 0 ? bannerList.length - 1 : prev - 1))
              }
              className="absolute start-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/20 hover:bg-black/40 text-white backdrop-blur-xs transition-colors z-20"
              aria-label="Previous Slide"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentIndex((prev) => (prev + 1) % bannerList.length)}
              className="absolute end-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/20 hover:bg-black/40 text-white backdrop-blur-xs transition-colors z-20"
              aria-label="Next Slide"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Indicator Dots */}
            <div className="absolute bottom-4 end-6 z-20 flex items-center gap-1.5">
              {bannerList.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`h-1.5 rounded-full transition-all ${
                    currentIndex === i ? 'w-6 bg-[#EFA8BA]' : 'w-1.5 bg-white/50'
                  }`}
                  aria-label={`Slide ${i + 1}`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
