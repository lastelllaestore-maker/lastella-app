import React, { useEffect, useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  CheckCircle,
  MessageCircle,
  Package,
  Clock,
  Truck,
  Sparkles,
  X,
  MapPin,
  Landmark,
  Copy,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { OrderStatus } from '../../types';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

interface OrderSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({ isOpen, onClose }) => {
  const {
    lastPlacedOrder,
    formatOMR,
    setCurrentTab,
    generateWhatsAppOrderUrl,
    setActiveTrackingOrder,
    language,
    t,
    settings,
  } = useStore();

  const isAr = language === 'ar';
  const [copiedAcc, setCopiedAcc] = useState(false);

  useEffect(() => {
    if (isOpen) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#E57390', '#C5A059', '#FCE4EC', '#F48FB1', '#25D366'],
        });
      } catch {
        // Ignored
      }
    }
  }, [isOpen]);

  if (!isOpen || !lastPlacedOrder) return null;

  const order = lastPlacedOrder;

  const statusSteps: { status: OrderStatus; label: string; icon: any }[] = [
    {
      status: 'Order Placed',
      label: isAr ? 'تم الاستلام' : 'Order Placed',
      icon: Clock,
    },
    {
      status: 'Order Confirmed',
      label: isAr ? 'تم التأكيد' : 'Confirmed',
      icon: CheckCircle,
    },
    {
      status: 'Preparing',
      label: isAr ? 'قيد التجهيز' : 'Preparing',
      icon: Package,
    },
    {
      status: 'Out for Delivery',
      label: isAr ? 'جاري التوصيل' : 'Out for Delivery',
      icon: Truck,
    },
    {
      status: 'Delivered',
      label: isAr ? 'تم التوصيل' : 'Delivered',
      icon: Sparkles,
    },
  ];

  const getStepIndex = (s: OrderStatus) => {
    switch (s) {
      case 'Order Placed':
        return 0;
      case 'Order Confirmed':
        return 1;
      case 'Preparing':
        return 2;
      case 'Out for Delivery':
        return 3;
      case 'Delivered':
        return 4;
      default:
        return 0;
    }
  };

  const currentStepIdx = getStepIndex(order.status);

  const getStatusLabel = (s: OrderStatus) => {
    switch (s) {
      case 'Order Placed':
        return isAr ? 'تم استلام الطلب' : 'Order Placed';
      case 'Order Confirmed':
        return isAr ? 'تم التأكيد' : 'Order Confirmed';
      case 'Preparing':
        return isAr ? 'قيد التجهيز والتغليف' : 'Preparing';
      case 'Out for Delivery':
        return isAr ? 'خرج للتوصيل' : 'Out for Delivery';
      case 'Delivered':
        return isAr ? 'تم التوصيل بنجاح' : 'Delivered';
      case 'Cancelled':
        return isAr ? 'تم إلغاء الطلب' : 'Cancelled';
      default:
        return s;
    }
  };

  const handleTrackInAccount = () => {
    setActiveTrackingOrder(order);
    setCurrentTab('account');
    onClose();
  };

  const handleSendWhatsAppReceipt = () => {
    const customer = order.customer || ({} as any);
    const customerName = customer.name || (order as any).customerName || (isAr ? 'زبونة لاستيلا' : 'LASTELLA Customer');
    const customerPhone = customer.phone || (order as any).phone || '';
    const fullDeliveryAddr = customer.city
      ? `${customer.city}, ${customer.area || ''}, ${customer.detailedAddress || customer.address || ''}`
      : customer.area
      ? `${customer.address || ''}, ${customer.area}${customer.governorate ? `, ${customer.governorate}` : ''}`
      : customer.address || (order as any).address || (isAr ? 'العنوان غير محدد' : 'Address not specified');

    const url = generateWhatsAppOrderUrl({
      customerName,
      phone: customerPhone,
      items: order.items,
      subtotal: order.subtotal,
      delivery: order.deliveryCharge,
      deliveryMethod: order.deliveryMethod,
      total: order.total,
      deliveryAddress: fullDeliveryAddr,
      city: customer.city,
      area: customer.area,
      detailedAddress: customer.detailedAddress || customer.address,
      notes: isAr
        ? `طلب رقم #${order.orderNumber} من التطبيق.`
        : `Order #${order.orderNumber} placed in app.`,
    });
    window.open(url, '_blank');
  };

  const displayName = (order.customer?.name || (order as any).customerName || (isAr ? 'عزيزتي' : 'Valued Customer')).split(' ')[0];

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-br from-[#FFF0F4] via-[#FFF9FB] to-[#FCE4EC] text-center relative border-b border-[#FCE4EC]">
          <button
            onClick={onClose}
            className="absolute top-4 end-4 p-1.5 rounded-full text-stone-400 hover:text-stone-700 bg-white/80"
            title={t('gotItClose')}
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-full bg-emerald-500 text-white mx-auto flex items-center justify-center shadow-lg mb-3">
            <CheckCircle className="w-8 h-8 stroke-[2.5px]" />
          </div>

          <span className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059] font-bold">
            {isAr ? 'تم تأكيد طلبكِ بنجاح' : 'ORDER CONFIRMED'}
          </span>
          <h3 className="font-serif text-2xl font-bold text-[#3B252E] mt-0.5">
            {isAr ? `شكراً لكِ، ${displayName}!` : `Thank You, ${displayName}!`}
          </h3>
          <p className="text-xs text-stone-600 mt-1">
            {isAr ? (
              <>
                تم استلام طلبكِ رقم{' '}
                <span className="font-bold text-[#832F47]">#{order.orderNumber}</span> وجاري تجهيزه
                وتغليفه بكل حب في مسقط.
              </>
            ) : (
              <>
                Order <span className="font-bold text-[#832F47]">#{order.orderNumber}</span> has
                been received and is being prepared with love in Muscat.
              </>
            )}
          </p>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-5">
          {/* Order Status Stepper */}
          <div className="bg-[#FFF0F4] rounded-2xl p-4 border border-[#FCE4EC] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#832F47] uppercase tracking-wider">
                {isAr ? 'حالة الطلب الحالية:' : 'CURRENT STATUS:'}
              </span>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                {getStatusLabel(order.status)}
              </span>
            </div>

            {/* Stepper Progress */}
            <div className="pt-2">
              <div className="relative flex items-center justify-between">
                {/* Connecting line */}
                <div className="absolute left-4 right-4 top-4 h-0.5 bg-[#FCE4EC] -z-0" />
                <div
                  className="absolute left-4 top-4 h-0.5 bg-[#E57390] -z-0 transition-all duration-500"
                  style={{
                    width: `${(currentStepIdx / (statusSteps.length - 1)) * 90}%`,
                  }}
                />

                {statusSteps.map((step, idx) => {
                  const isDone = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;
                  const Icon = step.icon;

                  return (
                    <div key={step.status} className="flex flex-col items-center relative z-10">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                          isDone
                            ? 'bg-[#E57390] text-white shadow-xs'
                            : 'bg-white text-stone-400 border border-[#FCE4EC]'
                        } ${isCurrent ? 'ring-4 ring-[#FFF0F4] scale-110' : ''}`}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <span
                        className={`text-[9px] mt-1.5 font-bold tracking-tight text-center max-w-[60px] leading-tight ${
                          isDone ? 'text-[#832F47]' : 'text-stone-400'
                        }`}
                      >
                        {step.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Delivery Details */}
          <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-2 text-xs shadow-2xs">
            <h4 className="font-bold text-[#3B252E] flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#C5A059]" />{' '}
              <span>{isAr ? 'وجهة وعنوان التوصيل' : 'Delivery Destination'}</span>
            </h4>
            <div className="text-stone-600 ps-5 space-y-1 text-[11px]">
              <p className="font-semibold text-stone-900">
                {order.customer?.name || (order as any).customerName || (isAr ? 'زبونة لاستيلا' : 'LASTELLA Customer')}
              </p>
              {(order.customer?.phone || (order as any).phone) && (
                <p>{order.customer?.phone || (order as any).phone}</p>
              )}
              {order.customer?.city ? (
                <>
                  <p className="font-semibold text-[#832F47]">
                    {order.customer.city} — {order.customer.area}
                  </p>
                  <p className="text-stone-700 leading-relaxed whitespace-pre-line bg-[#FFF9FB] p-2 rounded-xl border border-[#FDE7ED]">
                    {order.customer.detailedAddress || order.customer.address}
                  </p>
                </>
              ) : (order.customer?.area || order.customer?.address) ? (
                <>
                  <p className="font-semibold text-[#832F47]">
                    {order.customer?.area}{order.customer?.governorate ? `، ${order.customer.governorate}` : ''}
                  </p>
                  <p className="text-stone-700 leading-relaxed">
                    {order.customer?.address}
                  </p>
                </>
              ) : (
                <p className="text-stone-500 italic">
                  {(order as any).address || (isAr ? 'العنوان غير محدد' : 'Address not specified')}
                </p>
              )}
            </div>
          </div>

          {/* Items Summary */}
          <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-2 text-xs shadow-2xs">
            <h4 className="font-bold text-[#3B252E] mb-1">
              {isAr ? `القطع المطلوبة (${order.items?.length || 0})` : `Purchased Items (${order.items?.length || 0})`}
            </h4>
            <div className="divide-y divide-[#FDE7ED]">
              {(order.items || []).map((item, idx) => {
                const itemDisplayName =
                  isAr && item.product?.arabicName ? item.product.arabicName : item.product?.name || (item as any).name || (isAr ? 'قطعة مجوهرات' : 'Jewelry Item');

                return (
                  <div key={idx} className="py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={getOptimizedImageUrl(item.product?.images?.[0] || '/icon.svg', 100, 'auto', 'fit')}
                        alt={itemDisplayName}
                        className="w-10 h-10 rounded-lg object-cover bg-[#FFF0F4]"
                        loading="eager"
                        decoding="async"
                        width={40}
                        height={40}
                      />
                      <div>
                        <p className="font-semibold text-[#3B252E] line-clamp-1">{itemDisplayName}</p>
                        <p className="text-[10px] text-stone-400">
                          {isAr ? 'الكمية: ' : 'Qty: '}
                          {item.quantity}{' '}
                          {item.selectedSize
                            ? `• ${isAr ? 'المقاس: ' : 'Size: '}${item.selectedSize} `
                            : ''}
                          {item.selectedColor
                            ? `• ${isAr ? 'اللون: ' : 'Color: '}${
                                item.selectedColor === 'Gold'
                                  ? isAr
                                    ? 'ذهبي'
                                    : 'Gold'
                                  : item.selectedColor === 'Silver'
                                  ? isAr
                                    ? 'فضي'
                                    : 'Silver'
                                  : item.selectedColor
                              }`
                            : ''}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-[#832F47]">
                      {formatOMR(item.product.price * item.quantity)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Total */}
            <div className="pt-2 border-t border-[#FDE7ED] space-y-1 text-xs">
              <div className="flex justify-between text-stone-500">
                <span>{t('subtotal')}:</span>
                <span>{formatOMR(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-stone-500">
                <span>
                  {t('deliveryCharge')} (
                  {order.deliveryMethod === 'office'
                    ? isAr
                      ? 'استلام من المكتب'
                      : 'Office Delivery'
                    : isAr
                    ? 'توصيل للمنزل'
                    : 'Home Delivery'}
                  ):
                </span>
                <span>{formatOMR(order.deliveryCharge)}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-[#3B252E] pt-1">
                <span>{t('total')}:</span>
                <span className="text-[#832F47] font-brand">{formatOMR(order.total)}</span>
              </div>
            </div>
          </div>

          {/* Bank Transfer Payment Instructions Card */}
          <div className="bg-[#FFF0F4] rounded-2xl border-2 border-[#E57390] p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#FCE4EC] pb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-white border border-[#FCE4EC] flex items-center justify-center text-[#832F47] shadow-2xs">
                  <Landmark className="w-3.5 h-3.5 text-[#832F47]" />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-[#3B252E]">
                    {settings.bankName || 'Bank Muscat (بنك مسقط)'}
                  </h5>
                  <p className="text-[10px] text-stone-500">
                    {isAr ? 'بيانات التحويل البنكي لإتمام الطلب' : 'Bank Transfer Payment Details'}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                {isAr ? 'بانتظار التحويل' : 'Pending Payment'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC]">
                <span className="text-[10px] text-stone-400 block font-medium">
                  {isAr ? 'اسم الحساب:' : 'Account Name:'}
                </span>
                <span className="font-bold text-[#3B252E] text-xs">
                  {settings.accountName || 'LASTELLA JEWELRY'}
                </span>
              </div>

              {settings.accountNumber && (
                <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-stone-400 block font-medium">
                      {isAr ? 'رقم الحساب:' : 'Account Number:'}
                    </span>
                    <span className="font-mono font-bold text-[#832F47] text-xs">
                      {settings.accountNumber}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(settings.accountNumber || '');
                      setCopiedAcc(true);
                      setTimeout(() => setCopiedAcc(false), 2000);
                    }}
                    className="p-1 rounded-lg bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] transition-all cursor-pointer"
                    title={isAr ? 'نسخ رقم الحساب' : 'Copy account number'}
                  >
                    {copiedAcc ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              )}

              {settings.bankIban && (
                <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC] sm:col-span-2">
                  <span className="text-[10px] text-stone-400 block font-medium">
                    {isAr ? 'رقم الآيبان (IBAN):' : 'IBAN:'}
                  </span>
                  <span className="font-mono font-bold text-[#832F47] text-xs break-all">
                    {settings.bankIban}
                  </span>
                </div>
              )}
            </div>

            <div className="bg-white/80 p-2.5 rounded-xl border border-[#FCE4EC] text-[11px] leading-relaxed text-stone-600">
              <p className="font-semibold text-[#832F47] mb-0.5">
                {isAr ? '📌 ملاحظات التحويل:' : '📌 Payment Instructions:'}
              </p>
              <p>
                {isAr
                  ? (settings.bankTransferInstructionsAr || 'يرجى تحويل مبلغ الطلب بدقة إلى الحساب البنكي، مع كتابة رقم الطلب في خانة الملاحظات/الوصف عند التحويل.')
                  : (settings.bankTransferInstructions || 'Please transfer the exact order amount to our bank account. Include your Order Number in the remarks.')}
              </p>
              <p className="mt-1 font-semibold text-[#3B252E]">
                {isAr
                  ? `المبلغ المطلوب تحويله: ${formatOMR(order.total)} • رقم الملاحظة: #${order.orderNumber}`
                  : `Amount to Transfer: ${formatOMR(order.total)} • Reference: #${order.orderNumber}`}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-1">
            <button
              onClick={handleSendWhatsAppReceipt}
              className="w-full py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20BE5C] text-white font-bold text-xs sm:text-sm tracking-wide shadow-xs active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>{isAr ? 'إرسال الإيصال / التواصل عبر الواتساب' : 'Send Receipt / Chat on WhatsApp'}</span>
            </button>

            <button
              onClick={handleTrackInAccount}
              className="w-full py-3 px-4 rounded-2xl bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] font-bold text-xs border border-[#FCE4EC] active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Truck className="w-4 h-4" />
              <span>{isAr ? 'متابعة وتتبع الطلب في حسابي' : 'Track Live in My Orders'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
