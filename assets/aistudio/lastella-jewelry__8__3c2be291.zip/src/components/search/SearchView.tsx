import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../common/ProductCard';
import { ProductListingContainer } from '../common/ProductListingContainer';
import { Search, X, Clock, Sparkles } from 'lucide-react';
import { getCategoryTranslation } from '../../i18n/translations';

export const SearchView: React.FC = () => {
  const {
    products,
    searchQuery,
    setSearchQuery,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    language,
    t,
  } = useStore();

  const isAr = language === 'ar';
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');
  const [maxPrice, setMaxPrice] = useState<number>(10);
  const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);

  // Debounce search query changes by 150ms on mobile keyboards to avoid main-thread jank
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 150);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const searchSuggestions = isAr
    ? ['خاتم', 'سوليتير', 'عقد', 'لؤلؤ', 'إسوارة', 'زمرد', 'طقم مجوهرات', 'علبة هدية', 'باقة', 'ذهب']
    : [
        'Ring',
        'Solitaire',
        'Necklace',
        'Pearl',
        'Bracelet',
        'Emerald',
        'Jewelry Set',
        'Gift Box',
        'Combo',
        'Gold',
      ];

  const handleQueryChange = (text: string) => {
    setSearchQuery(text);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      addRecentSearch(searchQuery.trim());
    }
  };

  const handleSelectSuggestion = (tag: string) => {
    setSearchQuery(tag);
    addRecentSearch(tag);
  };

  // Filter products by search term, category, and price
  const searchResults = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();

    return products.filter((p) => {
      if (!p) return false;

      const matchesText =
        !q ||
        (p.name && p.name.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q)) ||
        (p.materials && p.materials.toLowerCase().includes(q)) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.arabicName && p.arabicName.toLowerCase().includes(q)) ||
        (p.arabicDescription && p.arabicDescription.toLowerCase().includes(q)) ||
        (p.arabicMaterials && p.arabicMaterials.toLowerCase().includes(q)) ||
        (p.sku && p.sku.toLowerCase().includes(q)) ||
        (Array.isArray(p.variants) &&
          p.variants.some(
            (v) =>
              (v.sizeEn && v.sizeEn.toLowerCase().includes(q)) ||
              (v.sizeAr && v.sizeAr.toLowerCase().includes(q)) ||
              (v.colorEn && v.colorEn.toLowerCase().includes(q)) ||
              (v.colorAr && v.colorAr.toLowerCase().includes(q))
          ));

      const matchesCategory =
        selectedCategoryFilter === 'All'
          ? true
          : selectedCategoryFilter === 'New Arrivals'
          ? !!p.isNewArrival
          : selectedCategoryFilter === 'Best Selling'
          ? !!p.isBestSeller
          : p.category === selectedCategoryFilter;

      const matchesPrice = typeof p.price === 'number' ? p.price <= maxPrice : true;

      return Boolean(matchesText && matchesCategory && matchesPrice);
    });
  }, [products, debouncedQuery, selectedCategoryFilter, maxPrice]);

  return (
    <div
      className="space-y-5 pb-16 animate-in fade-in duration-200 text-start"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Search Input Box */}
      <form
        onSubmit={handleSearchSubmit}
        className="relative bg-white rounded-3xl p-3 border border-[#FCE4EC] subtle-card-shadow flex items-center gap-3"
      >
        <Search className="w-5 h-5 text-[#E57390] mx-2 shrink-0" />
        <input
          id="search-main-input"
          type="text"
          value={searchQuery}
          onChange={(e) => handleQueryChange(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full text-xs sm:text-sm text-[#3B252E] placeholder:text-stone-400 bg-transparent focus:outline-hidden"
          autoFocus
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </form>

      {/* Suggestions & Recent Searches when not searching or as quick tags */}
      {!searchQuery && (
        <div className="space-y-4">
          {/* Quick Suggestions */}
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold flex items-center gap-1 mb-2">
              <Sparkles className="w-3 h-3 text-[#C5A059]" /> {isAr ? 'الأكثر بحثاً' : 'POPULAR SEARCHES'}
            </span>
            <div className="flex items-center gap-2 flex-wrap">
              {searchSuggestions.map((tag) => (
                <button
                  key={tag}
                  id={`search-sugg-${tag.toLowerCase()}`}
                  onClick={() => handleSelectSuggestion(tag)}
                  className="px-3 py-1.5 bg-white hover:bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC] hover:border-[#F8BBD0] rounded-full text-xs font-semibold transition-all active:scale-95 shadow-2xs"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-[0.2em] text-stone-500 font-bold flex items-center gap-1">
                  <Clock className="w-3 h-3 text-stone-400" /> {isAr ? 'عمليات البحث الأخيرة' : 'RECENT SEARCHES'}
                </span>
                <button
                  onClick={clearRecentSearches}
                  className="text-[11px] text-[#832F47] font-semibold hover:underline"
                >
                  {isAr ? 'مسح السجل' : 'Clear History'}
                </button>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {recentSearches.map((rec, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectSuggestion(rec)}
                    className="px-3 py-1 bg-[#FFF0F4] hover:bg-[#FDE7ED] text-[#3B252E] text-xs rounded-full border border-[#FCE4EC] flex items-center gap-1 transition-all"
                  >
                    <span>{rec}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filter Badges Row */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {[
          'All',
          'New Arrivals',
          'Necklaces',
          'Bracelets',
          'Bangles',
          'Anklets',
          'Rings',
          'Brand Boxes',
          'Best Selling',
        ].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategoryFilter(cat)}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategoryFilter === cat
                ? 'bg-[#E57390] text-white shadow-xs'
                : 'bg-white text-stone-600 border border-[#FCE4EC] hover:bg-[#FFF0F4]'
            }`}
          >
            {cat === 'All' ? t('all') : getCategoryTranslation(cat as any, language)}
          </button>
        ))}
      </div>

      {/* Search Results Summary */}
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold text-[#3B252E]">
          {searchQuery ? `${t('resultsFor')} "${searchQuery}"` : (isAr ? 'جميع القطع المتوفرة' : 'All Available Jewelry')}
        </span>
        <span className="text-xs text-stone-500 font-medium">
          {searchResults.length} {isAr ? 'قطعة' : (searchResults.length === 1 ? 'item' : 'items')}
        </span>
      </div>

      {/* Results Grid */}
      {searchResults.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-[#FCE4EC] p-6 space-y-3">
          <div className="w-12 h-12 rounded-full bg-[#FFF0F4] text-[#E57390] mx-auto flex items-center justify-center">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-lg font-bold text-[#3B252E]">{t('noResultsFound')}</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {isAr
              ? 'جربي البحث عن "خاتم سوليتير"، "عقد لؤلؤ"، "إسوارة تنس"، أو إعادة ضبط البحث.'
              : 'Try searching for "Solitaire Ring", "Pearl", "Tennis Bracelet", or clear your filter.'}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategoryFilter('All');
            }}
            className="px-4 py-2 bg-[#E57390] text-white text-xs font-bold rounded-xl shadow-xs"
          >
            {isAr ? 'إعادة ضبط البحث' : 'Reset Search'}
          </button>
        </div>
      ) : (
        <ProductListingContainer id="search-products-grid">
          {searchResults.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      )}
    </div>
  );
};
