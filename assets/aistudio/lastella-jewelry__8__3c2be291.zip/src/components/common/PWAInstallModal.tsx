import React from 'react';
import { X, Sparkles, Share2, PlusSquare, Smartphone, CheckCircle2, Download, ArrowUpRight } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { language, showToast } = useStore();
  const { isInstalled, isInstallable, isIOS, isAndroid, triggerInstall } = usePWAInstall();
  const isAr = language === 'ar';

  if (!isOpen) return null;

  const handleNativeInstall = async () => {
    const result = await triggerInstall();
    if (result === 'accepted') {
      showToast(isAr ? 'تم تثبيت تطبيق لاستيلا بنجاح على هاتفكِ 💖' : 'LASTELLA App installed successfully 💖');
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
      onClick={onClose}
    >
      <div
        className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto relative animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Card */}
        <div className="bg-gradient-to-br from-[#FFF0F4] via-[#FCE4EC] to-[#F8BBD0] p-6 text-center border-b border-[#F8BBD0] relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 rtl:left-auto rtl:right-4 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-stone-500 hover:text-[#832F47] flex items-center justify-center transition-colors shadow-2xs cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-16 h-16 rounded-2xl bg-white shadow-md mx-auto flex items-center justify-center p-1 border border-[#FCE4EC] mb-3">
            <img
              src="/icon-192.png"
              alt="LASTELLA Logo"
              className="w-full h-full object-contain rounded-xl"
            />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#FCE4EC] text-[#832F47] text-[11px] font-bold tracking-wider uppercase mb-1.5 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>{isAr ? 'تطبيق لاستيلا الرسمي' : 'LASTELLA Official Web App'}</span>
          </div>

          <h3 className="font-serif font-extrabold text-xl text-[#832F47]">
            {isAr ? 'تثبيت تطبيق مجوهرات لاستيلا' : 'Install LASTELLA App'}
          </h3>
          <p className="text-xs text-stone-600 mt-1 max-w-xs mx-auto">
            {isAr
              ? 'تسوّقي أرقى المجوهرات الفاخرة بلمسة واحدة مباشرة من شاشة هاتفكِ بدون متجر التطبيقات'
              : 'Shop luxury jewelry with one tap directly from your home screen without the App Store'}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Case 1: Already Installed */}
          {isInstalled ? (
            <div className="bg-[#FFF0F4] border border-[#FCE4EC] rounded-2xl p-4 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-[#E57390] mx-auto" />
              <p className="font-bold text-sm text-[#832F47]">
                {isAr ? 'التطبيق مثبت بالفعل على جهازكِ! ✨' : 'The App is already installed! ✨'}
              </p>
              <p className="text-xs text-stone-600">
                {isAr
                  ? 'يمكنكِ فتح التطبيق في أي وقت مباشرة من شاشتكِ الرئيسية.'
                  : 'You can launch it anytime directly from your home screen.'}
              </p>
            </div>
          ) : isInstallable ? (
            /* Case 2: Native Android / Chromium Install Prompt */
            <div className="space-y-3">
              <div className="bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FFF0F4] flex items-center justify-center text-[#832F47] shrink-0">
                  <Smartphone className="w-5 h-5 text-[#E57390]" />
                </div>
                <div className="text-xs text-stone-600 leading-relaxed">
                  <span className="font-bold text-[#832F47] block text-sm">
                    {isAr ? 'تثبيت فوري بنقرة واحدة' : 'Instant One-Click Install'}
                  </span>
                  {isAr
                    ? 'اضغطي على الزر بالأسفل لتثبيت أيقونة لاستيلا على هاتفكِ مباشرة.'
                    : 'Tap the button below to add LASTELLA icon to your phone home screen.'}
                </div>
              </div>

              <button
                onClick={handleNativeInstall}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-[#E57390] to-[#832F47] hover:opacity-95 active:scale-98 text-white font-bold text-sm rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{isAr ? 'تثبيت التطبيق الآن على الهاتف' : 'Install App Now'}</span>
              </button>
            </div>
          ) : isIOS ? (
            /* Case 3: iPhone / iPad Safari Step-by-Step Instructions */
            <div className="space-y-3">
              <div className="bg-[#FFF0F4] border border-[#FCE4EC] rounded-xl p-3 text-xs text-[#832F47] font-semibold text-center">
                {isAr
                  ? 'خطوات التثبيت على الآيفون (عبر متصفح سفاري Safari):'
                  : 'iPhone Installation Steps (via Safari Browser):'}
              </div>

              <ol className="space-y-2.5 text-xs text-stone-700">
                <li className="flex items-start gap-2.5 p-3 rounded-2xl bg-[#FFF9FB] border border-[#FCE4EC]">
                  <span className="w-6 h-6 rounded-full bg-[#E57390] text-white flex items-center justify-center font-bold text-xs shrink-0">
                    1
                  </span>
                  <div className="leading-relaxed">
                    <span className="font-bold text-[#3B252E] block">
                      {isAr ? 'اضغطي على زر المشاركة (Share)' : 'Tap the Share Button'}
                    </span>
                    <span className="text-stone-500">
                      {isAr
                        ? 'في أسفل شاشة سفاري، اضغطي على أيقونة المشاركة مربع به سهم للأعلى: '
                        : 'At the bottom of your Safari screen, tap the share icon: '}
                    </span>
                    <span className="inline-flex items-center gap-1 font-bold text-[#832F47] bg-white px-2 py-0.5 rounded-md border border-[#FCE4EC]">
                      <Share2 className="w-3.5 h-3.5 text-[#E57390]" />
                      <span>{isAr ? 'مشاركة' : 'Share'}</span>
                    </span>
                  </div>
                </li>

                <li className="flex items-start gap-2.5 p-3 rounded-2xl bg-[#FFF9FB] border border-[#FCE4EC]">
                  <span className="w-6 h-6 rounded-full bg-[#E57390] text-white flex items-center justify-center font-bold text-xs shrink-0">
                    2
                  </span>
                  <div className="leading-relaxed">
                    <span className="font-bold text-[#3B252E] block">
                      {isAr ? 'اختاري "إضافة إلى الصفحة الرئيسية"' : 'Select "Add to Home Screen"'}
                    </span>
                    <span className="text-stone-500">
                      {isAr
                        ? 'اسحبي قائمة الخيارات للأسفل واختاري: '
                        : 'Scroll down the list of options and select: '}
                    </span>
                    <span className="inline-flex items-center gap-1 font-bold text-[#832F47] bg-white px-2 py-0.5 rounded-md border border-[#FCE4EC]">
                      <PlusSquare className="w-3.5 h-3.5 text-[#E57390]" />
                      <span>{isAr ? 'إضافة إلى الصفحة الرئيسية' : 'Add to Home Screen'}</span>
                    </span>
                  </div>
                </li>

                <li className="flex items-start gap-2.5 p-3 rounded-2xl bg-[#FFF9FB] border border-[#FCE4EC]">
                  <span className="w-6 h-6 rounded-full bg-[#E57390] text-white flex items-center justify-center font-bold text-xs shrink-0">
                    3
                  </span>
                  <div className="leading-relaxed">
                    <span className="font-bold text-[#3B252E] block">
                      {isAr ? 'اضغطي على زر "إضافة" (Add)' : 'Tap "Add" in Top Right'}
                    </span>
                    <span className="text-stone-500">
                      {isAr
                        ? 'في الزاوية العلوية، اضغطي على "إضافة" لتظهر أيقونة لاستيلا على شاشة هاتفكِ فوراً.'
                        : 'Tap Add in the top-right corner to place LASTELLA icon on your home screen.'}
                    </span>
                  </div>
                </li>
              </ol>
            </div>
          ) : (
            /* Case 4: General Browser / Desktop */
            <div className="space-y-3">
              <div className="bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl p-4 text-xs text-stone-600 space-y-2">
                <p className="font-bold text-[#832F47] text-sm">
                  {isAr ? 'كيفية التثبيت من المتصفح:' : 'How to install from browser:'}
                </p>
                <p className="leading-relaxed">
                  {isAr
                    ? 'اضغطي على خيارات المتصفح (⋮) أو أيقونة التثبيت في شريط العنوان واختاري "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".'
                    : 'Click your browser menu (⋮) or the install icon in the address bar and select "Install App" or "Add to Home Screen".'}
                </p>
              </div>

              {isAndroid && (
                <button
                  onClick={handleNativeInstall}
                  className="w-full py-3 px-4 bg-gradient-to-r from-[#E57390] to-[#832F47] text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>{isAr ? 'محاولة التثبيت' : 'Attempt Install'}</span>
                </button>
              )}
            </div>
          )}

          {/* Benefits Feature List */}
          <div className="pt-2 border-t border-[#FDE7ED] space-y-2 text-[11px] text-stone-600">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E57390] shrink-0" />
              <span>{isAr ? 'وصول فوري وسريع بلمسة واحدة' : 'Instant 1-tap access from your home screen'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E57390] shrink-0" />
              <span>{isAr ? 'تصفح خفيف ومحمي بدون استهلاك لمساحة الهاتف' : 'Lightweight and secure without taking storage'}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E57390] shrink-0" />
              <span>{isAr ? 'تحديثات مستمرة لأحدث تشكيلات المجوهرات الفاخرة' : 'Continuous updates with the newest jewelry collections'}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#FAF8F9] border-t border-[#FCE4EC] text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-stone-50 border border-stone-200 text-stone-700 font-semibold text-xs active:scale-98 transition-all cursor-pointer"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
