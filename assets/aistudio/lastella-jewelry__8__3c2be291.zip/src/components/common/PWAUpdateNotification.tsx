import React from 'react';
import { useRegisterSW } from 'virtual:pwa-register/react';
import { Sparkles, RefreshCw, X } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export const PWAUpdateNotification: React.FC = () => {
  const { language } = useStore();
  const isAr = language === 'ar';

  const {
    needRefresh: [needRefresh, setNeedRefresh],
    updateServiceWorker,
  } = useRegisterSW({
    onRegistered(r) {
      if (r) {
        // Periodically check for service worker updates (every hour)
        setInterval(() => {
          r.update().catch((err) => {
            console.debug('[PWA] Auto update check note:', err);
          });
        }, 60 * 60 * 1000);
      }
    },
    onRegisterError(error) {
      console.debug('[PWA] Service worker registration note:', error);
    },
  });

  if (!needRefresh) {
    return null;
  }

  const handleUpdate = () => {
    updateServiceWorker(true);
  };

  const handleDismiss = () => {
    setNeedRefresh(false);
  };

  return (
    <div
      role="alert"
      className="fixed bottom-20 sm:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-50 bg-white/95 backdrop-blur-md border-2 border-[#E57390] rounded-2xl shadow-xl p-4 animate-in fade-in slide-in-from-bottom-4 duration-300"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#FFF0F4] border border-[#FCE4EC] flex items-center justify-center shrink-0 text-[#832F47]">
          <Sparkles className="w-5 h-5 text-[#C5A059]" />
        </div>

        <div className="flex-1 min-w-0">
          <h4 className="font-serif font-bold text-sm text-[#832F47] flex items-center gap-1.5">
            <span>{isAr ? 'تحديث جديد متوفر لمجوهرات لاستيلا ✨' : 'New LASTELLA Update Available ✨'}</span>
          </h4>
          <p className="text-xs text-stone-600 mt-1 leading-relaxed">
            {isAr
              ? 'تتوفر نسخة جديدة ومحسنة من المتجر مع أحدث المجوهرات والميزات. اضغطي لتحديث التطبيق فوراً.'
              : 'A new enhanced version of LASTELLA is ready with the latest collections. Tap update now.'}
          </p>

          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={handleUpdate}
              className="px-4 py-1.5 bg-gradient-to-r from-[#E57390] to-[#832F47] hover:opacity-95 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{isAr ? 'تحديث الآن' : 'Update Now'}</span>
            </button>

            <button
              onClick={handleDismiss}
              className="px-3 py-1.5 bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] text-xs font-semibold rounded-xl border border-[#FCE4EC] active:scale-95 transition-all cursor-pointer"
            >
              <span>{isAr ? 'لاحقاً' : 'Later'}</span>
            </button>
          </div>
        </div>

        <button
          onClick={handleDismiss}
          className="text-stone-400 hover:text-stone-600 p-1 rounded-lg"
          aria-label="Dismiss update notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
