import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Lock } from 'lucide-react';

export const StoreFooter: React.FC = () => {
  const {
    language,
    isAdminAuthenticated,
    setIsAdminLoginOpen,
    setCurrentTab,
  } = useStore();

  const isAr = language === 'ar';

  return (
    <footer className="w-full max-w-7xl mx-auto px-4 pt-8 pb-10 text-center border-t border-[#FCE4EC] mt-8 space-y-2.5">
      <p className="text-[11px] text-stone-400 font-serif tracking-wider uppercase">
        {isAr
          ? 'بوتيك مجوهرات لاستيلا الفاخرة • مسقط، سلطنة عُمان'
          : 'LASTELLA Luxury Jewelry Boutique • Muscat, Sultanate of Oman'}
      </p>
      <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-stone-400">
        <a
          href="/privacy-policy.html"
          target="_blank"
          rel="noopener noreferrer"
          className="text-stone-500 hover:text-[#832F47] underline underline-offset-2 transition-colors"
        >
          {isAr ? 'سياسة الخصوصية' : 'Privacy Policy'}
        </a>
        <span>•</span>
        <a
          href="/terms.html"
          target="_blank"
          rel="noopener noreferrer"
          className="text-stone-500 hover:text-[#832F47] underline underline-offset-2 transition-colors"
        >
          {isAr ? 'الشروط والأحكام' : 'Terms & Conditions'}
        </a>
        <span>•</span>
        <button
          type="button"
          onClick={() => {
            if (isAdminAuthenticated) {
              setCurrentTab('admin');
            } else {
              setIsAdminLoginOpen(true);
            }
          }}
          className="text-stone-500 hover:text-[#832F47] transition-colors flex items-center gap-1 cursor-pointer font-medium"
          title={isAr ? 'تسجيل دخول مديرة المتجر' : 'Store Staff & Manager Login'}
        >
          <Lock className="w-3 h-3 text-[#C5A059]" />
          <span>{isAr ? 'بوابة الإدارة' : 'Staff Portal'}</span>
        </button>
      </div>
      <p className="text-[10px] text-stone-400/80 font-mono">
        LASTELLA App v1.0.0
      </p>
    </footer>
  );
};
