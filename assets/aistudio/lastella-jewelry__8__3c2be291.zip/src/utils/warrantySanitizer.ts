import { Product, Banner } from '../types';

/**
 * Strips 1-Year Warranty and guarantee claims (English & Arabic) from any string.
 */
export function removeWarrantyText(text?: string): string {
  if (!text) return '';

  return text
    // English variations
    .replace(/\b(1|one)[ -]?year\s+(full\s+)?(warranty|guarantee)\b/gi, '')
    .replace(/\b(with\s+)?(1|one)[ -]?year\s+(warranty|guarantee)\s*(&|and)?\s*/gi, '')
    .replace(/(&|and)\s+(1|one)[ -]?year\s+(warranty|guarantee)\b/gi, '')
    .replace(/\b(1|one)[ -]?year\s+(warranty|guarantee)\b/gi, '')
    // Arabic variations: ضمان سنة، بضمان سنة، ضمان لمدة سنة، ضمان سنة كاملة، ضمان ذهبي لمدة سنة
    .replace(/(و\s*)?ب?ضمان(\s+ذهبي)?(\s+لمدة)?\s+(سنة|عام)(\s+كاملة)?(\s*و)?/g, '')
    .replace(/ضمان\s+حقيقي\s+لجودة\s+اللون\s+واللمعان/g, 'جودة مصنعية ولمعان يدوم طويلاً')
    // Clean up leftover double spaces, leading/trailing punctuation
    .replace(/\s{2,}/g, ' ')
    .replace(/^\s*[•\-,&]\s*/, '')
    .replace(/\s*[•\-,&]\s*$/, '')
    .trim();
}

/**
 * Filter out any feature item that claims a 1-year warranty.
 */
export function filterWarrantyFeatures(features?: string[]): string[] {
  if (!Array.isArray(features)) return [];
  return features.filter((feat) => {
    if (!feat) return false;
    const lower = feat.toLowerCase();
    if (lower.includes('year') && (lower.includes('warranty') || lower.includes('guarantee'))) {
      return false;
    }
    if (feat.includes('ضمان') && (feat.includes('سنة') || feat.includes('عام'))) {
      return false;
    }
    return true;
  });
}

/**
 * Sanitizes a product object so that any legacy 1-year warranty claims stored
 * in Firestore or local storage do not render on customer-facing screens.
 */
export function sanitizeProduct(product: Product): Product {
  if (!product) return product;

  const cleanedFeatures = filterWarrantyFeatures(product.features);
  const cleanedDescription = removeWarrantyText(product.description);
  const cleanedArabicDesc = removeWarrantyText(product.arabicDescription);
  const cleanedMaterials = removeWarrantyText(product.materials);
  const cleanedArabicMaterials = removeWarrantyText(product.arabicMaterials);

  return {
    ...product,
    features: cleanedFeatures,
    description: cleanedDescription,
    arabicDescription: cleanedArabicDesc || product.arabicDescription,
    materials: cleanedMaterials || product.materials,
    arabicMaterials: cleanedArabicMaterials || product.arabicMaterials,
  };
}

/**
 * Sanitizes an array of products.
 */
export function sanitizeProducts(products: Product[]): Product[] {
  if (!Array.isArray(products)) return [];
  return products.map(sanitizeProduct);
}

/**
 * Sanitizes promotional banners to ensure no 1-year warranty badge or tagline is shown.
 */
export function sanitizeBanner(banner: Banner): Banner {
  if (!banner) return banner;

  let cleanedBadge = banner.badge ? removeWarrantyText(banner.badge) : undefined;
  if (!cleanedBadge && banner.badge && /warranty|ضمان/i.test(banner.badge)) {
    cleanedBadge = undefined;
  }

  return {
    ...banner,
    badge: cleanedBadge,
    title: removeWarrantyText(banner.title) || banner.title,
    subtitle: removeWarrantyText(banner.subtitle) || banner.subtitle,
    tagline: removeWarrantyText(banner.tagline) || banner.tagline,
  };
}

export function sanitizeBanners(banners: Banner[]): Banner[] {
  if (!Array.isArray(banners)) return [];
  return banners.map(sanitizeBanner);
}
