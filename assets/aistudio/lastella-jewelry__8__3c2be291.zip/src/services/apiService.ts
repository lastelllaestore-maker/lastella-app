import { auth } from './firebaseService';

/**
 * Universal API Service for LASTELLA Jewellery
 * Works seamlessly across:
 * 1. GitHub Pages (Static hosting connecting to Cloudflare Worker backend)
 * 2. Local Vite Development & Preview (Express server on port 3000)
 * 3. Capacitor Android APK & iOS Native Webviews
 */

// Separately configured Production Cloudflare Tracking Worker endpoint (distinct from email Worker)
export const CLOUDFLARE_TRACKER_WORKER_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_TRACKER_WORKER_URL) ||
  'https://lastella-tracker-worker.lastelllaestore.workers.dev';

// Backward-compatible export
export const CLOUDFLARE_WORKER_URL = CLOUDFLARE_TRACKER_WORKER_URL;

export function getBackendEndpoint(path: string): string {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;

  // 1. If custom backend URL is explicitly configured via environment variable
  if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_BACKEND_API_URL) {
    return `${import.meta.env.VITE_BACKEND_API_URL.replace(/\/$/, '')}${cleanPath}`;
  }

  // 2. Production routing: GitHub Pages and custom production domain lastella-jewelery.com
  // Routes to the separately configured Cloudflare tracking Worker since static hosting has no Express server
  if (typeof window !== 'undefined') {
    const host = window.location.hostname.toLowerCase();
    const isStaticProductionHost =
      host === 'lastella-jewelery.com' ||
      host.endsWith('.lastella-jewelery.com') ||
      host.endsWith('github.io');

    if (isStaticProductionHost) {
      return `${CLOUDFLARE_TRACKER_WORKER_URL.replace(/\/$/, '')}${cleanPath}`;
    }
  }

  // 3. Development / Full-stack environment (Express server on port 3000)
  return cleanPath;
}

export interface TrackOrderResponse {
  success: boolean;
  order?: any;
  error?: string;
}

export interface ClaimLegacyResponse {
  success: boolean;
  message?: string;
  order?: any;
  error?: string;
}

/**
 * Securely track an order using orderId and cryptographically unguessable trackingToken.
 */
export async function trackOrder(orderId: string, trackingToken: string): Promise<TrackOrderResponse> {
  const url = getBackendEndpoint('/api/orders/track');

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        orderId,
        trackingToken,
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Order lookup failed' };
    }
    return { success: true, order: data.order };
  } catch (err: any) {
    console.warn('[API Service] trackOrder error:', err);
    return { success: false, error: err?.message || 'Network error looking up order' };
  }
}

/**
 * Securely claim an unassigned legacy order.
 * Authenticates the user via Firebase Auth ID token and sends it in Authorization header.
 * The backend verifies the token and derives the UID authoritatively.
 */
export async function claimLegacyOrder(orderId: string, trackingToken: string): Promise<ClaimLegacyResponse> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    return { success: false, error: 'Customer session not initialized. Please retry in a moment.' };
  }

  try {
    const idToken = await currentUser.getIdToken();
    const url = getBackendEndpoint('/api/orders/claim-legacy');

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${idToken}`,
      },
      body: JSON.stringify({
        orderId,
        trackingToken,
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Failed to claim legacy order' };
    }
    return { success: true, message: data.message, order: data.order };
  } catch (err: any) {
    console.warn('[API Service] claimLegacyOrder error:', err);
    return { success: false, error: err?.message || 'Network error claiming order' };
  }
}
