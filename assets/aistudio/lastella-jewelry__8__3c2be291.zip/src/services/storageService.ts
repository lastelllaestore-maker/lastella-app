import { Product, Order, CartItem, AppNotification, UserProfile, StoreSettings, Banner, Review, OrderStatus, DeliveryMethod, Language } from '../types';
import { INITIAL_PRODUCTS, INITIAL_SETTINGS, INITIAL_BANNERS, INITIAL_REVIEWS } from '../data/initialData';
import { firebaseService } from './firebaseService';
import { sanitizeProducts, sanitizeBanners, removeWarrantyText } from '../utils/warrantySanitizer';

const STORAGE_KEYS = {
  LANGUAGE: 'lastella_language_v1',
  PRODUCTS: 'lastella_products_v1',
  CART: 'lastella_cart_v1',
  WISHLIST: 'lastella_wishlist_v1',
  ORDERS: 'lastella_orders_v1',
  MY_ORDERS: 'lastella_my_orders_v1',
  NOTIFICATIONS: 'lastella_notifications_v1',
  PUBLIC_NOTIFICATIONS: 'lastella_public_notifications_v2',
  QUARANTINED_NOTIFICATIONS: 'lastella_quarantined_notifications_v1',
  PROFILE: 'lastella_profile_v1',
  SETTINGS: 'lastella_settings_v1',
  BANNERS: 'lastella_banners_v1',
  REVIEWS: 'lastella_reviews_v1',
  RECENT_SEARCHES: 'lastella_recent_searches_v1',
  DELIVERY_METHOD: 'lastella_delivery_method_v1',
  ADMIN_AUTH: 'lastella_admin_auth_v1',
  LEGACY_UNVERIFIED_ORDERS: 'lastella_legacy_unverified_orders',
};

// Cryptographically secure randomness helper
function generateSecureRandomHex(bytes = 16): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

function generateSecureOrderNumber(): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return `LST-${100000 + (buf[0] % 900000)}`;
  }
  return `LST-${Math.floor(100000 + Math.random() * 900000)}`;
}


// Initial notifications
const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: '✨ Welcome to LASTELLA Boutique!',
    message: 'Enjoy timeless elegance with fast delivery all over Oman.',
    type: 'arrival',
    timestamp: 'Just now',
    read: false,
  },
  {
    id: 'notif-2',
    title: '🎁 Ramadan & Festive Special Offer',
    message: 'Complimentary Signature LED Luxury Velvet Box on orders above 10.000 OMR.',
    type: 'offer',
    timestamp: '1 hour ago',
    read: false,
  },
];

// In-memory fallback cache for mobile webviews, incognito mode, or restricted environments
const memoryCache: Record<string, any> = {};

function safeGetCookie(name: string): string | null {
  try {
    if (typeof document === 'undefined') return null;
    const match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
    return match ? decodeURIComponent(match[3]) : null;
  } catch {
    return null;
  }
}

function safeSetCookie(name: string, value: string, maxAgeDays = 30): void {
  try {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=${maxAgeDays * 86400}; SameSite=Lax`;
  } catch {
    // ignore
  }
}

function safeRemoveCookie(name: string): void {
  try {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax`;
  } catch {
    // ignore
  }
}

export const storageService = {
  // PRODUCTS (Read-only performance & offline cache for Firestore Single Source of Truth)
  getCachedProducts(): Product[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          const sanitized = sanitizeProducts(parsed);
          memoryCache[STORAGE_KEYS.PRODUCTS] = sanitized;
          return sanitized;
        }
      }
      if (memoryCache[STORAGE_KEYS.PRODUCTS] && Array.isArray(memoryCache[STORAGE_KEYS.PRODUCTS])) {
        return sanitizeProducts(memoryCache[STORAGE_KEYS.PRODUCTS]);
      }
      return [];
    } catch {
      return sanitizeProducts(memoryCache[STORAGE_KEYS.PRODUCTS] || []);
    }
  },

  cacheProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      memoryCache[STORAGE_KEYS.PRODUCTS] = products;
    } catch (e) {
      console.warn('Failed to cache products locally', e);
    }
  },

  getProducts(): Product[] {
    return this.getCachedProducts();
  },

  saveProducts(products: Product[]): void {
    this.cacheProducts(products);
  },

  // Legacy wrappers forwarding directly to Firestore Single Source of Truth
  async addProduct(product: Omit<Product, 'id'>): Promise<Product> {
    return firebaseService.addProduct(product);
  },

  async updateProduct(updated: Product): Promise<void> {
    return firebaseService.updateProduct(updated);
  },

  async deleteProduct(id: string): Promise<void> {
    return firebaseService.deleteProduct(id);
  },

  // CART (Device-specific shopping session - NEVER shared globally or via Firestore)
  getCart(): CartItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CART);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  saveCart(cart: CartItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart locally', e);
    }
  },

  clearCart(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.CART);
    } catch {
      // ignore
    }
  },

  // WISHLIST (Device-specific shopping session - NEVER shared globally or via Firestore)
  getWishlist(): string[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.WISHLIST);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  },

  toggleWishlist(productId: string): string[] {
    const list = this.getWishlist();
    const exists = list.includes(productId);
    const updated = exists ? list.filter((id) => id !== productId) : [...list, productId];
    try {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to update wishlist', e);
    }
    return updated;
  },

  // CUSTOMER AUTH CREDENTIALS (Secure local device session)
  getCustomerAuthCred(): { email: string; password: string; uid?: string } | null {
    try {
      const stored = localStorage.getItem('lastella_cust_auth_v2');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed.email && parsed.password) return parsed;
      }
      return null;
    } catch {
      return null;
    }
  },

  // Save customer session metadata securely WITHOUT exposing plaintext passwords in localStorage
  saveCustomerAuthCred(cred: { email: string; password?: string; uid?: string }): void {
    try {
      // Intentionally omit raw password so plaintext credentials are never persisted in localStorage
      const safeMetadata = {
        email: cred.email,
        uid: cred.uid,
        updatedAt: new Date().toISOString(),
      };
      localStorage.setItem('lastella_cust_auth_v2', JSON.stringify(safeMetadata));
    } catch (e) {
      console.warn('Failed to save customer auth metadata', e);
    }
  },

  // CUSTOMER'S OWN ORDERS (Strictly isolated by customerUid to prevent shared device leaks)
  // Hardened legacy migration: NEVER assign unverified old orders to a new customer's account.
  getMyOrders(customerUid?: string): Order[] {
    if (!customerUid || typeof customerUid !== 'string' || customerUid.trim() === '') {
      // Strictly refuse to return orders without a verified customer UID
      return [];
    }

    const cleanUid = customerUid.trim();
    try {
      // Purge any legacy shared guest key so it never leaks or lingers
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem('lastella_orders_guest_v2');
      }

      const key = `lastella_orders_${cleanUid}_v2`;
      const stored = localStorage.getItem(key);
      let myOrders: Order[] = [];
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          // Reject any cached order whose customerUid does not match the authenticated customer UID
          myOrders = parsed.filter(
            (o: Order) => Boolean(o && o.id && o.customerUid === cleanUid)
          );
        }
      }

      // Safe migration check for legacy orders:
      // If un-scoped legacy orders exist from previous app versions in STORAGE_KEYS.MY_ORDERS ('lastella_my_orders_v1'):
      const legacy = localStorage.getItem(STORAGE_KEYS.MY_ORDERS);
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
          const verifiedForMe: Order[] = [];
          const unverifiedQuarantine: Order[] = this.getUnverifiedLegacyOrders();

          parsedLegacy.forEach((o: Order) => {
            // ONLY migrate to this customer if the order already legitimately has this customer's verified UID
            if (o && o.customerUid === cleanUid) {
              if (!myOrders.some((existing) => existing.id === o.id)) {
                verifiedForMe.push(o);
              }
            } else if (o && o.id) {
              // Unverified legacy orders are quarantined separately — NEVER assigned to current customerUid
              if (!unverifiedQuarantine.some((existing) => existing.id === o.id)) {
                unverifiedQuarantine.push(o);
              }
            }
          });

          if (verifiedForMe.length > 0) {
            myOrders = [...verifiedForMe, ...myOrders];
            localStorage.setItem(key, JSON.stringify(myOrders));
          }

          if (unverifiedQuarantine.length > 0) {
            localStorage.setItem(STORAGE_KEYS.LEGACY_UNVERIFIED_ORDERS, JSON.stringify(unverifiedQuarantine));
          }

          // Clean legacy key after sorting into verified vs quarantined
          localStorage.removeItem(STORAGE_KEYS.MY_ORDERS);
        }
      }

      return myOrders;
    } catch {
      return [];
    }
  },

  // Quarantined legacy orders that have no verified owner yet
  getUnverifiedLegacyOrders(): Order[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LEGACY_UNVERIFIED_ORDERS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  // Authoritatively link a verified legacy order to a customer account
  claimLegacyOrder(verifiedOrder: Order, customerUid: string): void {
    if (!customerUid || !verifiedOrder.id) return;
    const cleanUid = customerUid.trim();
    try {
      const key = `lastella_orders_${cleanUid}_v2`;
      const currentList = this.getMyOrders(cleanUid);
      const updated = [{ ...verifiedOrder, customerUid: cleanUid }, ...currentList.filter((o) => o.id !== verifiedOrder.id)];
      localStorage.setItem(key, JSON.stringify(updated));

      // Remove from quarantined legacy list
      const quarantined = this.getUnverifiedLegacyOrders().filter((o) => o.id !== verifiedOrder.id);
      localStorage.setItem(STORAGE_KEYS.LEGACY_UNVERIFIED_ORDERS, JSON.stringify(quarantined));
    } catch (e) {
      console.warn('Failed to claim legacy order', e);
    }
  },

  // Bulk cache customer's verified orders atomically without reversing or dropping orders
  cacheCustomerOrders(orders: Order[], customerUid?: string): void {
    if (!customerUid || !Array.isArray(orders)) return;
    const cleanUid = customerUid.trim();
    if (!cleanUid) return;

    try {
      const key = `lastella_orders_${cleanUid}_v2`;
      const verified = orders.filter((o) => Boolean(o && o.id && o.customerUid === cleanUid));
      localStorage.setItem(key, JSON.stringify(verified));
    } catch (e) {
      console.warn('Failed to cache customer orders', e);
    }
  },

  clearCustomerCache(customerUid?: string): void {
    try {
      if (customerUid) {
        localStorage.removeItem(`lastella_orders_${customerUid.trim()}_v2`);
      }
      localStorage.removeItem('lastella_orders_guest_v2');
      localStorage.removeItem(STORAGE_KEYS.MY_ORDERS);
    } catch (e) {
      console.warn('Failed to clear customer cache', e);
    }
  },

  saveMyOrder(order: Order, customerUid?: string): void {
    if (!order || !order.id) return;
    const effectiveUid = (customerUid || order.customerUid || '').trim();
    if (!effectiveUid) {
      console.warn('[Storage] Refusing to cache order without authenticated customerUid');
      return;
    }
    // Strict customer isolation invariant: order's customerUid MUST match effectiveUid
    if (order.customerUid && order.customerUid !== effectiveUid) {
      console.warn(`[Storage] Order customerUid mismatch (${order.customerUid} vs ${effectiveUid}). Skipping cache.`);
      return;
    }

    try {
      const key = `lastella_orders_${effectiveUid}_v2`;
      const list = this.getMyOrders(effectiveUid);
      const existingIndex = list.findIndex((o) => o.id === order.id);
      let updated: Order[];
      if (existingIndex !== -1) {
        updated = [...list];
        updated[existingIndex] = { ...updated[existingIndex], ...order, customerUid: effectiveUid };
      } else {
        updated = [{ ...order, customerUid: effectiveUid }, ...list];
      }
      localStorage.setItem(key, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save my order locally', e);
    }
  },

  updateMyOrder(updatedOrder: Order, customerUid?: string): void {
    if (!updatedOrder || !updatedOrder.id) return;
    const effectiveUid = (customerUid || updatedOrder.customerUid || '').trim();
    if (!effectiveUid) return;
    if (updatedOrder.customerUid && updatedOrder.customerUid !== effectiveUid) return;

    try {
      const key = `lastella_orders_${effectiveUid}_v2`;
      const list = this.getMyOrders(effectiveUid);
      const index = list.findIndex((o) => o.id === updatedOrder.id);
      if (index !== -1) {
        list[index] = { ...list[index], ...updatedOrder, customerUid: effectiveUid };
      } else {
        list.unshift({ ...updatedOrder, customerUid: effectiveUid });
      }
      localStorage.setItem(key, JSON.stringify(list));
    } catch (e) {
      console.warn('Failed to update my order locally', e);
    }
  },

  // ADMIN-ONLY CACHED ORDERS (Accessible in memory / sessionStorage ONLY when authenticated)
  getAdminCachedOrders(): Order[] {
    if (!this.isAdminAuthenticated()) {
      return [];
    }
    try {
      const session = sessionStorage.getItem('lastella_admin_orders_cache_v1');
      if (session) {
        const parsed = JSON.parse(session);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  cacheAdminOrders(orders: Order[]): void {
    if (!this.isAdminAuthenticated()) return;
    try {
      sessionStorage.setItem('lastella_admin_orders_cache_v1', JSON.stringify(orders));
    } catch (e) {
      console.warn('Failed to cache admin orders in session', e);
    }
  },

  clearAdminData(): void {
    memoryCache[STORAGE_KEYS.ADMIN_AUTH] = false;
    try {
      localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
      sessionStorage.removeItem('lastella_admin_session_v1');
      sessionStorage.removeItem('lastella_admin_orders_cache_v1');
      safeRemoveCookie('lastella_admin_auth_v1');
    } catch (e) {
      console.warn('Failed to clear admin data', e);
    }
  },

  getCachedOrders(customerUid?: string): Order[] {
    if (this.isAdminAuthenticated()) {
      return this.getAdminCachedOrders();
    }
    if (customerUid) {
      return this.getMyOrders(customerUid);
    }
    return [];
  },

  cacheOrders(orders: Order[]): void {
    if (this.isAdminAuthenticated()) {
      this.cacheAdminOrders(orders);
    }
  },

  getOrders(): Order[] {
    return this.getCachedOrders();
  },

  saveOrders(orders: Order[]): void {
    this.cacheOrders(orders);
  },

  createOrder(newOrderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>): Order {
    const randomSuffix = generateSecureRandomHex(8).toUpperCase();
    const orderNum = generateSecureOrderNumber();
    const newOrder: Order = {
      ...newOrderData,
      id: `ord_${Date.now()}_${randomSuffix}`,
      orderNumber: orderNum,
      createdAt: new Date().toISOString(),
      status: 'Order Placed',
      paymentStatus: 'Pending Payment',
      paymentMethod: newOrderData.paymentMethod || 'bank_transfer',
      statusHistory: [
        {
          status: 'Order Placed',
          timestamp: new Date().toISOString(),
          note: 'Order submitted to LASTELLA Boutique Cloud - Bank Transfer Pending',
        },
      ],
    };
    return newOrder;
  },

  updateOrderStatus(_orderId: string, _status: OrderStatus, _note?: string): void {
    // Handled directly via firebaseService.updateOrderStatus
  },

  // PUBLIC BOUTIQUE NOTIFICATIONS (Announcements, promotions, offers - available to everyone)
  getPublicNotifications(): AppNotification[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Never return any order notification from public store
          return parsed.filter((n) => n && n.type !== 'order' && !n.orderId);
        }
      }

      // Check legacy notifications for public non-order notifications
      const legacy = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (Array.isArray(parsedLegacy)) {
          const promoOnly = parsedLegacy.filter((n) => n && n.type !== 'order' && !n.orderId);
          if (promoOnly.length > 0) {
            localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(promoOnly));
            return promoOnly;
          }
        }
      }

      localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  },

  // CUSTOMER-SPECIFIC ORDER NOTIFICATIONS (Isolated by verified Firebase Auth UID)
  getCustomerNotifications(customerUid?: string): AppNotification[] {
    if (!customerUid || typeof customerUid !== 'string' || customerUid.trim() === '') {
      return [];
    }
    const cleanUid = customerUid.trim();
    const custKey = `lastella_cust_notifications_${cleanUid}_v2`;
    try {
      const stored = localStorage.getItem(custKey);
      let customerNotifs: AppNotification[] = [];
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          customerNotifs = parsed.filter((n: AppNotification) => Boolean(n && n.id));
        }
      }

      // Safe quarantine: Examine legacy unverified notifications
      const legacy = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
          const remainingPublic: AppNotification[] = [];
          const quarantined = this.getQuarantinedNotifications();

          parsedLegacy.forEach((n: AppNotification) => {
            if (n && (n.type === 'order' || n.orderId)) {
              if ((n as any).customerUid === cleanUid) {
                if (!customerNotifs.some((ex) => ex.id === n.id)) {
                  customerNotifs.push(n);
                }
              } else {
                // Quarantined: cannot be authoritatively verified for this customer
                if (!quarantined.some((q) => q.id === n.id)) {
                  quarantined.push(n);
                }
              }
            } else if (n) {
              remainingPublic.push(n);
            }
          });

          localStorage.setItem(STORAGE_KEYS.QUARANTINED_NOTIFICATIONS, JSON.stringify(quarantined));
          localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(remainingPublic));
          localStorage.setItem(custKey, JSON.stringify(customerNotifs));
        }
      }

      return customerNotifs;
    } catch {
      return [];
    }
  },

  getQuarantinedNotifications(): AppNotification[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.QUARANTINED_NOTIFICATIONS);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  },

  // Returns combined notifications: verified customer notifications + public announcements
  getNotifications(customerUid?: string): AppNotification[] {
    const publicNotifs = this.getPublicNotifications();
    const custNotifs = this.getCustomerNotifications(customerUid);
    return [...custNotifs, ...publicNotifs];
  },

  saveNotifications(notifs: AppNotification[], customerUid?: string): void {
    const cleanUid = customerUid && typeof customerUid === 'string' ? customerUid.trim() : null;
    if (cleanUid) {
      const custKey = `lastella_cust_notifications_${cleanUid}_v2`;
      const custOnly = notifs.filter((n) => n.type === 'order' || Boolean(n.orderId));
      try {
        localStorage.setItem(custKey, JSON.stringify(custOnly));
      } catch (e) {
        console.warn('Failed to save customer notifications', e);
      }
    }
    const publicOnly = notifs.filter((n) => n.type !== 'order' && !n.orderId);
    try {
      localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(publicOnly));
    } catch (e) {
      console.warn('Failed to save public notifications', e);
    }
  },

  addNotification(
    notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>,
    customerUid?: string
  ): AppNotification {
    const item: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}-${generateSecureRandomHex(4)}`,
      timestamp: 'Just now',
      read: false,
    };

    const isOrderNotif = item.type === 'order' || Boolean(item.orderId);
    const cleanUid = customerUid && typeof customerUid === 'string' ? customerUid.trim() : null;

    if (isOrderNotif && cleanUid) {
      (item as any).customerUid = cleanUid;
      const custKey = `lastella_cust_notifications_${cleanUid}_v2`;
      const current = this.getCustomerNotifications(cleanUid);
      const updated = [item, ...current.filter((n) => n.id !== item.id)];
      try {
        localStorage.setItem(custKey, JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save customer notification', e);
      }
      return item;
    }

    // Public announcement
    const publicNotifs = this.getPublicNotifications();
    const updated = [item, ...publicNotifs.filter((n) => n.id !== item.id)];
    try {
      localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save public notification', e);
    }
    return item;
  },

  markNotificationRead(id: string, customerUid?: string): void {
    const cleanUid = customerUid && typeof customerUid === 'string' ? customerUid.trim() : null;
    if (cleanUid) {
      const custKey = `lastella_cust_notifications_${cleanUid}_v2`;
      const custNotifs = this.getCustomerNotifications(cleanUid).map((n) =>
        n.id === id ? { ...n, read: true } : n
      );
      try {
        localStorage.setItem(custKey, JSON.stringify(custNotifs));
      } catch {}
    }

    const publicNotifs = this.getPublicNotifications().map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    try {
      localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(publicNotifs));
    } catch {}
  },

  markAllNotificationsRead(customerUid?: string): void {
    const cleanUid = customerUid && typeof customerUid === 'string' ? customerUid.trim() : null;
    if (cleanUid) {
      const custKey = `lastella_cust_notifications_${cleanUid}_v2`;
      const custNotifs = this.getCustomerNotifications(cleanUid).map((n) => ({ ...n, read: true }));
      try {
        localStorage.setItem(custKey, JSON.stringify(custNotifs));
      } catch {}
    }

    const publicNotifs = this.getPublicNotifications().map((n) => ({ ...n, read: true }));
    try {
      localStorage.setItem(STORAGE_KEYS.PUBLIC_NOTIFICATIONS, JSON.stringify(publicNotifs));
    } catch {}
  },

  clearCustomerNotifications(customerUid: string): void {
    if (!customerUid) return;
    try {
      localStorage.removeItem(`lastella_cust_notifications_${customerUid.trim()}_v2`);
    } catch {}
  },

  // USER PROFILE & SAVED ADDRESSES (Strictly isolated by customerUid)
  getProfile(customerUid?: string): UserProfile {
    const blankProfile: UserProfile = {
      id: customerUid ? `usr-${customerUid}` : 'usr-guest',
      name: '',
      phone: '',
      whatsapp: '',
      email: '',
      isGuest: !customerUid,
      addresses: [],
    };

    if (!customerUid || typeof customerUid !== 'string' || customerUid.trim() === '') {
      return blankProfile;
    }

    const cleanUid = customerUid.trim();
    const custKey = `lastella_profile_${cleanUid}_v2`;

    try {
      const stored = localStorage.getItem(custKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object') {
          return {
            ...blankProfile,
            ...parsed,
            id: parsed.id || `usr-${cleanUid}`,
          };
        }
      }

      // Check legacy profile for migration ONLY if it explicitly matches this customerUid
      const legacy = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (parsedLegacy && (parsedLegacy as any).customerUid === cleanUid) {
          const migrated: UserProfile = {
            ...blankProfile,
            ...parsedLegacy,
            id: `usr-${cleanUid}`,
          };
          localStorage.setItem(custKey, JSON.stringify(migrated));
          return migrated;
        }
      }

      return blankProfile;
    } catch {
      return blankProfile;
    }
  },

  saveProfile(profile: UserProfile, customerUid?: string): void {
    if (!customerUid || typeof customerUid !== 'string' || customerUid.trim() === '') {
      return;
    }

    const cleanUid = customerUid.trim();
    const custKey = `lastella_profile_${cleanUid}_v2`;
    try {
      const payload = {
        ...profile,
        customerUid: cleanUid,
        updatedAt: new Date().toISOString(),
      };
      localStorage.setItem(custKey, JSON.stringify(payload));
    } catch (e) {
      console.error('Failed to save customer profile', e);
    }
  },

  clearCustomerProfile(customerUid: string): void {
    if (!customerUid) return;
    try {
      localStorage.removeItem(`lastella_profile_${customerUid.trim()}_v2`);
    } catch {}
  },

  // STORE SETTINGS (Offline performance cache)
  getCachedSettings(): StoreSettings {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (stored) return JSON.parse(stored);
      return INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  },

  cacheSettings(settings: StoreSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to cache settings locally', e);
    }
  },

  getSettings(): StoreSettings {
    return this.getCachedSettings();
  },

  saveSettings(settings: StoreSettings): void {
    this.cacheSettings(settings);
  },

  // BANNERS
  getBanners(): Banner[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.BANNERS);
      if (stored) return sanitizeBanners(JSON.parse(stored));
      const banners = Array.isArray(INITIAL_BANNERS) ? INITIAL_BANNERS : Object.values(INITIAL_BANNERS).filter((b): b is Banner => typeof b === 'object' && b !== null && 'id' in b);
      const sanitized = sanitizeBanners(banners);
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(sanitized));
      return sanitized;
    } catch {
      return sanitizeBanners(Array.isArray(INITIAL_BANNERS) ? INITIAL_BANNERS : []);
    }
  },

  saveBanners(banners: Banner[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
    } catch (e) {
      console.error('Failed to save banners', e);
    }
  },

  // REVIEWS
  getReviews(): Review[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.REVIEWS);
      if (stored) return JSON.parse(stored);
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(INITIAL_REVIEWS));
      return INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  },

  addReview(review: Omit<Review, 'id' | 'date'>): Review {
    const reviews = this.getReviews();
    const newRev: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      date: 'Just now',
    };
    reviews.unshift(newRev);
    try {
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
    } catch (e) {
      console.error('Failed to save review', e);
    }
    return newRev;
  },

  // SEARCH HISTORY
  getRecentSearches(): string[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.RECENT_SEARCHES);
      return stored ? JSON.parse(stored) : ['Ring', 'Layered Necklace', 'Tennis Bracelet', 'Gold Set', 'Gift Box'];
    } catch {
      return ['Ring', 'Layered Necklace', 'Tennis Bracelet'];
    }
  },

  addRecentSearch(query: string): void {
    if (!query.trim()) return;
    const list = this.getRecentSearches().filter((s) => s.toLowerCase() !== query.trim().toLowerCase());
    list.unshift(query.trim());
    try {
      localStorage.setItem(STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(list.slice(0, 8)));
    } catch (e) {
      console.error('Failed to save recent search', e);
    }
  },

  clearRecentSearches(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.RECENT_SEARCHES);
    } catch (e) {
      console.error('Failed to clear recent searches', e);
    }
  },

  // DELIVERY PREFERENCE
  getDeliveryMethod(): DeliveryMethod | null {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.DELIVERY_METHOD);
      return stored === 'home' || stored === 'office' ? stored : null;
    } catch {
      return null;
    }
  },

  setDeliveryMethod(method: DeliveryMethod | null): void {
    try {
      if (method) {
        localStorage.setItem(STORAGE_KEYS.DELIVERY_METHOD, method);
      } else {
        localStorage.removeItem(STORAGE_KEYS.DELIVERY_METHOD);
      }
    } catch (e) {
      console.error('Failed to save delivery method', e);
    }
  },

  // ADMIN AUTHENTICATION
  isAdminAuthenticated(): boolean {
    // 1. Check in-memory cache
    if (memoryCache[STORAGE_KEYS.ADMIN_AUTH] === true) {
      return true;
    }

    try {
      // 2. Check localStorage
      const local = localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH);
      if (local === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      // 3. Check sessionStorage
      const session = sessionStorage.getItem('lastella_admin_session_v1');
      if (session === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      // 4. Check cookie fallback
      const cookieVal = safeGetCookie('lastella_admin_auth_v1');
      if (cookieVal === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      return false;
    } catch {
      return memoryCache[STORAGE_KEYS.ADMIN_AUTH] === true;
    }
  },

  setAdminAuthenticated(auth: boolean): void {
    memoryCache[STORAGE_KEYS.ADMIN_AUTH] = auth;

    try {
      if (auth) {
        localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
        sessionStorage.setItem('lastella_admin_session_v1', 'true');
        safeSetCookie('lastella_admin_auth_v1', 'true', 30);
      } else {
        localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        sessionStorage.removeItem('lastella_admin_session_v1');
        safeRemoveCookie('lastella_admin_auth_v1');
      }
    } catch (e) {
      console.warn('[LASTELLA Storage] Storage access constrained, using memory session', e);
    }
  },

  verifyAdminPasscode(passcode: string): boolean {
    try {
      const cleanPass = passcode.trim();
      if (!cleanPass) return false;
      const settings = this.getSettings();
      const configuredCode = (settings.adminPasscode || '').trim();
      if (!configuredCode) {
        return false;
      }
      return cleanPass === configuredCode;
    } catch {
      return false;
    }
  },

  // LANGUAGE
  getLanguage(): Language {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language;
      if (stored === 'ar' || stored === 'en') {
        return stored;
      }
      // Default to Arabic
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, 'ar');
      return 'ar';
    } catch {
      return 'ar';
    }
  },

  saveLanguage(lang: Language): void {
    try {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    } catch (e) {
      console.error('Failed to save language', e);
    }
  },
};

