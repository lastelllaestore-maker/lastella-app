import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  writeBatch,
  getDocFromServer,
} from 'firebase/firestore';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { Product, Order, StoreSettings, OrderStatus } from '../types';
import { INITIAL_PRODUCTS, INITIAL_SETTINGS } from '../data/initialData';
import { uploadProductImageToCloudinary, processAndCompressImage } from './cloudinaryService';

// Authorized Administrator Emails for LASTELLA Store (matches Firebase Auth)
export const ADMIN_EMAILS = ['lastelllaestore@gmail.com'];

// Cryptographically secure randomness helper
function generateSecureRandomHex(bytes = 16): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

function generateSecureOrderNumber(): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return `LST-${100000 + (buf[0] % 900000)}`;
  }
  return `LST-${Math.floor(100000 + Math.random() * 900000)}`;
}

// In-memory cache of verified admin UIDs to enable fast synchronous checks
const verifiedAdminUids = new Set<string>();

export type AdminAuthErrorCode =
  | 'INVALID_CREDENTIALS'
  | 'PERMISSION_DENIED'
  | 'MISSING_ADMIN_ROLE'
  | 'INVALID_ROLE'
  | 'NETWORK_ERROR'
  | 'UNKNOWN';

export class AdminAuthError extends Error {
  code: AdminAuthErrorCode;
  uid?: string;
  databaseId?: string;

  constructor(code: AdminAuthErrorCode, message: string, uid?: string, databaseId?: string) {
    super(message);
    this.name = 'AdminAuthError';
    this.code = code;
    this.uid = uid;
    this.databaseId = databaseId || firebaseConfig.firestoreDatabaseId;
  }
}

export interface AdminVerificationResult {
  isAdmin: boolean;
  status: 'AUTHORIZED' | 'PERMISSION_DENIED' | 'MISSING_ROLE_DOC' | 'INVALID_ROLE' | 'ERROR';
  uid?: string;
  errorMessage?: string;
}

// Helper to check if a Firebase user is an authorized administrator
// Strictly driven by server-assigned custom claim or database role document.
// Zero email-only fallbacks!
export function isUserAdmin(user: User | null): boolean {
  if (!user) return false;
  return (user as any)._lastellaAdmin === true || verifiedAdminUids.has(user.uid);
}

// Detailed asynchronous admin check reporting granular status (custom claims, Firestore role doc, permissions)
export async function verifyUserAdminPrivilegeDetailed(user: User | null): Promise<AdminVerificationResult> {
  if (!user) {
    return { isAdmin: false, status: 'MISSING_ROLE_DOC', errorMessage: 'No authenticated user session found.' };
  }

  try {
    // 1. Check custom claim (server-assigned custom claim `admin: true`)
    const tokenResult = await user.getIdTokenResult(true);
    if (tokenResult.claims.admin === true) {
      (user as any)._lastellaAdmin = true;
      verifiedAdminUids.add(user.uid);
      return { isAdmin: true, status: 'AUTHORIZED', uid: user.uid };
    }

    // 2. Check trusted role document in Firestore collection `/admins/{uid}` on named database
    const adminDocRef = doc(db, 'admins', user.uid);
    let adminSnap;
    try {
      adminSnap = await getDoc(adminDocRef);
    } catch (firestoreErr: any) {
      const errStr = (firestoreErr?.message || String(firestoreErr)).toLowerCase();
      const isPermissionDenied =
        firestoreErr?.code === 'permission-denied' ||
        errStr.includes('permission') ||
        errStr.includes('missing or insufficient permissions');

      console.error('[LASTELLA Auth] Firestore read error on /admins/' + user.uid + ':', firestoreErr);
      return {
        isAdmin: false,
        status: isPermissionDenied ? 'PERMISSION_DENIED' : 'ERROR',
        uid: user.uid,
        errorMessage: isPermissionDenied
          ? `Firestore Permission Denied: Rules for database "${firebaseConfig.firestoreDatabaseId}" denied reading /admins/${user.uid}. Verify active rules permit self-read.`
          : `Firestore error reading /admins/${user.uid}: ${firestoreErr?.message || firestoreErr}`,
      };
    }

    if (!adminSnap.exists()) {
      console.warn(`[LASTELLA Auth] Signed-in user lacks server-assigned admin role. /admins/${user.uid} does not exist in named database "${firebaseConfig.firestoreDatabaseId}".`);
      return {
        isAdmin: false,
        status: 'MISSING_ROLE_DOC',
        uid: user.uid,
        errorMessage: `Admin role document /admins/${user.uid} does not exist in database "${firebaseConfig.firestoreDatabaseId}". Ensure the document ID matches your Auth UID (${user.uid}).`,
      };
    }

    const data = adminSnap.data();
    if (data?.role !== 'admin') {
      console.warn(`[LASTELLA Auth] /admins/${user.uid} exists, but role is "${data?.role}", expected "admin".`);
      return {
        isAdmin: false,
        status: 'INVALID_ROLE',
        uid: user.uid,
        errorMessage: `Admin document exists, but role field is "${data?.role || 'empty'}" (expected "admin").`,
      };
    }

    (user as any)._lastellaAdmin = true;
    verifiedAdminUids.add(user.uid);
    return { isAdmin: true, status: 'AUTHORIZED', uid: user.uid };
  } catch (err: any) {
    console.error('[LASTELLA Auth] Unexpected admin privilege verification error:', err);
    return {
      isAdmin: false,
      status: 'ERROR',
      uid: user.uid,
      errorMessage: err?.message || String(err),
    };
  }
}

// Server-backed asynchronous admin check (evaluates token custom claims or Firestore role)
export async function verifyUserAdminPrivilege(user: User | null): Promise<boolean> {
  const result = await verifyUserAdminPrivilegeDetailed(user);
  if (!result.isAdmin && user) {
    (user as any)._lastellaAdmin = false;
    verifiedAdminUids.delete(user.uid);
  }
  return result.isAdmin;
}

/**
 * Recursively sanitizes data before writing to Cloud Firestore.
 * Removes all properties with `undefined` values because Firestore strictly
 * rejects documents containing `undefined` with:
 * "FirebaseError: Function setDoc() called with invalid data. Unsupported field value: undefined"
 */
export function cleanForFirestore<T>(data: T): T {
  if (data === undefined) {
    return null as any;
  }
  if (data === null || typeof data !== 'object') {
    return data;
  }
  if (data instanceof Date) {
    return data.toISOString() as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => cleanForFirestore(item)) as any;
  }
  const cleaned: Record<string, any> = {};
  for (const [key, val] of Object.entries(data)) {
    if (val !== undefined) {
      cleaned[key] = cleanForFirestore(val);
    }
  }
  return cleaned as T;
}

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Cloud Services (Firestore & Auth only - Firebase Storage removed)
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Authentication Service for Admin verification
export const authService = {
  getAuthInstance() {
    return auth;
  },
  getCurrentUser(): User | null {
    return auth.currentUser;
  },
  isCurrentAdmin(): boolean {
    return isUserAdmin(auth.currentUser);
  },
  async signInAdminWithCredentials(
    email: string,
    passcodeOrPassword: string
  ): Promise<{ user: User; isAdmin: boolean }> {
    const cleanEmail = (email || '').trim().toLowerCase();

    // 1. Firebase Auth authentication
    let userCredential;
    try {
      userCredential = await signInWithEmailAndPassword(
        auth,
        cleanEmail,
        passcodeOrPassword
      );
    } catch (authErr: any) {
      console.warn('[LASTELLA Auth] Firebase Auth sign-in failed:', authErr?.code, authErr?.message);
      const code = authErr?.code || '';
      if (
        code === 'auth/wrong-password' ||
        code === 'auth/invalid-credential' ||
        code === 'auth/user-not-found' ||
        code === 'auth/invalid-email'
      ) {
        throw new AdminAuthError(
          'INVALID_CREDENTIALS',
          'Invalid Firebase Auth credentials. Please verify your email and password.',
          undefined
        );
      }
      if (code === 'auth/network-request-failed') {
        throw new AdminAuthError(
          'NETWORK_ERROR',
          'Network connection error. Please check your internet connection.',
          undefined
        );
      }
      throw new AdminAuthError(
        'UNKNOWN',
        authErr?.message || 'Authentication failed. Please verify credentials.',
        undefined
      );
    }

    const user = userCredential.user;

    // 2. Authoritative role check against Firestore named database /admins/{uid}
    const verification = await verifyUserAdminPrivilegeDetailed(user);
    if (!verification.isAdmin) {
      console.warn('[LASTELLA Auth] Signed-in user lacks server-assigned admin role:', user.uid);
      if (verification.status === 'PERMISSION_DENIED') {
        throw new AdminAuthError(
          'PERMISSION_DENIED',
          verification.errorMessage || `Firestore Permission Denied on database "${firebaseConfig.firestoreDatabaseId}" reading /admins/${user.uid}.`,
          user.uid
        );
      }
      if (verification.status === 'MISSING_ROLE_DOC') {
        throw new AdminAuthError(
          'MISSING_ADMIN_ROLE',
          verification.errorMessage || `Signed-in user lacks server-assigned admin role: Document /admins/${user.uid} not found in database "${firebaseConfig.firestoreDatabaseId}".`,
          user.uid
        );
      }
      if (verification.status === 'INVALID_ROLE') {
        throw new AdminAuthError(
          'INVALID_ROLE',
          verification.errorMessage || `Admin role document /admins/${user.uid} has invalid role value.`,
          user.uid
        );
      }
      throw new AdminAuthError(
        'UNKNOWN',
        verification.errorMessage || 'Access Denied: Account is not provisioned with store administrator privileges.',
        user.uid
      );
    }

    console.log('[LASTELLA Auth] Signed in as verified administrator:', user.uid);
    return { user, isAdmin: true };
  },
  async changeAdminPassword(
    currentPassword: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> {
    const currentUser = auth.currentUser;
    if (!currentUser || !currentUser.email) {
      throw new Error('You must be signed in as administrator to change credentials.');
    }
    if (!isUserAdmin(currentUser)) {
      throw new Error('Unauthorized: only store administrator can change credentials.');
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password/passcode must be at least 6 characters long.');
    }

    try {
      // 1. Re-authenticate user with current password
      const credential = EmailAuthProvider.credential(currentUser.email, currentPassword);
      await reauthenticateWithCredential(currentUser, credential);

      // 2. Update password in Firebase Authentication
      await updatePassword(currentUser, newPassword);
      console.log('[LASTELLA Auth] Admin password successfully updated in Firebase Auth!');
      return { success: true };
    } catch (err: any) {
      console.error('[LASTELLA Auth] Failed to update admin password:', err);
      let message = err?.message || 'Failed to update password';
      if (err?.code === 'auth/wrong-password' || err?.code === 'auth/invalid-credential') {
        message = 'Current password/passcode is incorrect.';
      } else if (err?.code === 'auth/weak-password') {
        message = 'Password is too weak. Must be at least 6 characters.';
      } else if (err?.code === 'auth/requires-recent-login') {
        message = 'Please log out and log back in before changing your credentials.';
      }
      return { success: false, error: message };
    }
  },
  async syncAdminFirebaseAuth(passcode: string): Promise<User | null> {
    try {
      const result = await this.signInAdminWithCredentials(ADMIN_EMAILS[0], passcode);
      return result.user;
    } catch {
      return auth.currentUser;
    }
  },
  async signOutAdmin(): Promise<void> {
    await signOut(auth);
    console.log('[LASTELLA Auth] Admin signed out from Firebase Auth');
  },
  subscribeAuth(callback: (user: User | null, isAdmin: boolean) => void) {
    return onAuthStateChanged(auth, async (user) => {
      let isAdmin = false;
      if (user) {
        isAdmin = await verifyUserAdminPrivilege(user);
      }
      callback(user, isAdmin);
    });
  },
};

// Secure client-side IndexedDB credential vault (isolated to this origin; never exposes passwords to localStorage or public JS)
const VAULT_DB_NAME = 'lastella_auth_vault_v1';
const VAULT_STORE_NAME = 'device_auth';

function openVaultDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB not supported in this environment'));
    }
    const req = indexedDB.open(VAULT_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(VAULT_STORE_NAME)) {
        db.createObjectStore(VAULT_STORE_NAME, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getVaultCredential(): Promise<{ email: string; password: string; uid?: string } | null> {
  try {
    const db = await openVaultDB();
    return new Promise((resolve) => {
      const tx = db.transaction(VAULT_STORE_NAME, 'readonly');
      const store = tx.objectStore(VAULT_STORE_NAME);
      const req = store.get('customer_device_cred');
      req.onsuccess = () => resolve(req.result ? req.result.cred : null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function saveVaultCredential(cred: { email: string; password: string; uid?: string }): Promise<void> {
  try {
    const db = await openVaultDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(VAULT_STORE_NAME, 'readwrite');
      const store = tx.objectStore(VAULT_STORE_NAME);
      store.put({ id: 'customer_device_cred', cred, updatedAt: Date.now() });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.warn('[LASTELLA Auth Vault] Note saving credential in IndexedDB:', e);
  }
}

// In-flight singleton promise to prevent concurrent calls to ensureCustomerAuth from racing
let inFlightCustomerAuthPromise: Promise<User> | null = null;

/**
 * Ensures an authenticated Firebase Auth session for the current visitor/customer.
 * Generates and permanently preserves a stable, immutable Firebase Auth UID for guest shoppers
 * without requiring manual sign-up, enabling strict Firestore Security Rules enforcement (request.auth.uid == customerUid).
 * Credentials are securely persisted in an origin-isolated IndexedDB vault; NEVER plaintext passwords in localStorage!
 */
export async function ensureCustomerAuth(): Promise<User> {
  if (inFlightCustomerAuthPromise) {
    return inFlightCustomerAuthPromise;
  }

  inFlightCustomerAuthPromise = (async () => {
    // 1. Wait for Firebase Auth's native IndexedDB session to be ready
    try {
      if (typeof (auth as any).authStateReady === 'function') {
        await auth.authStateReady();
      }
    } catch {
      // continue
    }

    const current = auth.currentUser;
    if (current && !isUserAdmin(current)) {
      // Clean any legacy plain-text password from localStorage if previously stored
      try {
        const raw = typeof localStorage !== 'undefined' ? localStorage.getItem('lastella_cust_auth_v2') : null;
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed?.password) {
            delete parsed.password;
            parsed.sanitized = true;
            parsed.uid = current.uid;
            localStorage.setItem('lastella_cust_auth_v2', JSON.stringify(parsed));
          }
        }
      } catch {
        // ignore
      }
      return current;
    }

    const CUST_AUTH_KEY = 'lastella_cust_auth_v2';

    // 2. Check IndexedDB secure vault for device's established customer account
    const vaultCred = await getVaultCredential();
    if (vaultCred && vaultCred.email && vaultCred.password) {
      try {
        const cred = await signInWithEmailAndPassword(auth, vaultCred.email, vaultCred.password);
        console.log('[LASTELLA Auth] Customer session authoritatively restored from IndexedDB vault with UID:', cred.user.uid);
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(CUST_AUTH_KEY, JSON.stringify({
            email: vaultCred.email,
            uid: cred.user.uid,
            restoredAt: new Date().toISOString(),
          }));
        }
        return cred.user;
      } catch (vaultErr) {
        console.warn('[LASTELLA Auth] Vault re-auth failed, will attempt fallback:', vaultErr);
      }
    }

    // 3. Safe migration for existing customer accounts with legacy localStorage password
    try {
      const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(CUST_AUTH_KEY) : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.email && parsed.password) {
          const cred = await signInWithEmailAndPassword(auth, parsed.email, parsed.password);
          console.log('[LASTELLA Auth] Existing customer safely migrated to vault with UID:', cred.user.uid);
          // Migrate to vault
          await saveVaultCredential({
            email: parsed.email,
            password: parsed.password,
            uid: cred.user.uid,
          });
          // Wipe password immediately from localStorage
          localStorage.setItem(CUST_AUTH_KEY, JSON.stringify({
            email: parsed.email,
            uid: cred.user.uid,
            migrated: true,
            migratedAt: new Date().toISOString(),
          }));
          return cred.user;
        }
      }
    } catch (e) {
      console.warn('[LASTELLA Auth] Customer legacy migration note:', e);
    }

    // 4. Genuinely new customer on this device:
    // Provision fresh identity with high-entropy cryptographic password and store in IndexedDB vault.
    const randomSuffix = generateSecureRandomHex(12);
    const email = `cust_${randomSuffix}@lastella-store.internal`;
    const securePassword = `LST_c!_${generateSecureRandomHex(24)}`;

    try {
      const created = await createUserWithEmailAndPassword(auth, email, securePassword);
      // Persist in secure IndexedDB vault so re-auth after admin logout keeps the exact same UID
      await saveVaultCredential({
        email,
        password: securePassword,
        uid: created.user.uid,
      });

      if (typeof localStorage !== 'undefined') {
        // Store ONLY non-sensitive identifier metadata (email & uid), NEVER the password!
        localStorage.setItem(CUST_AUTH_KEY, JSON.stringify({
          email,
          uid: created.user.uid,
          createdAt: new Date().toISOString(),
        }));

        try {
          const past = JSON.parse(localStorage.getItem('lastella_cust_past_uids') || '[]');
          if (Array.isArray(past) && !past.includes(created.user.uid)) {
            past.push(created.user.uid);
            localStorage.setItem('lastella_cust_past_uids', JSON.stringify(past.slice(-10)));
          }
        } catch {
          // ignore
        }
      }
      console.log('[LASTELLA Auth] New secure guest session provisioned with UID:', created.user.uid);
      return created.user;
    } catch (err) {
      console.error('[LASTELLA Auth] Failed to provision customer guest auth:', err);
      throw err;
    }
  })().finally(() => {
    inFlightCustomerAuthPromise = null;
  });

  return inFlightCustomerAuthPromise;
}


// Error Handling Infrastructure conforming to Skill requirements
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function isQuotaExceededError(error: unknown): boolean {
  if (!error) return false;
  const msg = (error instanceof Error ? error.message : String(error)).toLowerCase();
  return (
    msg.includes('quota exceeded') ||
    msg.includes('resource-exhausted') ||
    msg.includes('quota_exceeded') ||
    msg.includes('free daily read units')
  );
}

type QuotaListener = (exceeded: boolean, details?: string) => void;
const quotaListeners = new Set<QuotaListener>();

export function subscribeQuotaStatus(handler: QuotaListener): () => void {
  quotaListeners.add(handler);
  return () => quotaListeners.delete(handler);
}

let quotaExceededState = false;

export function getIsQuotaExceeded(): boolean {
  if (quotaExceededState) return true;
  if (typeof sessionStorage !== 'undefined') {
    return sessionStorage.getItem('lastella_firestore_quota_exceeded') === 'true';
  }
  return false;
}

export function notifyQuotaExceeded(details?: string): void {
  quotaExceededState = true;
  if (typeof sessionStorage !== 'undefined') {
    try {
      sessionStorage.setItem('lastella_firestore_quota_exceeded', 'true');
    } catch {
      // ignore
    }
  }
  quotaListeners.forEach((listener) => {
    try {
      listener(true, details);
    } catch {
      // ignore
    }
  });
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const currentUid = auth.currentUser?.uid || null;
  const isPermissionDenied =
    (error as any)?.code === 'permission-denied' ||
    errMessage.toLowerCase().includes('permission') ||
    errMessage.toLowerCase().includes('missing or insufficient permissions');

  // If a permission-denied error occurs when unauthenticated (auth.currentUser is null),
  // this is an expected unauthenticated session transition or signout event.
  if (isPermissionDenied && !currentUid) {
    console.warn(`[LASTELLA Firestore Notice]: Unauthenticated ${operationType} on "${path || 'unknown'}" rejected during auth transition.`);
    return {
      error: errMessage,
      authInfo: {
        userId: null,
        email: null,
        emailVerified: null,
        isAnonymous: null,
      },
      operationType,
      path,
    };
  }

  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: currentUid,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
    },
    operationType,
    path,
  };
  if (isQuotaExceededError(error)) {
    console.warn('[LASTELLA Firestore Notice - Quota Exceeded]:', JSON.stringify(errInfo));
    notifyQuotaExceeded(errMessage);
  } else {
    console.error('[LASTELLA Firestore Error]:', JSON.stringify(errInfo));
  }
  return errInfo;
}

// Collections references
const PRODUCTS_COLLECTION = 'products';
const ORDERS_COLLECTION = 'orders';
const SETTINGS_COLLECTION = 'settings';
const BOUTIQUE_SETTINGS_DOC = 'boutique';

// Helper to parse Firestore REST API response fields into standard JSON objects
function parseFirestoreValue(v: any): any {
  if (!v || typeof v !== 'object') return v;
  if ('stringValue' in v) return v.stringValue;
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('integerValue' in v) return Number(v.integerValue);
  if ('booleanValue' in v) return Boolean(v.booleanValue);
  if ('nullValue' in v) return null;
  if ('arrayValue' in v) {
    return (v.arrayValue.values || []).map(parseFirestoreValue);
  }
  if ('mapValue' in v) {
    const res: Record<string, any> = {};
    const fields = v.mapValue.fields || {};
    for (const key of Object.keys(fields)) {
      res[key] = parseFirestoreValue(fields[key]);
    }
    return res;
  }
  return v;
}

function parseFirestoreDoc(docObj: any): any {
  if (!docObj || !docObj.fields) return null;
  const id = docObj.name ? docObj.name.split('/').pop() : '';
  const parsed: Record<string, any> = { id };
  for (const key of Object.keys(docObj.fields)) {
    parsed[key] = parseFirestoreValue(docObj.fields[key]);
  }
  return parsed;
}

// Resilient fallback query using standard Firestore REST API
async function queryCollectionRest(collectionId: string): Promise<any[]> {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents:runQuery?key=${firebaseConfig.apiKey}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId }],
        },
      }),
    });
    if (!response.ok) {
      throw new Error(`REST query for ${collectionId} returned HTTP ${response.status}`);
    }
    const results = await response.json();
    if (!Array.isArray(results)) return [];
    return results
      .filter((item: any) => item && item.document)
      .map((item: any) => parseFirestoreDoc(item.document))
      .filter(Boolean);
  } catch (err) {
    console.warn(`[FIRESTORE] REST query fallback for ${collectionId} failed:`, err);
    return [];
  }
}

async function getDocRest(collectionId: string, docId: string): Promise<any | null> {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/${collectionId}/${docId}?key=${firebaseConfig.apiKey}`;
    const response = await fetch(url);
    if (!response.ok) return null;
    const docObj = await response.json();
    return parseFirestoreDoc(docObj);
  } catch (err) {
    console.warn(`[FIRESTORE] REST getDoc fallback for ${collectionId}/${docId} failed:`, err);
    return null;
  }
}

// Check connectivity on startup
async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('[FIRESTORE] Connected to Cloud Firestore successfully.');
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('[FIRESTORE] Client offline, will utilize offline and local cache.');
    } else if (isQuotaExceededError(error)) {
      console.warn('[FIRESTORE] Free tier daily quota reached. Will utilize local cache.');
      notifyQuotaExceeded(error instanceof Error ? error.message : String(error));
    }
  }
}
if (typeof window !== 'undefined') {
  testFirestoreConnection();
}

export const firebaseService = {
  // ONE-TIME SAFE MIGRATION
  // Genuinely empty database ONLY. Never overwrites existing Firestore database.
  // Stores a persistent Firestore migration marker so it NEVER runs again once completed.
  async runInitialMigration(): Promise<void> {
    const MIGRATION_DOC_ID = 'migration';
    const LOCAL_MIGRATION_FLAG_KEY = 'lastella_firestore_migration_done_v1';

    try {
      // 1. If this device has already confirmed migration, skip immediately
      if (typeof window !== 'undefined' && localStorage.getItem(LOCAL_MIGRATION_FLAG_KEY) === 'true') {
        return;
      }

      // 2. Check if Firestore migration marker document exists in settings collection
      const migrationRef = doc(db, SETTINGS_COLLECTION, MIGRATION_DOC_ID);
      let migrationExists = false;
      try {
        const migrationSnap = await getDoc(migrationRef);
        migrationExists = migrationSnap.exists();
      } catch (err) {
        if (isQuotaExceededError(err)) {
          console.warn('[FIRESTORE] Migration check skipped due to daily quota limit.');
          notifyQuotaExceeded();
          return;
        }
        const restDoc = await getDocRest(SETTINGS_COLLECTION, MIGRATION_DOC_ID);
        migrationExists = !!restDoc;
      }

      if (migrationExists) {
        if (typeof window !== 'undefined') {
          localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
        }
        return;
      }

      // 3. Check if Firestore products collection already contains ANY documents
      const existingProds = await this.getProducts();
      if (existingProds.length > 0) {
        // Products already exist in Cloud Firestore! Mark migration completed so it NEVER seeds defaults
        console.log(`[FIRESTORE] [PRODUCT] Existing catalog detected (${existingProds.length} items). Seeding permanently disabled.`);
        try {
          await setDoc(migrationRef, {
            completed: true,
            migratedAt: new Date().toISOString(),
            existingProductCount: existingProds.length,
            note: 'Existing Firestore database detected; initial seed permanently disabled.',
          });
        } catch {
          // ignore
        }
        if (typeof window !== 'undefined') {
          localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
        }
        return;
      }

      // 4. Genuinely blank Firestore database: seed initial catalog once
      console.log('[FIRESTORE] Genuinely empty Firestore detected. Seeding initial catalog once...');
      const batch = writeBatch(db);

      for (const product of INITIAL_PRODUCTS) {
        const productRef = doc(db, PRODUCTS_COLLECTION, product.id);
        batch.set(productRef, cleanForFirestore({
          ...product,
          createdAt: product.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }));
      }

      const settingsRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      batch.set(settingsRef, cleanForFirestore({
        ...INITIAL_SETTINGS,
        updatedAt: new Date().toISOString(),
      }), { merge: true });

      batch.set(migrationRef, cleanForFirestore({
        completed: true,
        migratedAt: new Date().toISOString(),
        seededProductCount: INITIAL_PRODUCTS.length,
        note: 'Initial catalog seeded into empty Firestore database.',
      }));

      await batch.commit();
      if (typeof window !== 'undefined') {
        localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
      }
      console.log(`[FIRESTORE] [PRODUCT] Successfully initialized Firestore database with ${INITIAL_PRODUCTS.length} products! ✨`);
    } catch (e) {
      if (isQuotaExceededError(e)) {
        console.warn('[FIRESTORE] Migration check note: daily quota reached.');
        notifyQuotaExceeded();
      } else {
        console.warn('[FIRESTORE] Migration check note:', e);
      }
    }
  },

  // REAL-TIME SUBSCRIBERS
  subscribeProducts(callback: (products: Product[]) => void): () => void {
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [PRODUCT] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [PRODUCT] Attaching real-time onSnapshot listener for products');
    const q = query(collection(db, PRODUCTS_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const prods: Product[] = [];
        snapshot.forEach((d) => {
          prods.push({ id: d.id, ...(d.data() as Omit<Product, 'id'>) });
        });
        console.log(`[FIRESTORE] [PRODUCT] onSnapshot received ${prods.length} products`);
        callback(prods);
      },
      async (error) => {
        handleFirestoreError(error, OperationType.LIST, PRODUCTS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [PRODUCT] Free tier daily quota reached. Live sync paused, relying on cached data.');
          notifyQuotaExceeded();
          return;
        }
        // Fallback: If onSnapshot encounters connection or other issues, fetch current catalog via REST
        console.warn('[FIRESTORE] [PRODUCT] onSnapshot error, falling back to REST query');
        const fallbackProds = await queryCollectionRest(PRODUCTS_COLLECTION);
        if (fallbackProds.length > 0) {
          callback(fallbackProds as Product[]);
        }
      }
    );
  },

  subscribeOrders(callback: (orders: Order[]) => void): () => void {
    if (!authService.isCurrentAdmin()) {
      console.warn('[FIRESTORE] [ORDER] Access restricted: Only authenticated administrator can subscribe to all orders.');
      callback([]);
      return () => {};
    }
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [ORDER] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [ORDER] Attaching real-time onSnapshot listener for admin orders');
    const q = query(collection(db, ORDERS_COLLECTION), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const orders: Order[] = [];
        snapshot.forEach((d) => {
          orders.push({ id: d.id, ...(d.data() as Omit<Order, 'id'>) });
        });
        console.log(`[FIRESTORE] [ORDER] Admin onSnapshot received ${orders.length} orders`);
        callback(orders);
      },
      (error) => {
        if (!auth.currentUser || !authService.isCurrentAdmin()) {
          console.log('[FIRESTORE] [ORDER] Admin listener gracefully closed on session change.');
          callback([]);
          return;
        }
        handleFirestoreError(error, OperationType.LIST, ORDERS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [ORDER] Free tier daily quota reached.');
          notifyQuotaExceeded();
        }
      }
    );
  },

  /**
   * Real-time listener strictly scoped to a single customer's orders via immutable Firebase Auth UID.
   * Conforms to Firestore Security Rules: resource.data.customerUid == request.auth.uid.
   * Customer A can NEVER see Customer B's orders.
   * Preserves customer order state during loading, auth transitions, and transient errors.
   */
  subscribeCustomerOrders(customerUid: string, callback: (orders: Order[]) => void): () => void {
    if (getIsQuotaExceeded()) {
      return () => {};
    }
    const currentAuthUser = auth.currentUser;
    if (!currentAuthUser || !currentAuthUser.uid) {
      console.warn('[FIRESTORE] [ORDER] Deferring customer orders listener: active auth session not ready.');
      // NEVER call callback([]) here! Calling callback([]) would wipe valid cached/in-memory orders during auth initialization!
      return () => {};
    }

    // Strictly enforce the authenticated UID from the active Firebase Auth session
    const verifiedUid = currentAuthUser.uid;
    if (customerUid && customerUid !== verifiedUid) {
      console.warn(`[FIRESTORE] [ORDER] Scoping query to active authenticated session UID (${verifiedUid})`);
    }

    console.log(`[FIRESTORE] [ORDER] Attaching UID-scoped real-time listener for authenticated UID: ${verifiedUid}`);
    const q = query(
      collection(db, ORDERS_COLLECTION),
      where('customerUid', '==', verifiedUid)
    );
    return onSnapshot(
      q,
      (snapshot) => {
        const orders: Order[] = [];
        snapshot.forEach((d) => {
          const data = d.data() as Omit<Order, 'id'>;
          // Invariant check: customer A never receives another customer's order
          if (data && data.customerUid === verifiedUid) {
            orders.push({ id: d.id, ...data });
          }
        });
        orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        callback(orders);
      },
      (error) => {
        // If auth state transitioned or user signed out, listener teardown is expected.
        // DO NOT wipe existing orders with callback([]) on error or transition!
        if (!auth.currentUser || auth.currentUser.uid !== verifiedUid) {
          console.log(`[FIRESTORE] [ORDER] Customer listener gracefully detached on auth transition for UID: ${verifiedUid}`);
          return;
        }
        console.warn(`[FIRESTORE] [ORDER] Customer UID query notice for ${verifiedUid}:`, error);
        handleFirestoreError(error, OperationType.LIST, `${ORDERS_COLLECTION}?customerUid=${verifiedUid}`);
      }
    );
  },

  /**
   * One-off authoritative query for all orders owned by a customer UID.
   * Used by refreshOrders() to avoid overwriting fresh cloud data with empty cache.
   */
  async getCustomerOrders(customerUid: string): Promise<Order[]> {
    if (!customerUid || getIsQuotaExceeded()) return [];
    const cleanUid = customerUid.trim();
    if (!cleanUid) return [];

    try {
      const q = query(
        collection(db, ORDERS_COLLECTION),
        where('customerUid', '==', cleanUid)
      );
      const snapshot = await getDocs(q);
      const orders: Order[] = [];
      snapshot.forEach((d) => {
        const data = d.data() as Omit<Order, 'id'>;
        if (data && data.customerUid === cleanUid) {
          orders.push({ id: d.id, ...data });
        }
      });
      orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return orders;
    } catch (e) {
      console.warn(`[FIRESTORE] [ORDER] Failed to fetch customer orders for ${cleanUid}:`, e);
      handleFirestoreError(e, OperationType.LIST, `${ORDERS_COLLECTION}?customerUid=${cleanUid}`);
      return [];
    }
  },

  /**
   * Real-time listener for a single specific order by canonical document ID.
   * Conforms to Firestore security rules: Allows customer to live-track only their own
   * order without permission errors, quota exhaustion, or exposing any other customer's order.
   */
  subscribeSingleOrder(orderId: string, callback: (order: Order | null) => void): () => void {
    if (!orderId || getIsQuotaExceeded()) {
      return () => {};
    }
    console.log(`[FIRESTORE] [ORDER-TRACKING] Attaching real-time onSnapshot listener for order: ${orderId}`);
    const orderDocRef = doc(db, ORDERS_COLLECTION, orderId);
    return onSnapshot(
      orderDocRef,
      (docSnapshot) => {
        if (docSnapshot.exists()) {
          const data = docSnapshot.data() as Omit<Order, 'id'>;
          callback({ id: docSnapshot.id, ...data });
        } else {
          callback(null);
        }
      },
      (error) => {
        if (!auth.currentUser) {
          console.log(`[FIRESTORE] [ORDER-TRACKING] Single order listener gracefully closed during session teardown for order: ${orderId}`);
          callback(null);
          return;
        }
        console.warn(`[FIRESTORE] [ORDER-TRACKING] onSnapshot error on order ${orderId}:`, error);
        handleFirestoreError(error, OperationType.GET, `${ORDERS_COLLECTION}/${orderId}`);
      }
    );
  },

  subscribeSettings(callback: (settings: StoreSettings) => void): () => void {
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [SETTINGS] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [SETTINGS] Attaching real-time onSnapshot listener for boutique settings');
    const ref = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
    return onSnapshot(
      ref,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as StoreSettings;
          console.log('[FIRESTORE] [SETTINGS] onSnapshot received boutique settings');
          callback(data);
        }
      },
      async (error) => {
        handleFirestoreError(error, OperationType.GET, SETTINGS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [SETTINGS] Free tier daily quota reached. Relying on cached settings.');
          notifyQuotaExceeded();
          return;
        }
        const fallbackSettings = await getDocRest(SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
        if (fallbackSettings) {
          callback(fallbackSettings as StoreSettings);
        }
      }
    );
  },

  // PRODUCTS CLOUD CRUD
  async getProducts(): Promise<Product[]> {
    console.log('[FIRESTORE] [PRODUCT] Fetching products from Firestore...');
    try {
      const snapshot = await getDocs(collection(db, PRODUCTS_COLLECTION));
      const prods: Product[] = [];
      snapshot.forEach((d) => {
        prods.push({ id: d.id, ...(d.data() as Omit<Product, 'id'>) });
      });
      console.log(`[FIRESTORE] [PRODUCT] Retrieved ${prods.length} products via SDK`);
      return prods;
    } catch (e) {
      console.warn('[FIRESTORE] [PRODUCT] SDK query failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.LIST, PRODUCTS_COLLECTION);
      if (isQuotaExceededError(e)) {
        return [];
      }
      const restProds = await queryCollectionRest(PRODUCTS_COLLECTION);
      console.log(`[FIRESTORE] [PRODUCT] Retrieved ${restProds.length} products via REST fallback`);
      return restProds as Product[];
    }
  },

  async addProduct(product: Omit<Product, 'id'>): Promise<Product> {
    const id = `lst-${Date.now().toString(36)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const fullProduct: Product = {
      ...product,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    console.log(`[FIRESTORE] [PRODUCT] Creating new product with canonical ID: ${id}`);
    try {
      await setDoc(doc(db, PRODUCTS_COLLECTION, id), cleanForFirestore(fullProduct));
      console.log(`[FIRESTORE] [PRODUCT] Successfully saved product ${id} to Firestore!`);
      return fullProduct;
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to create product ${id}:`, e);
      handleFirestoreError(e, OperationType.CREATE, `${PRODUCTS_COLLECTION}/${id}`);
      throw e;
    }
  },

  async updateProduct(product: Product): Promise<void> {
    if (!product || !product.id) {
      throw new Error('Cannot update product without a valid canonical Firestore document ID.');
    }
    const updated = {
      ...product,
      updatedAt: new Date().toISOString(),
    };
    console.log(`[FIRESTORE] [PRODUCT] Updating existing product: ${product.id}`);
    try {
      await setDoc(doc(db, PRODUCTS_COLLECTION, product.id), cleanForFirestore(updated), { merge: true });
      console.log(`[FIRESTORE] [PRODUCT] Successfully updated product ${product.id} in Firestore!`);
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to update product ${product.id}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${PRODUCTS_COLLECTION}/${product.id}`);
      throw e;
    }
  },

  async deleteProduct(productId: string): Promise<void> {
    if (!productId) {
      throw new Error('Cannot delete product without a valid canonical Firestore document ID.');
    }
    console.log(`[FIRESTORE] [PRODUCT] Deleting product document: ${productId}`);
    try {
      await deleteDoc(doc(db, PRODUCTS_COLLECTION, productId));
      console.log(`[FIRESTORE] [PRODUCT] Successfully deleted product ${productId} from Firestore!`);
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to delete product ${productId}:`, e);
      handleFirestoreError(e, OperationType.DELETE, `${PRODUCTS_COLLECTION}/${productId}`);
      throw e;
    }
  },

  // ORDERS CLOUD CRUD
  async getOrders(): Promise<Order[]> {
    if (!authService.isCurrentAdmin()) {
      console.warn('[FIRESTORE] [ORDER] Access restricted: Only authenticated administrator can retrieve all orders.');
      return [];
    }
    console.log('[FIRESTORE] [ORDER] Fetching all store orders as verified administrator...');
    try {
      const q = query(collection(db, ORDERS_COLLECTION), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const orders: Order[] = [];
      snapshot.forEach((d) => {
        orders.push({ id: d.id, ...(d.data() as Omit<Order, 'id'>) });
      });
      console.log(`[FIRESTORE] [ORDER] Retrieved ${orders.length} orders via SDK`);
      return orders;
    } catch (e) {
      console.warn('[FIRESTORE] [ORDER] SDK query failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.LIST, ORDERS_COLLECTION);
      return [];
    }
  },

  async createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>): Promise<Order> {
    // Ensure customer has authenticated session with an immutable Firebase Auth UID
    const user = await ensureCustomerAuth();
    const customerUid = user.uid;

    const randomSuffix = generateSecureRandomHex(8).toUpperCase();
    const trackingToken = `tok_${generateSecureRandomHex(32)}`;
    const orderNum = generateSecureOrderNumber();
    const orderId = `ord_${Date.now()}_${randomSuffix}`;
    const newOrder: Order = {
      ...orderData,
      id: orderId,
      orderNumber: orderNum,
      trackingToken,
      customerUid,
      createdAt: new Date().toISOString(),
      status: 'Order Placed',
      paymentStatus: 'Pending Payment',
      paymentMethod: orderData.paymentMethod || 'bank_transfer',
      statusHistory: [
        {
          status: 'Order Placed',
          timestamp: new Date().toISOString(),
          note: 'Order submitted via Bank Transfer - Pending Payment Verification',
        },
      ],
    };

    console.log(`[FIRESTORE] [ORDER] Writing new unique order ${orderId} (#${orderNum}) for UID ${customerUid}...`);
    try {
      const sanitizedOrder = cleanForFirestore(newOrder);
      await setDoc(doc(db, ORDERS_COLLECTION, orderId), sanitizedOrder);
      console.log(`[FIRESTORE] [ORDER] Successfully wrote order ${orderId} to Firestore!`);
      return newOrder;
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to write order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.CREATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  async updateOrderStatus(orderId: string, status: OrderStatus, note?: string): Promise<void> {
    if (!authService.isCurrentAdmin()) {
      throw new Error('Unauthorized: Only store administrator can update order status.');
    }
    console.log(`[FIRESTORE] [ORDER] Updating status of order ${orderId} to ${status}`);
    try {
      const orderRef = doc(db, ORDERS_COLLECTION, orderId);
      let existingOrder: Order | null = null;
      try {
        const orderDoc = await getDoc(orderRef);
        if (orderDoc.exists()) {
          existingOrder = orderDoc.data() as Order;
        }
      } catch {
        // ignore
      }

      const statusHistory = existingOrder?.statusHistory || [];
      statusHistory.push({
        status,
        timestamp: new Date().toISOString(),
        note: note || `Status updated to ${status}`,
      });

      await updateDoc(orderRef, cleanForFirestore({
        status,
        statusHistory,
        updatedAt: new Date().toISOString(),
      }));
      console.log(`[FIRESTORE] [ORDER] Status of order ${orderId} updated to ${status}!`);
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to update status of order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  async updateOrderPaymentStatus(orderId: string, paymentStatus: 'Pending Payment' | 'Paid' | 'Payment Verified' | 'Refunded'): Promise<void> {
    if (!authService.isCurrentAdmin()) {
      throw new Error('Unauthorized: Only store administrator can update payment status.');
    }
    console.log(`[FIRESTORE] [ORDER] Updating payment status of order ${orderId} to ${paymentStatus}`);
    try {
      const orderRef = doc(db, ORDERS_COLLECTION, orderId);
      let existingOrder: Order | null = null;
      try {
        const orderDoc = await getDoc(orderRef);
        if (orderDoc.exists()) {
          existingOrder = orderDoc.data() as Order;
        }
      } catch {
        // ignore
      }

      const statusHistory = existingOrder?.statusHistory || [];
      const paymentNote =
        paymentStatus === 'Payment Verified'
          ? 'Bank transfer payment verified by store manager'
          : `Payment status updated to ${paymentStatus}`;

      // Avoid duplicating identical payment status history entry
      const lastEntry = statusHistory[statusHistory.length - 1];
      if (!lastEntry || lastEntry.note !== paymentNote) {
        statusHistory.push({
          status: existingOrder?.status || 'Order Placed',
          timestamp: new Date().toISOString(),
          note: paymentNote,
        });
      }

      await updateDoc(orderRef, cleanForFirestore({
        paymentStatus,
        statusHistory,
        updatedAt: new Date().toISOString(),
      }));
      console.log(`[FIRESTORE] [ORDER] Payment status of order ${orderId} updated to ${paymentStatus}!`);
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to update payment status of order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  // SETTINGS CLOUD CRUD
  async getSettings(): Promise<StoreSettings> {
    console.log('[FIRESTORE] [SETTINGS] Fetching store settings from Firestore...');
    try {
      const docRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      const snapshot = await getDoc(docRef);
      if (snapshot.exists()) {
        console.log('[FIRESTORE] [SETTINGS] Successfully fetched settings via SDK');
        return snapshot.data() as StoreSettings;
      }
      return INITIAL_SETTINGS;
    } catch (e) {
      console.warn('[FIRESTORE] [SETTINGS] SDK fetch failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.GET, `${SETTINGS_COLLECTION}/${BOUTIQUE_SETTINGS_DOC}`);
      if (isQuotaExceededError(e)) {
        return INITIAL_SETTINGS;
      }
      const restSettings = await getDocRest(SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      if (restSettings) {
        console.log('[FIRESTORE] [SETTINGS] Successfully fetched settings via REST');
        return restSettings as StoreSettings;
      }
      return INITIAL_SETTINGS;
    }
  },

  async saveSettings(settings: StoreSettings): Promise<void> {
    console.log('[FIRESTORE] [SETTINGS] Saving store settings to Firestore...');
    try {
      const docRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      // Securely omit adminPasscode so plaintext credentials are never saved in Firestore
      const { adminPasscode, ...safeSettings } = settings;
      await setDoc(docRef, cleanForFirestore({
        ...safeSettings,
        updatedAt: new Date().toISOString(),
      }), { merge: true });
      console.log('[FIRESTORE] [SETTINGS] Successfully saved store settings in Firestore!');
    } catch (e) {
      console.error('[FIRESTORE] [SETTINGS] Failed to save store settings:', e);
      handleFirestoreError(e, OperationType.WRITE, `${SETTINGS_COLLECTION}/${BOUTIQUE_SETTINGS_DOC}`);
      throw e;
    }
  },

  // CLOUDINARY PRODUCT IMAGE UPLOADS (Unsigned preset: lastella_products)
  async uploadProductImage(
    file: File | Blob,
    onProgress?: (percent: number) => void
  ): Promise<string> {
    console.log('[CLOUDINARY] Uploading image via uploadProductImageToCloudinary');
    return uploadProductImageToCloudinary(file, onProgress);
  },
};

export { processAndCompressImage, uploadProductImageToCloudinary };

