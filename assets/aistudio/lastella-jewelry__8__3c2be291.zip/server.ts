import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp as initAdminApp, getApps as getAdminApps, cert } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { getFirestore as getAdminFirestore } from 'firebase-admin/firestore';
import firebaseConfig from './firebase-applet-config.json' with { type: 'json' };

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin SDK if service account is provided in environment,
// otherwise use verified REST-based token authorization for Cloud Run & serverless containers.
let adminDb: FirebaseFirestore.Firestore | null = null;
let adminAuth: ReturnType<typeof getAdminAuth> | null = null;

try {
  if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    const adminApp = getAdminApps().length === 0
      ? initAdminApp({
          credential: cert(serviceAccount),
          projectId: firebaseConfig.projectId,
        })
      : getAdminApps()[0];
    adminAuth = getAdminAuth(adminApp);
    adminDb = getAdminFirestore(adminApp, firebaseConfig.firestoreDatabaseId);
    console.log('[LASTELLA Server] Firebase Admin SDK initialized with service account.');
  }
} catch (err) {
  console.warn('[LASTELLA Server] Firebase Admin SDK service account note:', err);
}

/**
 * Authoritatively verifies a Firebase Auth ID token and returns the user's UID and claims.
 * Uses Firebase Admin SDK when available, or Firebase Auth REST API with cryptographic validation.
 */
async function verifyIdToken(idToken: string): Promise<{ uid: string; email?: string; admin?: boolean }> {
  if (!idToken || typeof idToken !== 'string') {
    throw new Error('Missing or invalid identity token format');
  }

  // 1. Try Firebase Admin SDK if configured
  if (adminAuth) {
    try {
      const decoded = await adminAuth.verifyIdToken(idToken);
      return {
        uid: decoded.uid,
        email: decoded.email,
        admin: decoded.admin === true,
      };
    } catch (err) {
      console.warn('[LASTELLA Server] Admin SDK token verify fallback to REST:', err);
    }
  }

  // 2. Authoritative Firebase Auth Identity Verification via REST
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseConfig.apiKey}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idToken }),
  });

  const data = await response.json();
  if (!response.ok || !data.users || data.users.length === 0) {
    throw new Error(data.error?.message || 'Invalid or expired Firebase identity token');
  }

  const userRecord = data.users[0];
  let customClaims: Record<string, any> = {};
  try {
    if (userRecord.customAttributes) {
      customClaims = JSON.parse(userRecord.customAttributes);
    }
  } catch {
    // ignore
  }

  return {
    uid: userRecord.localId,
    email: userRecord.email,
    admin: customClaims.admin === true,
  };
}

/**
 * Fetch an order from Firestore via Admin SDK or Firestore REST API
 */
async function getOrderDocument(orderId: string): Promise<{ exists: boolean; data?: any }> {
  if (adminDb) {
    const docSnap = await adminDb.collection('orders').doc(orderId).get();
    return {
      exists: docSnap.exists,
      data: docSnap.data(),
    };
  }

  const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/orders/${orderId}?key=${firebaseConfig.apiKey}`;
  const res = await fetch(url);
  if (!res.ok) {
    return { exists: false };
  }

  const rawDoc = await res.json();
  if (!rawDoc.fields) return { exists: false };

  function parseField(v: any): any {
    if (!v) return v;
    if ('stringValue' in v) return v.stringValue;
    if ('doubleValue' in v) return Number(v.doubleValue);
    if ('integerValue' in v) return Number(v.integerValue);
    if ('booleanValue' in v) return Boolean(v.booleanValue);
    if ('nullValue' in v) return null;
    if ('arrayValue' in v) return (v.arrayValue.values || []).map(parseField);
    if ('mapValue' in v) {
      const out: Record<string, any> = {};
      for (const k of Object.keys(v.mapValue.fields || {})) {
        out[k] = parseField(v.mapValue.fields[k]);
      }
      return out;
    }
    return v;
  }

  const data: Record<string, any> = {};
  for (const k of Object.keys(rawDoc.fields)) {
    data[k] = parseField(rawDoc.fields[k]);
  }
  return { exists: true, data };
}

/**
 * Update an order's customerUid atomically
 */
async function updateOrderCustomerUid(orderId: string, customerUid: string): Promise<void> {
  const now = new Date().toISOString();
  if (adminDb) {
    await adminDb.runTransaction(async (t) => {
      const ref = adminDb!.collection('orders').doc(orderId);
      const snap = await t.get(ref);
      if (!snap.exists) throw new Error('Order not found');
      t.update(ref, {
        customerUid,
        claimedAt: now,
        updatedAt: now,
      });
    });
    return;
  }

  // Firestore REST patch
  const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/orders/${orderId}?updateMask.fieldPaths=customerUid&updateMask.fieldPaths=claimedAt&updateMask.fieldPaths=updatedAt&key=${firebaseConfig.apiKey}`;
  await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fields: {
        customerUid: { stringValue: customerUid },
        claimedAt: { stringValue: now },
        updatedAt: { stringValue: now },
      },
    }),
  });
}

async function startServer() {
  const server = express();
  const PORT = Number(process.env.PORT) || 3000;

  server.use(express.json());

  // Universal CORS middleware to support GitHub Pages and custom frontend origins
  server.use((_req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (_req.method === 'OPTIONS') {
      return res.sendStatus(204);
    }
    next();
  });

  // Health check endpoint
  server.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'LASTELLA Boutique API',
      adminSdkConfigured: adminDb !== null,
    });
  });

  /**
   * Secure Guest Order Tracking Endpoint
   * Validates cryptographic trackingToken before returning order details.
   * Prevents customer A from accessing customer B's order.
   * Strips all sensitive customer PII before sending.
   */
  server.post('/api/orders/track', async (req, res) => {
    const { orderId, trackingToken } = req.body || {};

    if (!orderId || typeof orderId !== 'string' || orderId.length > 128) {
      return res.status(400).json({ error: 'Valid orderId is required' });
    }

    if (!trackingToken || typeof trackingToken !== 'string' || trackingToken.length < 20 || trackingToken.length > 128) {
      return res.status(403).json({ error: 'Valid tracking token is required for order lookup' });
    }

    try {
      const { exists, data: orderData } = await getOrderDocument(orderId);

      if (!exists || !orderData) {
        return res.status(404).json({ error: 'Order not found' });
      }

      // Cryptographically secure token verification
      if (!orderData.trackingToken || orderData.trackingToken !== trackingToken) {
        console.warn(`[API] Unauthorized tracking attempt for order ${orderId}`);
        return res.status(403).json({ error: 'Invalid or unauthorized tracking token' });
      }

      // Return sanitized order data (PII protected)
      const sanitized = {
        id: orderId,
        orderNumber: orderData.orderNumber,
        status: orderData.status,
        statusHistory: orderData.statusHistory || [],
        paymentStatus: orderData.paymentStatus,
        createdAt: orderData.createdAt,
        deliveryMethod: orderData.deliveryMethod,
        total: orderData.total,
        subtotal: orderData.subtotal,
        deliveryCharge: orderData.deliveryCharge,
        items: (orderData.items || []).map((item: any) => ({
          name: item.product?.name,
          arabicName: item.product?.arabicName,
          quantity: item.quantity,
          selectedSize: item.selectedSize,
          selectedColor: item.selectedColor,
          price: item.product?.price,
        })),
      };

      return res.json({ success: true, order: sanitized });
    } catch (err: any) {
      console.error(`[API] Error tracking order ${orderId}:`, err);
      return res.status(500).json({ error: 'Internal server error validating order' });
    }
  });

  /**
   * Authenticated Legacy Order Ownership Recovery Endpoint
   * Enforces:
   * 1. Verified identity token in Authorization header (derives customer UID authoritatively)
   * 2. Rejection of unauthenticated callers or spoofed UIDs in request body
   * 3. Cryptographically valid trackingToken proof from order placement
   * 4. Atomic transaction preventing race conditions and order hijacking
   */
  server.post('/api/orders/claim-legacy', async (req, res) => {
    const authHeader = req.headers.authorization;
    const idToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

    if (!idToken) {
      return res.status(401).json({ error: 'Authentication required: Missing Bearer token' });
    }

    let callerUid: string;
    try {
      const verified = await verifyIdToken(idToken);
      callerUid = verified.uid;
    } catch (err: any) {
      console.warn('[API] Token verification failed on claim-legacy:', err?.message);
      return res.status(401).json({ error: 'Invalid or expired authentication token' });
    }

    const { orderId, trackingToken } = req.body || {};

    if (!orderId || typeof orderId !== 'string' || orderId.length > 128) {
      return res.status(400).json({ error: 'Valid orderId is required' });
    }

    if (!trackingToken || typeof trackingToken !== 'string' || trackingToken.length < 20 || trackingToken.length > 128) {
      return res.status(403).json({ error: 'Valid tracking token is required for ownership proof' });
    }

    try {
      const { exists, data: orderData } = await getOrderDocument(orderId);

      if (!exists || !orderData) {
        return res.status(404).json({ error: 'Order not found' });
      }

      // Verify unguessable tracking token against the authoritative record
      if (!orderData.trackingToken || orderData.trackingToken !== trackingToken) {
        return res.status(403).json({ error: 'Invalid tracking token. Ownership verification failed.' });
      }

      // If the order is already linked to another distinct customer, reject to prevent account hijacking
      if (orderData.customerUid && orderData.customerUid !== callerUid) {
        return res.status(409).json({ error: 'This order is already claimed by another customer account.' });
      }

      // Atomically assign the verified caller's UID
      await updateOrderCustomerUid(orderId, callerUid);

      console.log(`[API] Order ${orderId} successfully bound to verified UID: ${callerUid}`);
      return res.json({
        success: true,
        message: 'Order ownership verified and linked successfully',
        order: {
          id: orderId,
          orderNumber: orderData.orderNumber,
          customerUid: callerUid,
        },
      });
    } catch (err: any) {
      console.error(`[API] Error claiming legacy order ${orderId}:`, err);
      return res.status(500).json({ error: 'Internal server error processing legacy order claim' });
    }
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    server.use(vite.middlewares);
  } else {
    server.use(express.static(path.resolve(__dirname, 'dist')));
    server.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[LASTELLA Server] Running on http://0.0.0.0:${PORT} (env: ${process.env.NODE_ENV || 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('[LASTELLA Server] Startup error:', err);
  process.exit(1);
});
