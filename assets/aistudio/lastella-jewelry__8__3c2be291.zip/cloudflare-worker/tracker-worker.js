/**
 * LASTELLA Jewellery Cloudflare Worker API
 * 
 * Provides serverless backend routes for GitHub Pages static hosting & custom domain:
 * 1. POST /api/orders/track (or /track) - Guest order lookup with cryptographic tracking token
 * 2. POST /api/orders/claim-legacy (or /claim-legacy) - Authenticated order ownership recovery
 * 3. POST / (Email notification trigger matching lastella-orders-mail-v2)
 *
 * Environment Bindings (configured in Cloudflare Dashboard Secrets):
 * - FIREBASE_API_KEY: Firebase Web API Key from firebase-applet-config.json
 * - FIREBASE_PROJECT_ID: "gen-lang-client-0637631484"
 * - FIRESTORE_DATABASE_ID: "ai-studio-lastellajewelry-efd3dfa3-a01c-4ed6-b180-7ec71f8b8354"
 * - FIREBASE_SERVICE_ACCOUNT: Optional JSON service account for server-side Admin authorization
 * - FIRESTORE_ADMIN_TOKEN: Optional server authorization bearer token
 */

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400',
};

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...CORS_HEADERS,
    },
  });
}

function parseFirestoreValue(v) {
  if (!v || typeof v !== 'object') return v;
  if ('stringValue' in v) return v.stringValue;
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('integerValue' in v) return Number(v.integerValue);
  if ('booleanValue' in v) return Boolean(v.booleanValue);
  if ('nullValue' in v) return null;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(parseFirestoreValue);
  if ('mapValue' in v) {
    const res = {};
    const fields = v.mapValue.fields || {};
    for (const key of Object.keys(fields)) {
      res[key] = parseFirestoreValue(fields[key]);
    }
    return res;
  }
  return v;
}

// In-memory token cache for isolate lifetime
let cachedOAuthToken = null;
let tokenExpiresAt = 0;

function base64UrlEncode(data) {
  let str = '';
  if (typeof data === 'string') {
    str = btoa(data);
  } else {
    const bytes = new Uint8Array(data);
    for (let i = 0; i < bytes.byteLength; i++) {
      str += String.fromCharCode(bytes[i]);
    }
    str = btoa(str);
  }
  return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function getServiceAccountToken(serviceAccount) {
  const now = Math.floor(Date.now() / 1000);
  if (cachedOAuthToken && tokenExpiresAt > now + 60) {
    return cachedOAuthToken;
  }

  const { client_email, private_key } = serviceAccount;
  if (!client_email || !private_key) return null;

  try {
    // Clean PKCS8 PEM header/footer
    const pem = private_key
      .replace(/-----BEGIN PRIVATE KEY-----/, '')
      .replace(/-----END PRIVATE KEY-----/, '')
      .replace(/\s+/g, '');
    const binaryDer = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));

    const cryptoKey = await crypto.subtle.importKey(
      'pkcs8',
      binaryDer.buffer,
      {
        name: 'RSASSA-PKCS1-v1_5',
        hash: 'SHA-256',
      },
      false,
      ['sign']
    );

    const header = { alg: 'RS256', typ: 'JWT' };
    const claims = {
      iss: client_email,
      scope: 'https://www.googleapis.com/auth/datastore',
      aud: 'https://oauth2.googleapis.com/token',
      exp: now + 3600,
      iat: now,
    };

    const encodedHeader = base64UrlEncode(JSON.stringify(header));
    const encodedClaims = base64UrlEncode(JSON.stringify(claims));
    const signingInput = `${encodedHeader}.${encodedClaims}`;

    const encoder = new TextEncoder();
    const signature = await crypto.subtle.sign(
      'RSASSA-PKCS1-v1_5',
      cryptoKey,
      encoder.encode(signingInput)
    );

    const jwt = `${signingInput}.${base64UrlEncode(signature)}`;

    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        assertion: jwt,
      }),
    });

    if (!tokenRes.ok) {
      console.warn('[Tracker Worker] Service account token exchange failed:', tokenRes.status);
      return null;
    }

    const tokenData = await tokenRes.json();
    cachedOAuthToken = tokenData.access_token;
    tokenExpiresAt = now + (tokenData.expires_in || 3600);
    return cachedOAuthToken;
  } catch (err) {
    console.warn('[Tracker Worker] Service account token generation note:', err);
    return null;
  }
}

async function getFirestoreAuthHeader(env, callerIdToken = null) {
  if (env.FIRESTORE_ADMIN_TOKEN) {
    return `Bearer ${env.FIRESTORE_ADMIN_TOKEN}`;
  }
  if (env.FIREBASE_AUTH_TOKEN) {
    return `Bearer ${env.FIREBASE_AUTH_TOKEN}`;
  }

  if (env.FIREBASE_SERVICE_ACCOUNT) {
    try {
      const sa = typeof env.FIREBASE_SERVICE_ACCOUNT === 'string'
        ? JSON.parse(env.FIREBASE_SERVICE_ACCOUNT)
        : env.FIREBASE_SERVICE_ACCOUNT;
      const saToken = await getServiceAccountToken(sa);
      if (saToken) return `Bearer ${saToken}`;
    } catch {}
  }

  if (callerIdToken) {
    return `Bearer ${callerIdToken}`;
  }

  return null;
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    const url = new URL(request.url);
    const path = url.pathname;
    const apiKey = env.FIREBASE_API_KEY || 'AIzaSyDzH24heYs6x8Sy7kPDJurDpJdeBfuvIms';
    const projectId = env.FIREBASE_PROJECT_ID || 'gen-lang-client-0637631484';
    const databaseId = env.FIRESTORE_DATABASE_ID || 'ai-studio-lastellajewelry-efd3dfa3-a01c-4ed6-b180-7ec71f8b8354';

    // 1. Guest Order Tracking Endpoint
    if (path === '/api/orders/track' || path === '/track') {
      if (request.method !== 'POST') {
        return jsonResponse({ error: 'Method not allowed' }, 405);
      }

      let body;
      try {
        body = await request.json();
      } catch {
        return jsonResponse({ error: 'Invalid JSON body' }, 400);
      }

      const { orderId, trackingToken } = body || {};
      if (!orderId || typeof orderId !== 'string' || orderId.length > 128) {
        return jsonResponse({ error: 'orderId is required' }, 400);
      }
      if (!trackingToken || typeof trackingToken !== 'string' || trackingToken.length < 20 || trackingToken.length > 128) {
        return jsonResponse({ error: 'Valid trackingToken is required' }, 403);
      }

      try {
        const firestoreUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${databaseId}/documents/orders/${orderId}?key=${apiKey}`;
        const fetchHeaders = { 'Content-Type': 'application/json' };
        const authHeader = await getFirestoreAuthHeader(env);
        if (authHeader) {
          fetchHeaders['Authorization'] = authHeader;
        }

        const res = await fetch(firestoreUrl, { headers: fetchHeaders });
        if (!res.ok) {
          return jsonResponse({ error: 'Order not found' }, 404);
        }

        const rawDoc = await res.json();
        const fields = rawDoc.fields || {};
        const parsed = {};
        for (const k of Object.keys(fields)) {
          parsed[k] = parseFirestoreValue(fields[k]);
        }

        // Cryptographically strict tracking token verification
        if (!parsed.trackingToken || parsed.trackingToken !== trackingToken) {
          return jsonResponse({ error: 'Invalid or unauthorized tracking token' }, 403);
        }

        // Return sanitized order data (protecting customer PII)
        const sanitizedOrder = {
          id: orderId,
          orderNumber: parsed.orderNumber,
          status: parsed.status,
          statusHistory: parsed.statusHistory || [],
          paymentStatus: parsed.paymentStatus,
          createdAt: parsed.createdAt,
          deliveryMethod: parsed.deliveryMethod,
          total: parsed.total,
          subtotal: parsed.subtotal,
          deliveryCharge: parsed.deliveryCharge,
          items: (parsed.items || []).map((it) => ({
            name: it.product?.name,
            arabicName: it.product?.arabicName,
            quantity: it.quantity,
            selectedSize: it.selectedSize,
            selectedColor: it.selectedColor,
            price: it.product?.price,
          })),
        };

        return jsonResponse({ success: true, order: sanitizedOrder });
      } catch (err) {
        return jsonResponse({ error: 'Internal error tracking order' }, 500);
      }
    }

    // 2. Authenticated Legacy Order Claim Endpoint
    if (path === '/api/orders/claim-legacy' || path === '/claim-legacy') {
      if (request.method !== 'POST') {
        return jsonResponse({ error: 'Method not allowed' }, 405);
      }

      const authHeader = request.headers.get('Authorization');
      const idToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
      if (!idToken) {
        return jsonResponse({ error: 'Unauthorized: Missing Bearer ID Token' }, 401);
      }

      // Authoritative ID token validation with Google Cloud Identity Toolkit
      const verifyUrl = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${apiKey}`;
      const verifyRes = await fetch(verifyUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const verifyData = await verifyRes.json();
      if (!verifyRes.ok || !verifyData.users || verifyData.users.length === 0) {
        return jsonResponse({ error: 'Invalid or expired Firebase ID token' }, 401);
      }

      const callerUid = verifyData.users[0].localId;

      let body;
      try {
        body = await request.json();
      } catch {
        return jsonResponse({ error: 'Invalid JSON body' }, 400);
      }

      const { orderId, trackingToken } = body || {};
      if (!orderId || !trackingToken) {
        return jsonResponse({ error: 'orderId and trackingToken are required' }, 400);
      }

      try {
        const firestoreUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${databaseId}/documents/orders/${orderId}?key=${apiKey}`;
        const fetchHeaders = { 'Content-Type': 'application/json' };
        const serverAuth = await getFirestoreAuthHeader(env, idToken);
        if (serverAuth) {
          fetchHeaders['Authorization'] = serverAuth;
        }

        const orderRes = await fetch(firestoreUrl, { headers: fetchHeaders });
        if (!orderRes.ok) {
          return jsonResponse({ error: 'Order not found' }, 404);
        }

        const rawDoc = await orderRes.json();
        const fields = rawDoc.fields || {};
        const parsed = {};
        for (const k of Object.keys(fields)) {
          parsed[k] = parseFirestoreValue(fields[k]);
        }

        // Verify cryptographic tracking token
        if (!parsed.trackingToken || parsed.trackingToken !== trackingToken) {
          return jsonResponse({ error: 'Invalid tracking token. Ownership could not be verified.' }, 403);
        }

        // Check for existing conflicting owner
        if (parsed.customerUid && parsed.customerUid !== callerUid) {
          return jsonResponse({ error: 'Order is already linked to another customer account' }, 409);
        }

        // Patch customerUid in Firestore
        const now = new Date().toISOString();
        const patchUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${databaseId}/documents/orders/${orderId}?updateMask.fieldPaths=customerUid&updateMask.fieldPaths=claimedAt&updateMask.fieldPaths=updatedAt&key=${apiKey}`;
        const patchHeaders = { 'Content-Type': 'application/json' };
        if (serverAuth) {
          patchHeaders['Authorization'] = serverAuth;
        }

        const patchRes = await fetch(patchUrl, {
          method: 'PATCH',
          headers: patchHeaders,
          body: JSON.stringify({
            fields: {
              customerUid: { stringValue: callerUid },
              claimedAt: { stringValue: now },
              updatedAt: { stringValue: now },
            },
          }),
        });

        // Check Firestore update response strictly before confirming
        if (!patchRes.ok) {
          const errorText = await patchRes.text().catch(() => '');
          console.error(`[Tracker Worker] Firestore patch failed (${patchRes.status}):`, errorText);
          return jsonResponse(
            { error: `Firestore update failed (${patchRes.status}): Authorization or write denied.` },
            patchRes.status >= 400 && patchRes.status < 500 ? patchRes.status : 502
          );
        }

        return jsonResponse({
          success: true,
          message: 'Order ownership verified and claimed successfully',
          order: {
            id: orderId,
            orderNumber: parsed.orderNumber,
            customerUid: callerUid,
          },
        });
      } catch (err) {
        return jsonResponse({ error: 'Internal error processing legacy claim' }, 500);
      }
    }

    // Default 404
    return jsonResponse({ error: 'Endpoint not found on LASTELLA Worker' }, 404);
  },
};
