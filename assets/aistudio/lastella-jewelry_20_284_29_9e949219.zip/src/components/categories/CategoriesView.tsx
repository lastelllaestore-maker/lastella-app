import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCategory, Product } from '../../types';
import { ProductCard } from '../common/ProductCard';
import { ProductListingContainer } from '../common/ProductListingContainer';
import {
  Sparkles,
  Flame,
  Gift,
  Layers,
  Disc,
  CircleDot,
  ArrowLeft,
  ArrowRight,
  SlidersHorizontal,
  ArrowUpDown,
} from 'lucide-react';
import { getCategoryTranslation } from '../../i18n/translations';
import braceletsCategoryImg from '../../assets/images/regenerated_image_1791484829558.jpg';
import banglesCategoryImg from '../../assets/images/regenerated_image_1791812675949.webp';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

export const CategoriesView: React.FC = () => {
  const { products, selectedCategory, setSelectedCategory, language, t } = useStore();
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'popular'>('featured');
  const [selectedRingSize, setSelectedRingSize] = useState<number | null>(null);

  const isAr = language === 'ar';
  const ArrowBackIcon = isAr ? ArrowRight : ArrowLeft;

  const categoryList: {
    name: ProductCategory;
    arabic: string;
    desc: string;
    descAr: string;
    image: string;
    icon: React.ReactNode;
  }[] = [
    {
      name: 'New Arrivals',
      arabic: 'وصل حديثاً',
      desc: 'Fresh luxury releases with mirror 18K luster',
      descAr: 'أحدث الإطلاقات الفاخرة بلمعان الذهب عيار 18',
      image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80',
      icon: <Sparkles className="w-5 h-5 text-[#C5A059]" />,
    },
    {
      name: 'Necklaces',
      arabic: 'القلائد والعقود',
      desc: 'Layered chains, pendants & pearl medallions',
      descAr: 'سلاسل متعددة الطبقات وعقود لؤلؤ ودلايات',
      image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=600&q=80',
      icon: <Disc className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Bracelets',
      arabic: 'الأساور الفاخرة',
      desc: 'Tennis crystal cuffs, charm chains & delicate links',
      descAr: 'أساور تنس كريستالية وسلاسل ساحرة وناعمة',
      image: braceletsCategoryImg,
      icon: <CircleDot className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Bangles',
      arabic: 'البناجر الخليجية',
      desc: 'Rigid luxury cuffs & statement open-hinge bangles',
      descAr: 'بناجر صلبة وأساور مفتوحة بتصاميم ملكية فاخرة',
      image: banglesCategoryImg,
      icon: <CircleDot className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Anklets',
      arabic: 'الخلاخل الأنيقة',
      desc: 'Dainty shimmer foot chains & beach luxury charms',
      descAr: 'خلاخل ناعمة ببريق الذهب وسلاسل قدم أنيقة',
      image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=600&q=80',
      icon: <Sparkles className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Rings',
      arabic: 'الخواتم والدبل',
      desc: 'Solitaire, pavé bands & emerald cuts in sizes 14–19',
      descAr: 'سوليتير ودبل مرصعة وقصات فاخرة بمقاسات 14-19',
      image: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&w=600&q=80',
      icon: <CircleDot className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Brand Boxes',
      arabic: 'علب الهدايا والماركة',
      desc: 'LED lighted velvet boxes & luxury presentation cases',
      descAr: 'علب مخملية بإضاءة LED وعلب إهداء فاخرة',
      image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80',
      icon: <Gift className="w-5 h-5 text-[#832F47]" />,
    },
    {
      name: 'Best Selling',
      arabic: 'الأكثر مبيعاً',
      desc: 'Iconic jewelry loved across Muscat & Oman',
      descAr: 'القطع الأيقونية الأكثر طلباً في مسقط وعُمان',
      image: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=600&q=80',
      icon: <Flame className="w-5 h-5 text-[#F06292]" />,
    },
  ];

  // Filter products for category listing
  const filteredProducts = useMemo(() => {
    if (!selectedCategory) return products;

    let list: Product[] = [];
    if (selectedCategory === 'New Arrivals') {
      list = products.filter((p) => p.isNewArrival);
    } else if (selectedCategory === 'Best Selling') {
      list = products.filter((p) => p.isBestSeller);
    } else {
      list = products.filter((p) => p.category === selectedCategory);
    }

    // Filter by ring size if selected
    if (selectedCategory === 'Rings' && selectedRingSize) {
      list = list.filter((p) => p.sizes && p.sizes.includes(selectedRingSize));
    }

    // Sort
    if (sortBy === 'price-asc') {
      list = [...list].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      list = [...list].sort((a, b) => b.price - a.price);
    } else if (sortBy === 'popular') {
      list = [...list].sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }

    return list;
  }, [products, selectedCategory, selectedRingSize, sortBy]);

  // If NO category is selected, display the grand 8-category directory
  if (!selectedCategory) {
    return (
      <div className="space-y-5 pb-16 animate-in fade-in duration-200">
        <div className="text-center max-w-md mx-auto pt-2">
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
            {t('boutiqueDirectory')}
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#3B252E] mt-0.5">
            {t('categories')}
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            {isAr
              ? 'تصفحي تشكيلات المجوهرات الفاخرة المطلية بالذهب عيار 18 والمقاومة للماء وتغير اللون.'
              : 'Explore curated high-end artificial fashion jewelry crafted for modern elegance.'}
          </p>
        </div>

        {/* Category Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {categoryList.map((cat) => {
            const count =
              cat.name === 'New Arrivals'
                ? products.filter((p) => p.isNewArrival).length
                : cat.name === 'Best Selling'
                ? products.filter((p) => p.isBestSeller).length
                : products.filter((p) => p.category === cat.name).length;

            const translatedTitle = getCategoryTranslation(cat.name, language);
            const description = isAr ? cat.descAr : cat.desc;

            return (
              <div
                key={cat.name}
                id={`cat-card-${cat.name.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setSelectedCategory(cat.name)}
                className="group relative rounded-3xl overflow-hidden bg-white border border-[#FCE4EC] p-4 flex items-center justify-between shadow-2xs hover:shadow-md hover:border-[#F8BBD0] transition-all cursor-pointer text-start"
              >
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden shrink-0 bg-[#FFF0F4] border border-[#FCE4EC]">
                    <img
                      src={getOptimizedImageUrl(cat.image, 160, 'auto', 'fit')}
                      alt={translatedTitle}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      loading="eager"
                      decoding="async"
                      width={80}
                      height={80}
                    />
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-serif text-base sm:text-lg font-bold text-[#3B252E] group-hover:text-[#832F47] transition-colors">
                        {translatedTitle}
                      </h3>
                      <span className="text-[10px] text-stone-400 font-medium">
                        ({count} {isAr ? 'قطعة' : 'items'})
                      </span>
                    </div>
                    <p className="text-[11px] text-stone-500 font-normal leading-snug line-clamp-1 mt-0.5">
                      {description}
                    </p>
                    <span className="inline-block text-[10px] text-[#C5A059] font-medium mt-1">
                      {isAr ? cat.name : cat.arabic}
                    </span>
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full bg-[#FFF0F4] text-[#832F47] flex items-center justify-center group-hover:bg-[#E57390] group-hover:text-white transition-colors shrink-0">
                  {isAr ? '←' : '→'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const activeCategoryTitle = getCategoryTranslation(selectedCategory, language);

  // Dedicated Product Listing Page for the Selected Category
  return (
    <div className="space-y-4 pb-16 animate-in fade-in duration-200 text-start">
      {/* Category Header with Back Navigation */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#FCE4EC] subtle-card-shadow">
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => setSelectedCategory(null)}
            className="flex items-center gap-1.5 text-xs font-bold text-[#832F47] hover:underline"
          >
            <ArrowBackIcon className="w-4 h-4" />
            <span>{t('allCategories')}</span>
          </button>
          <span className="text-xs text-stone-400 font-medium">
            {filteredProducts.length} {isAr ? 'قطعة متاحة' : 'items found'}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#3B252E] flex items-center gap-2">
              <span>{activeCategoryTitle}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#EFA8BA]"></span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              {isAr
                ? 'متوفر في سلطنة عُمان بضمان سنة وتوصيل سريع'
                : 'Available in Oman with 1-Year Warranty & Fast Delivery'}
            </p>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-stone-500 font-medium">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>{t('sortBy')}:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs font-semibold text-[#832F47] bg-[#FFF0F4] border border-[#FCE4EC] rounded-xl px-2.5 py-1.5 focus:outline-hidden"
            >
              <option value="featured">{t('sortFeatured')}</option>
              <option value="popular">{t('sortPopular')}</option>
              <option value="price-asc">{t('sortPriceAsc')}</option>
              <option value="price-desc">{t('sortPriceDesc')}</option>
            </select>
          </div>
        </div>

        {/* Quick Ring Size Filter if on Rings page */}
        {selectedCategory === 'Rings' && (
          <div className="mt-4 pt-3 border-t border-[#FDE7ED] flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-[#832F47] flex items-center gap-1">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#E57390]" /> {isAr ? 'تصفية حسب المقاس:' : 'Filter Size:'}
            </span>
            <button
              onClick={() => setSelectedRingSize(null)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                selectedRingSize === null
                  ? 'bg-[#E57390] text-white'
                  : 'bg-[#FFF0F4] text-stone-600 hover:bg-[#FDE7ED]'
              }`}
            >
              {t('all')}
            </button>
            {[14, 15, 16, 17, 18, 19].map((size) => (
              <button
                key={size}
                onClick={() => setSelectedRingSize(size === selectedRingSize ? null : size)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedRingSize === size
                    ? 'bg-[#E57390] text-white shadow-xs'
                    : 'bg-[#FFF0F4] text-stone-700 hover:bg-[#FDE7ED]'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Category Pills Quick Switcher */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {categoryList.map((cat) => (
          <button
            key={cat.name}
            onClick={() => setSelectedCategory(cat.name)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
              selectedCategory === cat.name
                ? 'bg-[#E57390] text-white shadow-xs'
                : 'bg-white text-stone-600 border border-[#FCE4EC] hover:bg-[#FFF0F4]'
            }`}
          >
            {getCategoryTranslation(cat.name, language)}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-3xl border border-[#FCE4EC] p-8">
          <p className="text-sm font-semibold text-stone-500">
            {isAr ? 'لا توجد منتجات حالياً في هذا القسم.' : 'No jewelry currently in this category.'}
          </p>
          <button
            onClick={() => setSelectedCategory(null)}
            className="mt-3 px-4 py-2 bg-[#E57390] text-white text-xs font-bold rounded-xl shadow-xs"
          >
            {isAr ? 'عرض جميع التشكيلات' : 'View All Jewelry'}
          </button>
        </div>
      ) : (
        <ProductListingContainer id="categories-products-grid">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      )}
    </div>
  );
};
