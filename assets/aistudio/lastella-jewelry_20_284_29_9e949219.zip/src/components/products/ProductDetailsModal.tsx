import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { Product } from '../../types';
import { getCategoryTranslation } from '../../i18n/translations';
import {
  X,
  Heart,
  ShoppingBag,
  Droplets,
  Sparkles,
  Clock,
  AlertTriangle,
  Minus,
  Plus,
  Share2,
  ZoomIn,
  Award,
} from 'lucide-react';
import { RingSizeModal } from '../common/RingSizeModal';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';
import { translateSizeToArabic, translateColorToArabic } from '../../services/translationService';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({ product, onClose }) => {
  const {
    formatOMR,
    addToCart,
    toggleWishlist,
    isInWishlist,
    showToast,
    language,
    t,
  } = useStore();

  const isAr = language === 'ar';

  const hasVariants = !!(product?.variants && product.variants.length > 0);

  // Available sizes derived from variants or legacy sizes
  const sizesList: { en: string; ar?: string }[] = useMemo(() => {
    if (!product) return [];
    if (hasVariants) {
      const list: { en: string; ar?: string }[] = [];
      const seen = new Set<string>();
      product.variants!.forEach((v) => {
        const val = (v.sizeEn || '').trim();
        if (val && !seen.has(val)) {
          seen.add(val);
          list.push({ en: val, ar: v.sizeAr || (val ? translateSizeToArabic(val) : undefined) });
        }
      });
      return list;
    }
    return (product.sizes || []).map((s) => ({
      en: String(s),
      ar: translateSizeToArabic(String(s)),
    }));
  }, [product, hasVariants]);

  // Available colors derived from variants or legacy colors
  const colorsList: { en: string; ar?: string }[] = useMemo(() => {
    if (!product) return [];
    if (hasVariants) {
      const list: { en: string; ar?: string }[] = [];
      const seen = new Set<string>();
      product.variants!.forEach((v) => {
        const val = (v.colorEn || '').trim();
        if (val && !seen.has(val)) {
          seen.add(val);
          list.push({ en: val, ar: v.colorAr });
        }
      });
      return list;
    }
    return (product.colors || []).map((c) => ({
      en: c,
      ar: translateColorToArabic(c),
    }));
  }, [product, hasVariants]);

  const hasSizes = sizesList.length > 0;
  const hasColors = colorsList.length > 0;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<number | string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  // Reset variant selections when product changes
  useEffect(() => {
    if (product) {
      const initSize = sizesList.length === 1 ? sizesList[0].en : undefined;
      const initColor = colorsList.length === 1 ? colorsList[0].en : undefined;
      setSelectedSize(initSize);
      setSelectedColor(initColor);
      setQuantity(1);
      setActiveImageIndex(0);
    }
  }, [product?.id, sizesList.length, colorsList.length]);

  // Match active variant
  const matchedVariant = useMemo(() => {
    if (!product || !hasVariants) return null;
    return (
      product.variants!.find((v) => {
        const sMatch = !hasSizes || !selectedSize || v.sizeEn === String(selectedSize);
        const cMatch = !hasColors || !selectedColor || v.colorEn === selectedColor;
        return sMatch && cMatch;
      }) || null
    );
  }, [product, hasVariants, hasSizes, hasColors, selectedSize, selectedColor]);

  // Check if a color has available stock for the currently selected size
  const isColorOptionAvailable = (colorEn: string) => {
    if (product?.inStock === false) return false;
    if (!hasVariants) return true;
    return product.variants!.some((v) => {
      const sizeMatch = !hasSizes || !selectedSize || v.sizeEn === String(selectedSize);
      return sizeMatch && v.colorEn === colorEn && v.available !== false;
    });
  };

  // Check if a size has available stock for the currently selected color
  const isSizeOptionAvailable = (sizeEn: string) => {
    if (product?.inStock === false) return false;
    if (!hasVariants) return true;
    return product.variants!.some((v) => {
      const colorMatch = !hasColors || !selectedColor || v.colorEn === selectedColor;
      return colorMatch && v.sizeEn === sizeEn && v.available !== false;
    });
  };

  if (!product) return null;

  const inWishlist = isInWishlist(product.id);
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0;

  const displayName = isAr && product.arabicName ? product.arabicName : product.name;
  const secondaryName = isAr ? product.name : product.arabicName;
  const displayDescription = isAr && product.arabicDescription ? product.arabicDescription : product.description;
  const displayMaterials = isAr && product.arabicMaterials ? product.arabicMaterials : product.materials;
  const displayCare = isAr && product.arabicCareInstructions
    ? product.arabicCareInstructions
    : product.careInstructions || t('defaultCareInstructions');

  const handleAddToCart = () => {
    if (product.inStock === false) {
      showToast(
        isAr
          ? 'عذراً، هذه القطعة غير متوفرة حالياً للطلب'
          : 'Sorry, this product is currently unavailable for order'
      );
      return;
    }
    if (hasSizes && selectedSize === undefined) {
      showToast(isAr ? 'يرجى اختيار المقاس المطلوب أولاً' : 'Please select a size first');
      return;
    }
    if (hasColors && selectedColor === undefined) {
      showToast(isAr ? 'يرجى اختيار اللون المطلوب أولاً' : 'Please select a color first');
      return;
    }
    if (matchedVariant && matchedVariant.available === false) {
      showToast(
        isAr
          ? 'عذراً، هذا الخيار غير متوفر حالياً في المخزن'
          : 'Sorry, this variant is currently out of stock'
      );
      return;
    }

    addToCart(
      product,
      quantity,
      selectedSize,
      selectedColor,
      matchedVariant?.id,
      matchedVariant?.sizeAr || (selectedSize ? translateSizeToArabic(String(selectedSize)) : undefined),
      matchedVariant?.colorAr || (selectedColor ? translateColorToArabic(selectedColor) : undefined)
    );
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `LASTELLA - ${displayName}`,
          text: isAr
            ? `شاهدي هذه القطعة المميزة ${displayName} من مجوهرات لاستيلا سلطنة عُمان!`
            : `Check out this gorgeous ${product.name} at LASTELLA Jewelry Oman!`,
          url: window.location.href,
        });
      } catch {
        // Ignored or cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast(isAr ? 'تم نسخ الرابط للحافظة! 📋' : 'Link copied to clipboard! 📋');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200" dir={isAr ? 'rtl' : 'ltr'}>
      <div className="bg-[#FFF9FB] w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto max-h-[92vh] flex flex-col relative">
        {/* Sticky Top Close & Actions */}
        <div className={`absolute top-3 ${isAr ? 'left-3' : 'right-3'} z-30 flex items-center gap-2`}>
          <button
            onClick={handleShare}
            className="p-2.5 rounded-full bg-white/95 backdrop-blur-md text-stone-600 hover:text-[#832F47] shadow-2xs border border-[#FCE4EC] transition-all active:scale-90"
            title={t('switchLanguage')}
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => toggleWishlist(product.id)}
            className={`p-2.5 rounded-full backdrop-blur-md shadow-2xs border border-[#FCE4EC] transition-all active:scale-90 ${
              inWishlist
                ? 'bg-[#E57390] text-white border-[#E57390]'
                : 'bg-white/95 text-stone-600 hover:text-[#832F47]'
            }`}
            title={t('navWishlist')}
          >
            <Heart className={`w-4 h-4 ${inWishlist ? 'fill-white stroke-white' : ''}`} />
          </button>
          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/95 backdrop-blur-md text-stone-700 hover:text-[#832F47] shadow-2xs border border-[#FCE4EC] transition-all active:scale-90"
            title={t('gotItClose')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-5">
          {/* Main Gallery Section */}
          <div className="space-y-2.5">
            <div
              onClick={() => setIsZoomed(!isZoomed)}
              className="relative w-full aspect-square sm:aspect-4/3 rounded-2xl overflow-hidden bg-[#FFF5F8] border border-[#FCE4EC] cursor-zoom-in group flex items-center justify-center"
            >
              <img
                src={
                  isZoomed
                    ? (product.images[activeImageIndex] || product.images[0])
                    : getOptimizedImageUrl(product.images[activeImageIndex] || product.images[0], 800, 'auto', 'fit')
                }
                alt={displayName}
                className={`w-full h-full object-contain object-center transition-all duration-300 ${
                  isZoomed ? 'scale-150 z-10' : ''
                }`}
                loading="eager"
                decoding="async"
              />

              <div className={`absolute bottom-3 ${isAr ? 'left-3' : 'right-3'} bg-white/90 backdrop-blur-xs px-3 py-1 rounded-full text-[10px] font-medium text-stone-600 flex items-center gap-1 shadow-2xs pointer-events-none border border-[#FCE4EC]`}>
                <ZoomIn className="w-3 h-3 text-[#E57390]" />
                <span>{isZoomed ? t('tapToZoomOut') : t('tapToZoomIn')}</span>
              </div>

              {/* Discount / Badge */}
              <div className={`absolute top-3 ${isAr ? 'right-3' : 'left-3'} flex flex-col gap-1`}>
                {product.isBestSeller && (
                  <span className="bg-[#E57390] text-white text-[10px] font-medium tracking-wider px-3 py-1 rounded-full uppercase shadow-xs flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-[#C5A059]" /> {t('bestSellerBadge')}
                  </span>
                )}
                {hasDiscount && (
                  <span className="bg-[#E57390] text-white text-[10px] font-medium tracking-wide px-2.5 py-0.5 rounded-full shadow-xs">
                    {t('savePercent').replace('{percent}', String(discountPercent))}
                  </span>
                )}
              </div>
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setActiveImageIndex(idx);
                      setIsZoomed(false);
                    }}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 bg-[#FFF5F8] flex items-center justify-center p-0.5 ${
                      activeImageIndex === idx
                        ? 'border-[#E57390] ring-1 ring-[#E57390]/30 scale-105'
                        : 'border-[#FCE4EC] opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={getOptimizedImageUrl(img, 160, 'auto', 'fit')}
                      alt=""
                      className="w-full h-full object-contain"
                      loading="eager"
                      decoding="async"
                      width={64}
                      height={64}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title & Price Header */}
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-medium">
                {t('luxuryBrandHeader')} • {getCategoryTranslation(product.category, language)}
              </span>
              <span className="text-[10px] text-stone-400 font-mono">{t('sku')}: {product.sku}</span>
            </div>

            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-1 leading-snug">
              {displayName}
            </h2>
            {secondaryName && (
              <p className="text-xs text-stone-500 font-medium mt-0.5">
                {secondaryName}
              </p>
            )}

            {/* Price Row */}
            <div className="mt-3 flex items-baseline gap-2 flex-wrap">
              <span className="font-serif font-bold text-2xl text-[#832F47]">
                {formatOMR(product.price)}
              </span>
              {hasDiscount && (
                <span className="text-sm text-stone-400 line-through">
                  {formatOMR(product.originalPrice!)}
                </span>
              )}
              {product.inStock === false ? (
                <span className="text-[11px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded-full">
                  {t('outOfStock')}
                </span>
              ) : (
                <span className="text-[11px] font-medium text-[#832F47] bg-[#FFF0F4] border border-[#FCE4EC] px-2 py-0.5 rounded-full">
                  {t('freeGiftBoxAvailable')}
                </span>
              )}
            </div>
          </div>

          {/* Sizes Selector if configured */}
          {hasSizes && (
            <div className="p-4 bg-white rounded-2xl border border-[#FCE4EC] space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-serif font-bold text-[#832F47] tracking-wide uppercase flex items-center gap-1.5">
                  <span>{t('chooseSize')}</span>
                  {selectedSize !== undefined && (
                    <span className="text-[#3B252E] bg-[#FFF0F4] px-2 py-0.5 rounded-full border border-[#FCE4EC] font-sans font-medium text-[11px]">
                      {t('sizeLabel')} {isAr ? (sizesList.find((s) => s.en === String(selectedSize))?.ar || translateSizeToArabic(String(selectedSize))) : selectedSize}
                    </span>
                  )}
                </label>
                {(product.category === 'Rings' || sizesList.some((s) => !isNaN(Number(s.en)))) && (
                  <button
                    onClick={() => setIsSizeGuideOpen(true)}
                    className="text-xs font-medium text-[#C5A059] hover:text-[#832F47] underline flex items-center gap-1 cursor-pointer"
                  >
                    {t('sizeGuide1419')}
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {sizesList.map((szObj) => {
                  const isSelected = String(selectedSize) === String(szObj.en);
                  const isNumeric = !isNaN(Number(szObj.en));
                  const isAvail = isSizeOptionAvailable(szObj.en);
                  const szLabel = isAr ? (szObj.ar || translateSizeToArabic(szObj.en)) : szObj.en;
                  return (
                    <button
                      key={szObj.en}
                      type="button"
                      onClick={() => setSelectedSize(szObj.en)}
                      className={`h-10 rounded-xl text-xs font-medium transition-all cursor-pointer relative ${
                        isNumeric ? 'w-10 min-w-[40px]' : 'px-4'
                      } ${
                        isSelected
                          ? 'bg-[#E57390] text-white shadow-xs scale-105 font-bold ring-2 ring-[#E57390]/40'
                          : isAvail
                          ? 'bg-white text-stone-700 border border-[#FCE4EC] hover:border-[#E57390]'
                          : 'bg-stone-50 text-stone-400 border border-stone-200 opacity-60 line-through'
                      }`}
                      title={!isAvail ? (isAr ? 'غير متوفر حالياً' : 'Out of Stock') : undefined}
                    >
                      {szLabel}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Colors Selector if configured */}
          {hasColors && (
            <div className="p-4 bg-white rounded-2xl border border-[#FCE4EC] space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-serif font-bold text-[#832F47] tracking-wide uppercase flex items-center gap-1.5">
                  <span>{t('chooseColor')}</span>
                  {selectedColor && (
                    <span className="text-[#3B252E] bg-[#FFF0F4] px-2.5 py-0.5 rounded-full border border-[#FCE4EC] font-sans font-medium text-[11px]">
                      {isAr
                        ? (colorsList.find((c) => c.en === selectedColor)?.ar ||
                           (selectedColor === 'Gold' ? 'ذهبي' : selectedColor === 'Silver' ? 'فضي' : selectedColor))
                        : selectedColor}
                    </span>
                  )}
                </label>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap">
                {colorsList.map((clrObj) => {
                  const isSelected = selectedColor === clrObj.en;
                  const isAvail = isColorOptionAvailable(clrObj.en);
                  const isGold = clrObj.en.toLowerCase() === 'gold';
                  const isSilver = clrObj.en.toLowerCase() === 'silver';
                  const clrLabel = isAr ? (clrObj.ar || (isGold ? 'ذهبي' : isSilver ? 'فضي' : clrObj.en)) : clrObj.en;

                  return (
                    <button
                      key={clrObj.en}
                      type="button"
                      onClick={() => setSelectedColor(clrObj.en)}
                      className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#832F47] text-white shadow-xs ring-2 ring-[#E57390]/50 scale-[1.02]'
                          : isAvail
                          ? 'bg-white text-stone-700 border border-[#FCE4EC] hover:border-[#E57390] hover:bg-[#FFF9FB]'
                          : 'bg-stone-50 text-stone-400 border border-stone-200 opacity-60 line-through'
                      }`}
                      title={!isAvail ? (isAr ? 'غير متوفر حالياً' : 'Out of Stock') : undefined}
                    >
                      <span
                        className={`w-3.5 h-3.5 rounded-full border shadow-2xs shrink-0 ${
                          isGold
                            ? 'bg-amber-400 border-amber-600'
                            : isSilver
                            ? 'bg-slate-300 border-slate-400'
                            : 'bg-stone-300 border-stone-400'
                        }`}
                      />
                      <span>{clrLabel}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Out of Stock Notice for Variant Combination */}
          {matchedVariant && matchedVariant.available === false && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span className="font-medium">
                {isAr
                  ? 'هذا الخيار (المقاس / اللون) غير متوفر حالياً في المخزن، يرجى اختيار خيار آخر.'
                  : 'This variant option is currently out of stock. Please select another combination.'}
              </span>
            </div>
          )}

          {/* Quantity and Actions */}
          <div className="flex items-center gap-3">
            <div className="flex items-center border border-[#FCE4EC] bg-white rounded-full p-1 shrink-0">
              <button
                onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                className="w-8 h-8 rounded-full bg-[#FFF0F4] flex items-center justify-center text-[#832F47] hover:text-black active:scale-95 transition-all"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-8 text-center text-xs font-medium text-[#3B252E]">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((prev) => prev + 1)}
                className="w-8 h-8 rounded-full bg-[#FFF0F4] flex items-center justify-center text-[#832F47] hover:text-black active:scale-95 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex-1">
              <button
                id="btn-modal-add-cart"
                onClick={handleAddToCart}
                disabled={
                  product.inStock === false ||
                  (hasVariants && (
                    (hasSizes && selectedSize === undefined) ||
                    (hasColors && selectedColor === undefined) ||
                    (matchedVariant ? matchedVariant.available === false : false)
                  ))
                }
                className={`w-full py-3.5 font-semibold text-xs sm:text-sm tracking-wide rounded-full shadow-xs transition-all flex items-center justify-center gap-2 ${
                  product.inStock === false || (matchedVariant && matchedVariant.available === false)
                    ? 'bg-stone-200 text-stone-400 cursor-not-allowed opacity-70'
                    : 'bg-[#E57390] hover:bg-[#D45E7C] active:scale-95 text-white cursor-pointer'
                }`}
              >
                <ShoppingBag className="w-4 h-4 text-white" />
                <span>
                  {product.inStock === false || (matchedVariant && matchedVariant.available === false)
                    ? t('outOfStock')
                    : t('addToCart')}
                </span>
              </button>
            </div>
          </div>

          {/* Key Trust & Guarantees Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
            <div className="p-3 rounded-2xl bg-white border border-[#FCE4EC] flex items-center gap-2">
              <Award className="w-4 h-4 text-[#C5A059] shrink-0" />
              <span className="text-[10px] font-medium text-[#3B252E]">{t('warranty1Year')}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white border border-[#FCE4EC] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#E57390] shrink-0" />
              <span className="text-[10px] font-medium text-[#3B252E]">{t('everydayWear')}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white border border-[#FCE4EC] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C5A059] shrink-0" />
              <span className="text-[10px] font-medium text-[#3B252E]">{t('colorResistant')}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white border border-[#FCE4EC] flex items-center gap-2">
              <Droplets className="w-4 h-4 text-[#E57390] shrink-0" />
              <span className="text-[10px] font-medium text-[#3B252E]">{t('waterResistant')}</span>
            </div>
          </div>

          {/* Description & Materials */}
          <div className="space-y-3 pt-2 text-xs text-stone-600">
            <div>
              <h4 className="font-serif font-bold text-xs tracking-wider uppercase text-[#3B252E] mb-1">
                {t('productDescription')}
              </h4>
              <p className="leading-relaxed font-light">{displayDescription}</p>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-[#FCE4EC] space-y-1.5">
              {displayMaterials && (
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-normal text-stone-500">{t('materials')}:</span>
                  <span className="font-semibold text-[#832F47]">{displayMaterials}</span>
                </div>
              )}
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-normal text-stone-500">{t('deliveryInOman')}</span>
                <span className="font-semibold text-emerald-700">{t('fastDispatch2448')}</span>
              </div>
            </div>

            {/* Chemical Sensitivity Warning */}
            <div className="p-3.5 bg-[#FFFBF0] rounded-2xl border border-[#F6E3B8] flex items-start gap-2.5 text-stone-700">
              <AlertTriangle className="w-4 h-4 text-[#B87A1E] shrink-0 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <span className="font-semibold text-[#8C5E14]">{t('careNotice')} </span>
                {displayCare}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ring Size Modal Guide */}
      <RingSizeModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
        selectedSize={selectedSize}
        onSelectSize={(sz) => setSelectedSize(sz)}
      />
    </div>
  );
};
