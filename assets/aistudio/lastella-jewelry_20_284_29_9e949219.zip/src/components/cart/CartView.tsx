import React from 'react';
import { CartItem } from '../../types';
import { useStore } from '../../context/StoreContext';
import { getCategoryTranslation } from '../../i18n/translations';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';
import { translateSizeToArabic } from '../../services/translationService';
import {
  Trash2,
  Minus,
  Plus,
  ArrowRight,
  ArrowLeft,
  Truck,
  Building,
  Home,
  Sparkles,
  ShoppingBag,
  X,
} from 'lucide-react';

export const CartView: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    deliveryCharge,
    cartTotal,
    deliveryMethod,
    setDeliveryMethod,
    formatOMR,
    setIsCheckoutOpen,
    profile,
    setCurrentTab,
    setSelectedCategory,
    settings,
    language,
    t,
  } = useStore();

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const isItemUnavailable = (item: CartItem) => {
    if (item.product.inStock === false) return true;
    if (item.selectedVariantId && item.product.variants && item.product.variants.length > 0) {
      const variant = item.product.variants.find((v) => v.id === item.selectedVariantId);
      if (variant && variant.available === false) return true;
    }
    return false;
  };

  const hasUnavailableItems = cart.some(isItemUnavailable);

  if (cart.length === 0) {
    return (
      <div
        className="text-center py-16 bg-white rounded-3xl border border-[#FCE4EC] p-8 space-y-4 max-w-md mx-auto animate-in fade-in duration-200"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        <div className="w-16 h-16 rounded-full bg-[#FFF0F4] text-[#E57390] mx-auto flex items-center justify-center">
          <ShoppingBag className="w-8 h-8 stroke-[1.5px]" />
        </div>
        <div>
          <h3 className="font-serif text-xl font-bold text-[#3B252E]">{t('cartEmpty')}</h3>
          <p className="text-xs text-stone-500 mt-1 leading-relaxed">
            {t('cartEmptyDesc')}
          </p>
        </div>
        <button
          onClick={() => {
            setSelectedCategory(null);
            setCurrentTab('categories');
          }}
          className="px-6 py-3 bg-[#E57390] text-white text-xs font-bold rounded-2xl shadow-xs hover:bg-[#D45E7C] active:scale-95 transition-all inline-flex items-center gap-2"
        >
          <span>{t('startShopping')}</span>
          <ArrowIcon className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div
      className="space-y-5 pb-20 animate-in fade-in duration-200 max-w-4xl mx-auto"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059] font-bold">
            {isAr ? 'اختياراتكِ الفاخرة' : 'YOUR SELECTION'}
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#3B252E] mt-0.5">
            {t('cartTitle')}
          </h2>
        </div>
        <button
          onClick={clearCart}
          className="text-xs text-[#E57390] hover:text-[#832F47] font-semibold cursor-pointer"
        >
          {t('clearCart')}
        </button>
      </div>

      {/* Cart Items List */}
      <div className="space-y-3">
        {cart.map((item, idx) => {
          const itemDisplayName =
            isAr && item.product.arabicName ? item.product.arabicName : item.product.name;

          return (
            <div
              key={`${item.product.id}-${item.selectedSize || 'nosize'}-${item.selectedColor || 'nocolor'}-${idx}`}
              className="bg-white rounded-2xl border border-[#FCE4EC] p-3 sm:p-4 flex items-center gap-3 sm:gap-4 subtle-card-shadow"
            >
              {/* Image */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-[#FFF0F4] shrink-0 border border-[#FCE4EC]">
                <img
                  src={getOptimizedImageUrl(item.product.images[0], 200, 'auto', 'fit')}
                  alt={itemDisplayName}
                  className="w-full h-full object-cover"
                  loading="eager"
                  decoding="async"
                  width={96}
                  height={96}
                />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[#C5A059]">
                  {getCategoryTranslation(item.product.category, language)}
                </span>
                <h3 className="font-serif text-xs sm:text-sm font-bold text-[#3B252E] truncate">
                  {itemDisplayName}
                </h3>

                <div className="flex flex-wrap items-center gap-1.5 mt-1">
                  {item.selectedSize && (
                    <span className="text-[11px] text-[#832F47] font-semibold bg-[#FFF0F4] px-2 py-0.5 rounded-md border border-[#FCE4EC]">
                      {t('selectedSize')} {isAr ? (item.selectedSizeAr || translateSizeToArabic(String(item.selectedSize))) : item.selectedSize}
                    </span>
                  )}
                  {item.selectedColor && (
                    <span className="text-[11px] text-[#832F47] font-semibold bg-[#FFF0F4] px-2 py-0.5 rounded-md border border-[#FCE4EC] flex items-center gap-1">
                      <span
                        className={`w-2.5 h-2.5 rounded-full inline-block border ${
                          item.selectedColor.toLowerCase() === 'gold'
                            ? 'bg-amber-400 border-amber-600'
                            : item.selectedColor.toLowerCase() === 'silver'
                            ? 'bg-slate-300 border-slate-400'
                            : 'bg-stone-300 border-stone-400'
                        }`}
                      />
                      <span>
                        {isAr ? 'اللون:' : 'Color:'}{' '}
                        {isAr
                          ? (item.selectedColorAr ||
                              (item.selectedColor === 'Gold'
                                ? 'ذهبي'
                                : item.selectedColor === 'Silver'
                                ? 'فضي'
                                : item.selectedColor))
                          : item.selectedColor}
                      </span>
                    </span>
                  )}
                  {isItemUnavailable(item) && (
                    <span className="text-[10px] text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md flex items-center gap-1 font-bold">
                      <X className="w-3 h-3 text-rose-600" />
                      {isAr ? 'الخيار غير متوفر حالياً (يرجى الحذف)' : 'Option out of stock (please remove)'}
                    </span>
                  )}
                </div>

                <div className="mt-2 flex items-center justify-between">
                  <span className="font-bold text-xs sm:text-sm text-[#3B252E]">
                    {formatOMR(item.product.price)}
                  </span>

                  {/* Quantity Controls */}
                  <div className="flex items-center border border-[#FCE4EC] bg-[#FFF0F4] rounded-xl p-0.5">
                    <button
                      onClick={() =>
                        updateCartQuantity(
                          item.product.id,
                          item.quantity - 1,
                          item.selectedSize,
                          item.selectedColor,
                          item.selectedVariantId
                        )
                      }
                      className="w-6 h-6 rounded-lg bg-white flex items-center justify-center text-[#832F47] hover:text-black shadow-2xs active:scale-90 transition-all cursor-pointer"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-7 text-center text-xs font-bold text-[#3B252E]">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        updateCartQuantity(
                          item.product.id,
                          item.quantity + 1,
                          item.selectedSize,
                          item.selectedColor,
                          item.selectedVariantId
                        )
                      }
                      className="w-6 h-6 rounded-lg bg-white flex items-center justify-center text-[#832F47] hover:text-black shadow-2xs active:scale-90 transition-all cursor-pointer"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Remove */}
              <button
                onClick={() =>
                  removeFromCart(
                    item.product.id,
                    item.selectedSize,
                    item.selectedColor,
                    item.selectedVariantId
                  )
                }
                className="p-2 text-stone-400 hover:text-[#E57390] transition-colors shrink-0 cursor-pointer"
                title={t('deleteAddress')}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Delivery Method Selection */}
      <div className="bg-white rounded-3xl border border-[#FCE4EC] p-4 sm:p-5 space-y-3 subtle-card-shadow">
        <h3 className="font-brand font-bold text-xs sm:text-sm tracking-wider text-[#832F47] flex items-center gap-1.5">
          <Truck className="w-4 h-4 text-[#E57390]" />
          <span>{isAr ? 'اختيار طريقة التوصيل في عُمان' : 'SELECT OMAN DELIVERY METHOD'}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Home Delivery Option */}
          <div
            id="cart-delivery-option-home"
            onClick={() => setDeliveryMethod('home')}
            className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${
              deliveryMethod === 'home'
                ? 'border-[#E57390] bg-[#FFF0F4] shadow-xs'
                : 'border-[#FCE4EC] bg-white hover:border-[#F8BBD0]'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                  deliveryMethod === 'home'
                    ? 'border-[#E57390] bg-[#E57390]'
                    : 'border-stone-300 bg-white'
                }`}
              >
                {deliveryMethod === 'home' && (
                  <div className="w-2 h-2 rounded-full bg-white" />
                )}
              </div>
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  deliveryMethod === 'home'
                    ? 'bg-[#E57390] text-white'
                    : 'bg-[#FFF0F4] text-[#832F47]'
                }`}
              >
                <Home className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[#3B252E]">
                  {t('deliveryHomeTitle')}
                </h4>
                <p className="text-[10px] text-stone-500">
                  {t('deliveryHomeDesc')}
                </p>
              </div>
            </div>
            <span className="font-bold text-xs text-[#832F47] whitespace-nowrap">
              {formatOMR(settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2.0)}
            </span>
          </div>

          {/* Office Delivery Option */}
          <div
            id="cart-delivery-option-office"
            onClick={() => setDeliveryMethod('office')}
            className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${
              deliveryMethod === 'office'
                ? 'border-[#E57390] bg-[#FFF0F4] shadow-xs'
                : 'border-[#FCE4EC] bg-white hover:border-[#F8BBD0]'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                  deliveryMethod === 'office'
                    ? 'border-[#E57390] bg-[#E57390]'
                    : 'border-stone-300 bg-white'
                }`}
              >
                {deliveryMethod === 'office' && (
                  <div className="w-2 h-2 rounded-full bg-white" />
                )}
              </div>
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  deliveryMethod === 'office'
                    ? 'bg-[#E57390] text-white'
                    : 'bg-[#FFF0F4] text-[#832F47]'
                }`}
              >
                <Building className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[#3B252E]">
                  {t('deliveryOfficeTitle')}
                </h4>
                <p className="text-[10px] text-stone-500">
                  {t('deliveryOfficeDesc')}
                </p>
              </div>
            </div>
            <span className="font-bold text-xs text-[#832F47] whitespace-nowrap">
              {formatOMR(settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1.0)}
            </span>
          </div>
        </div>
      </div>

      {/* Summary & Checkout Actions */}
      <div className="bg-white rounded-3xl border border-[#FCE4EC] p-5 space-y-4 subtle-card-shadow">
        <h3 className="font-brand font-bold text-xs sm:text-sm tracking-wider text-[#3B252E]">
          {t('orderSummary')}
        </h3>

        <div className="space-y-2 text-xs">
          <div className="flex justify-between text-stone-600">
            <span>
              {t('subtotal')} ({cart.length} {isAr ? 'قطع' : 'items'})
            </span>
            <span className="font-bold text-stone-900">{formatOMR(cartSubtotal)}</span>
          </div>
          <div className="flex justify-between text-stone-600">
            <span>
              {t('deliveryCharge')}
              {deliveryMethod
                ? ` (${deliveryMethod === 'home' ? t('deliveryHomeTitle') : t('deliveryOfficeTitle')})`
                : ''}
            </span>
            <span
              className={
                deliveryMethod
                  ? 'font-bold text-[#832F47]'
                  : 'text-xs text-stone-400 font-medium italic'
              }
            >
              {deliveryMethod
                ? formatOMR(deliveryCharge)
                : isAr
                ? 'اختر طريقة التوصيل'
                : 'Select delivery method'}
            </span>
          </div>
          <div className="pt-2 border-t border-[#FDE7ED] flex justify-between items-baseline text-sm sm:text-base">
            <span className="font-bold text-[#3B252E]">{t('total')}</span>
            <span className="font-brand font-bold text-xl text-[#832F47]">
              {formatOMR(cartTotal)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2">
          {hasUnavailableItems && (
            <div className="p-2.5 mb-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs text-center font-medium">
              {isAr
                ? 'يرجى إزالة القطع غير المتوفرة من السلة للمتابعة إلى إتمام الطلب.'
                : 'Please remove unavailable items from your cart to proceed to checkout.'}
            </div>
          )}
          <button
            id="btn-proceed-checkout"
            onClick={() => setIsCheckoutOpen(true)}
            disabled={hasUnavailableItems}
            className={`w-full py-3.5 px-6 rounded-2xl font-bold text-xs sm:text-sm tracking-wider uppercase shadow-md transition-all flex items-center justify-center gap-2 ${
              hasUnavailableItems
                ? 'bg-stone-200 text-stone-400 cursor-not-allowed border border-stone-300'
                : 'bg-[#E57390] hover:bg-[#D45E7C] text-white active:scale-98 cursor-pointer'
            }`}
          >
            <span>{t('proceedToCheckout')}</span>
            <ArrowIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
