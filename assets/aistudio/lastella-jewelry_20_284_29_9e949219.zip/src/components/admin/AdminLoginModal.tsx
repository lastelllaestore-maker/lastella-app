import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Lock, KeyRound, Eye, EyeOff, X, ShieldCheck, ArrowRight, ArrowLeft, Mail } from 'lucide-react';

export const AdminLoginModal: React.FC = () => {
  const {
    isAdminLoginOpen,
    setIsAdminLoginOpen,
    loginAdmin,
    loginAdminWithCredentials,
    language,
  } = useStore();

  const [authMode, setAuthMode] = useState<'credentials' | 'passcode'>('credentials');
  const [email, setEmail] = useState('lastelllaestore@gmail.com');
  const [password, setPassword] = useState('');
  const [passcode, setPasscode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isAdminLoginOpen) return null;

  const isAr = language === 'ar';

  const handleClose = () => {
    setIsAdminLoginOpen(false);
    setPassword('');
    setPasscode('');
    setError('');
  };

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError(isAr ? 'الرجاء إدخال البريد الإلكتروني للمدير' : 'Please enter manager email');
      return;
    }

    if (cleanEmail !== 'lastelllaestore@gmail.com') {
      setError(
        isAr
          ? 'تم رفض الوصول: هذا الحساب غير مصرح له بإدارة المتجر. المدير المعتمد: lastelllaestore@gmail.com'
          : 'Access Denied: Account is not authorized. Authorized admin: lastelllaestore@gmail.com'
      );
      return;
    }

    if (!password) {
      setError(isAr ? 'الرجاء إدخال كلمة المرور' : 'Please enter password');
      return;
    }

    setIsLoading(true);
    try {
      const res = await loginAdminWithCredentials(cleanEmail, password);
      if (!res.success) {
        setError(res.error || (isAr ? 'تم رفض الوصول: بيانات الدخول غير صحيحة' : 'Access Denied: Invalid credentials'));
      } else {
        handleClose();
      }
    } catch (err: any) {
      setError(err?.message || (isAr ? 'تم رفض الوصول' : 'Access Denied'));
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasscodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!passcode.trim()) {
      setError(isAr ? 'الرجاء إدخال رمز المرور السري للمدير' : 'Please enter manager passcode');
      return;
    }

    setIsLoading(true);
    try {
      const res = await loginAdmin(passcode);
      if (!res.success) {
        setError(res.error || (isAr ? 'رمز المرور غير صحيح. تم رفض الوصول.' : 'Incorrect passcode. Access Denied.'));
      } else {
        handleClose();
      }
    } catch (err: any) {
      setError(err?.message || (isAr ? 'رمز المرور غير صحيح' : 'Access Denied'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-br from-[#FFF0F4] via-[#FFF9FB] to-[#FCE4EC] text-center relative border-b border-[#FCE4EC]">
          <button
            onClick={handleClose}
            className={`absolute top-4 ${isAr ? 'left-4' : 'right-4'} p-1.5 rounded-full text-stone-400 hover:text-stone-700 bg-white/80 transition-colors cursor-pointer`}
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-14 h-14 rounded-2xl bg-white text-[#832F47] mx-auto flex items-center justify-center shadow-xs border border-[#FCE4EC] mb-2.5">
            <Lock className="w-6 h-6 text-[#832F47]" />
          </div>

          <span className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059] font-bold">
            {isAr ? 'إدارة المتجر والبوتيك' : 'STORE MANAGEMENT'}
          </span>
          <h3 className="font-serif text-xl font-bold text-[#3B252E] mt-0.5">
            {isAr ? 'بوابة دخول الإدارة' : 'Manager Access Portal'}
          </h3>
          <p className="text-xs text-stone-600 mt-1 max-w-xs mx-auto">
            {isAr
              ? 'تسجيل الدخول المعتمد لمدير بوتيك لاستيلا مع صلاحيات التخزين السحابي الآمن.'
              : 'Authorized sign-in for LASTELLA manager with verified store permissions.'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="p-2 bg-[#FFF9FB] border-b border-[#FCE4EC] flex gap-1">
          <button
            type="button"
            onClick={() => {
              setAuthMode('credentials');
              setError('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              authMode === 'credentials'
                ? 'bg-white text-[#832F47] shadow-xs border border-[#FCE4EC]'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>{isAr ? 'البريد وكلمة المرور' : 'Email & Password'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('passcode');
              setError('');
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              authMode === 'passcode'
                ? 'bg-white text-[#832F47] shadow-xs border border-[#FCE4EC]'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{isAr ? 'رمز المرور PIN' : 'Passcode PIN'}</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {authMode === 'credentials' ? (
            /* Mode 1: Email & Password Form */
            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#3B252E] mb-1.5 flex items-center justify-between">
                  <span>{isAr ? 'البريد الإلكتروني المعتمد' : 'Authorized Admin Email'}</span>
                  <span className="text-[10px] text-emerald-700 font-normal">
                    lastelllaestore@gmail.com
                  </span>
                </label>
                <div className="relative">
                  <Mail
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="lastelllaestore@gmail.com"
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-3' : 'pl-10 pr-3'
                    } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#3B252E] mb-1.5">
                  {isAr ? 'كلمة المرور' : 'Password'}
                </label>
                <div className="relative">
                  <Lock
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={isAr ? 'أدخلي كلمة المرور...' : 'Enter admin password...'}
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute ${
                      isAr ? 'left-3.5' : 'right-3.5'
                    } top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer`}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5 animate-in fade-in">
                  <span>⚠️</span>
                  <span>{error}</span>
                </div>
              )}

              <div className="pt-1 flex flex-col gap-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-2xl bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-semibold text-xs tracking-wider uppercase shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? (
                    <span>{isAr ? 'جاري التحقق من الحساب...' : 'Verifying credentials...'}</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>{isAr ? 'تسجيل دخول الإدارة' : 'Admin Sign In'}</span>
                      {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleClose}
                  className="w-full py-2 text-xs text-stone-500 hover:text-[#832F47] font-medium transition-colors cursor-pointer"
                >
                  {isAr ? 'العودة إلى متجر المجوهرات' : 'Return to Customer Boutique'}
                </button>
              </div>
            </form>
          ) : (
            /* Mode 2: PIN / Passcode Form */
            <form onSubmit={handlePasscodeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#3B252E] mb-1.5 flex items-center justify-between">
                  <span>{isAr ? 'رمز مرور الإدارة (PIN)' : 'Admin Passcode'}</span>
                </label>

                <div className="relative">
                  <KeyRound
                    className={`w-4 h-4 text-stone-400 absolute ${
                      isAr ? 'right-3.5' : 'left-3.5'
                    } top-1/2 -translate-y-1/2`}
                  />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={passcode}
                    onChange={(e) => {
                      setPasscode(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={isAr ? 'أدخلي رمز المرور السري...' : 'Enter store passcode...'}
                    className={`w-full text-sm ${
                      isAr ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } py-2.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-2xl focus:outline-hidden focus:border-[#E57390] focus:ring-2 focus:ring-[#FFF0F4] font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute ${
                      isAr ? 'left-3.5' : 'right-3.5'
                    } top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer`}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5 animate-in fade-in">
                  <span>⚠️</span>
                  <span>{error}</span>
                </div>
              )}

              <div className="pt-1 flex flex-col gap-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-2xl bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-semibold text-xs tracking-wider uppercase shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? (
                    <span>{isAr ? 'جاري التحقق من الرمز...' : 'Verifying credentials...'}</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>{isAr ? 'فتح لوحة الإدارة' : 'Unlock Admin Dashboard'}</span>
                      {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleClose}
                  className="w-full py-2 text-xs text-stone-500 hover:text-[#832F47] font-medium transition-colors cursor-pointer"
                >
                  {isAr ? 'العودة إلى متجر المجوهرات' : 'Return to Customer Boutique'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
