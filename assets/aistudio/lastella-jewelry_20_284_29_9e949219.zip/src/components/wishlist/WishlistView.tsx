import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../common/ProductCard';
import { ProductListingContainer } from '../common/ProductListingContainer';
import { Heart, ShoppingBag, ArrowRight, ArrowLeft } from 'lucide-react';

export const WishlistView: React.FC = () => {
  const { wishlistProducts, addToCart, setCurrentTab, setSelectedCategory, showToast, language, t } = useStore();
  const isAr = language === 'ar';

  const handleAddAllToCart = () => {
    if (wishlistProducts.length === 0) return;
    wishlistProducts.forEach((p) => {
      addToCart(
        p,
        1,
        p.sizes && p.sizes.length > 0 ? p.sizes[0] : undefined,
        p.colors && p.colors.length > 0 ? p.colors[0] : undefined
      );
    });
    showToast(
      isAr
        ? `تمت إضافة ${wishlistProducts.length} قطعة إلى سلة التسوق 🛍️`
        : `Added ${wishlistProducts.length} item(s) to Cart 🛍️`
    );
  };

  return (
    <div className="space-y-5 pb-16 animate-in fade-in duration-200" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white rounded-3xl p-5 border border-[#FCE4EC] subtle-card-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059] font-bold">
            {isAr ? 'القطع المفضلة المحفوظة' : 'SAVED FAVORITES'}
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#3B252E] mt-0.5 flex items-center gap-2">
            <span>{t('wishlistTitle')}</span>
            <Heart className="w-5 h-5 text-[#E57390] fill-[#E57390]" />
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            {wishlistProducts.length}{' '}
            {isAr
              ? 'قطعة محفوظة للرجوع إليها لاحقاً'
              : wishlistProducts.length === 1
              ? 'item saved for later'
              : 'items saved for later'}
          </p>
        </div>

        {wishlistProducts.length > 0 && (
          <button
            onClick={handleAddAllToCart}
            className="px-5 py-2.5 bg-[#E57390] hover:bg-[#D45E7C] text-white text-xs font-bold rounded-2xl shadow-sm active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{t('addAllToCart')}</span>
          </button>
        )}
      </div>

      {/* Grid or Empty state */}
      {wishlistProducts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-[#FCE4EC] p-8 space-y-4 max-w-md mx-auto">
          <div className="w-16 h-16 rounded-full bg-[#FFF0F4] text-[#E57390] mx-auto flex items-center justify-center">
            <Heart className="w-8 h-8 stroke-[1.5px]" />
          </div>
          <div>
            <h3 className="font-serif text-xl font-bold text-[#3B252E]">{t('wishlistEmpty')}</h3>
            <p className="text-xs text-stone-500 mt-1 leading-relaxed">
              {t('wishlistEmptyDesc')}
            </p>
          </div>
          <button
            onClick={() => {
              setSelectedCategory(null);
              setCurrentTab('categories');
            }}
            className="px-6 py-3 bg-[#E57390] text-white text-xs font-bold rounded-2xl shadow-sm hover:bg-[#D45E7C] active:scale-95 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <span>{t('exploreCollection')}</span>
            {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          </button>
        </div>
      ) : (
        <ProductListingContainer id="wishlist-products-grid">
          {wishlistProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      )}
    </div>
  );
};
