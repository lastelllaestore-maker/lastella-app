import React from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Bell, Sparkles, Gift, Package, Check } from 'lucide-react';
import { storageService } from '../../services/storageService';

export const NotificationsDrawer: React.FC = () => {
  const {
    isNotificationsOpen,
    setIsNotificationsOpen,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    setCurrentTab,
    setSelectedCategory,
    language,
    t,
  } = useStore();

  if (!isNotificationsOpen) return null;

  const isAr = language === 'ar';

  const handleNotificationClick = (notif: any) => {
    markNotificationRead(notif.id);
    if (notif.orderId || notif.linkTab === 'account') {
      setCurrentTab('account');
    } else if (notif.type === 'arrival') {
      setSelectedCategory('New Arrivals');
      setCurrentTab('categories');
    } else if (notif.type === 'offer') {
      setSelectedCategory('Combos');
      setCurrentTab('categories');
    }
    setIsNotificationsOpen(false);
  };

  const handleSimulateOffer = () => {
    storageService.addNotification({
      title: isAr ? '💎 تنبيه عرض خاص: خصم 20% على العقود!' : '💎 Flash Sale Alert: 20% OFF Necklaces!',
      message: isAr
        ? 'استخدمي الكود ELEGANCE20 اليوم على جميع سلاسل الذهب عيار 18 وعقود اللؤلؤ.'
        : 'Use code ELEGANCE20 today on all 18K layered chains and pearl chokers.',
      type: 'offer',
      linkTab: 'categories',
    });
    window.location.reload();
  };

  return (
    <div className={`fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex ${isAr ? 'justify-start' : 'justify-end'} animate-in fade-in duration-200`}>
      <div
        className={`bg-[#FFF9FB] w-full max-w-md h-full shadow-2xl flex flex-col ${isAr ? 'border-r border-[#FCE4EC] animate-in slide-in-from-left' : 'border-l border-[#FCE4EC] animate-in slide-in-from-right'} duration-300 text-start`}
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-white border-b border-[#FCE4EC] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#E57390] text-white flex items-center justify-center shadow-xs">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-xs tracking-[0.15em] uppercase text-[#3B252E]">
                {t('notificationsTitle')}
              </h3>
              <p className="text-[10px] text-stone-500">
                {isAr ? 'تابعي جديد بوتيك لاستيلا سلطنة عُمان' : 'Stay updated with LASTELLA Oman'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {notifications.length > 0 && (
              <button
                onClick={markAllNotificationsRead}
                className="p-2 text-stone-500 hover:text-[#832F47] text-xs font-medium"
                title={t('markAllRead')}
              >
                <Check className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => setIsNotificationsOpen(false)}
              className="p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-[#FFF0F4] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <Bell className="w-10 h-10 text-stone-300 mx-auto" />
              <h4 className="font-serif text-base font-bold text-[#3B252E]">{t('noNotifications')}</h4>
              <p className="text-xs text-stone-400">
                {isAr ? 'ليس لديك أي إشعارات جديدة حالياً.' : "You're all caught up with orders and boutique announcements."}
              </p>
            </div>
          ) : (
            notifications.map((notif) => {
              const isOrder = notif.type === 'order';
              const isOffer = notif.type === 'offer';

              return (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                    notif.read
                      ? 'bg-white border-[#FCE4EC] opacity-80'
                      : 'bg-white border-[#E57390]/50 shadow-xs ring-1 ring-[#FFF0F4]'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isOrder
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : isOffer
                        ? 'bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC]'
                        : 'bg-[#FFFBF0] text-[#C5A059] border border-[#F6E3B8]'
                    }`}
                  >
                    {isOrder ? (
                      <Package className="w-4 h-4" />
                    ) : isOffer ? (
                      <Gift className="w-4 h-4" />
                    ) : (
                      <Sparkles className="w-4 h-4" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <h4
                        className={`text-xs font-serif font-bold truncate ${
                          notif.read ? 'text-[#3B252E]' : 'text-[#832F47]'
                        }`}
                      >
                        {notif.title}
                      </h4>
                      {!notif.read && (
                        <span className="w-2 h-2 rounded-full bg-[#E57390] shrink-0 mx-1"></span>
                      )}
                    </div>
                    <p className="text-[11px] text-stone-600 leading-snug font-normal">{notif.message}</p>
                    <span className="text-[9px] text-stone-400 font-normal mt-1 block">
                      {notif.timestamp}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer simulation action */}
        <div className="p-3.5 bg-white border-t border-[#FCE4EC] flex items-center justify-between">
          <button
            onClick={handleSimulateOffer}
            className="text-[10px] text-[#C5A059] hover:text-[#832F47] hover:underline font-medium"
          >
            {isAr ? '+ محاكاة إشعار عرض جديد' : '+ Simulate New Offer Notification'}
          </button>
          <button
            onClick={() => setIsNotificationsOpen(false)}
            className="px-4 py-1.5 bg-[#E57390] hover:bg-[#D45E7C] text-white text-xs font-semibold tracking-widest uppercase rounded-full transition-colors"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </div>
  );
};
