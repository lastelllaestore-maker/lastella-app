import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  X,
  Truck,
  Building,
  Home,
  CheckCircle2,
  Sparkles,
  Landmark,
  Copy,
  Check,
} from 'lucide-react';
import { DeliveryMethod } from '../../types';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';
import { translateSizeToArabic } from '../../services/translationService';

interface CheckoutViewProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({ isOpen, onClose }) => {
  const {
    cart,
    cartSubtotal,
    deliveryCharge,
    cartTotal,
    deliveryMethod,
    setDeliveryMethod,
    formatOMR,
    placeOrder,
    profile,
    updateProfile,
    language,
    t,
    settings,
  } = useStore();

  const isAr = language === 'ar';

  // Customer contact information (typed manually, not prefilled from another customer or device)
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [sameAsPhone, setSameAsPhone] = useState(true);

  // Exactly THREE manual delivery address text fields
  const [city, setCity] = useState('');
  const [area, setArea] = useState('');
  const [detailedAddress, setDetailedAddress] = useState('');

  const [notes, setNotes] = useState('');
  const [copiedAcc, setCopiedAcc] = useState(false);
  const paymentMethod = 'bank_transfer' as const;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handlePhoneChange = (val: string) => {
    setPhone(val);
    if (sameAsPhone) {
      setWhatsapp(val);
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmedName = customerName.trim();
    const trimmedPhone = phone.trim();
    const trimmedWhatsapp = (sameAsPhone ? phone : whatsapp).trim();
    const trimmedCity = city.trim();
    const trimmedArea = area.trim();
    const trimmedDetailedAddress = detailedAddress.trim();

    // Requirement 4 & 5: Prevent ordering unavailable products or unavailable variants
    const unavailableItem = cart.find((item) => {
      if (item.product.inStock === false) return true;
      if (item.selectedVariantId && item.product.variants && item.product.variants.length > 0) {
        const variant = item.product.variants.find((v) => v.id === item.selectedVariantId);
        if (variant && variant.available === false) return true;
      }
      return false;
    });
    if (unavailableItem) {
      setErrorMsg(
        isAr
          ? `عذراً، القطعة (${unavailableItem.product.arabicName || unavailableItem.product.name}) أو الخيار المختار غير متوفر حالياً في المخزن`
          : `Sorry, (${unavailableItem.product.name}) or the selected variant is currently out of stock.`
      );
      return;
    }

    // Validation for contact info
    if (!trimmedName) {
      setErrorMsg(isAr ? 'يرجى إدخال الاسم الكامل' : 'Please enter your full name');
      return;
    }
    if (!trimmedPhone || trimmedPhone.length < 8) {
      setErrorMsg(
        isAr
          ? 'يرجى إدخال رقم هاتف صحيح في عُمان (+968)'
          : 'Please provide a valid phone number in Oman (+968)'
      );
      return;
    }
    if (!sameAsPhone && (!trimmedWhatsapp || trimmedWhatsapp.length < 8)) {
      setErrorMsg(
        isAr
          ? 'يرجى إدخال رقم واتساب صحيح للتواصل'
          : 'Please enter a valid WhatsApp number'
      );
      return;
    }

    // Validation for the 3 required address fields
    if (!trimmedCity) {
      setErrorMsg(isAr ? 'يرجى إدخال المدينة' : 'Please enter your city');
      return;
    }
    if (!trimmedArea) {
      setErrorMsg(isAr ? 'يرجى إدخال المنطقة' : 'Please enter your area');
      return;
    }
    if (!trimmedDetailedAddress) {
      setErrorMsg(
        isAr
          ? 'يرجى إدخال العنوان التفصيلي (الشارع، البناية، رقم الشقة...)'
          : 'Please enter your detailed address (Street, building, flat number...)'
      );
      return;
    }

    // Validation for delivery method (neither is preselected; user must manually choose one)
    if (!deliveryMethod) {
      setErrorMsg(
        isAr
          ? 'يرجى اختيار طريقة التوصيل'
          : 'Please select your delivery method.'
      );
      return;
    }

    setIsSubmitting(true);

    // Save/Update user profile info
    updateProfile({
      ...profile,
      name: trimmedName,
      phone: trimmedPhone,
      whatsapp: trimmedWhatsapp,
      addresses: [
        {
          id: 'addr-main',
          title: deliveryMethod === 'home' ? (isAr ? 'المنزل' : 'Home') : (isAr ? 'العمل' : 'Office'),
          recipientName: trimmedName,
          phone: trimmedPhone,
          city: trimmedCity,
          governorate: trimmedCity,
          area: trimmedArea,
          streetAddress: trimmedDetailedAddress,
          isDefault: true,
        },
      ],
    });

    try {
      const sanitizedCartItems = cart.map((item) => ({
        product: {
          id: item.product.id,
          name: item.product.name,
          arabicName: item.product.arabicName || '',
          category: item.product.category,
          price: item.product.price,
          images: item.product.images || [],
          sku: item.product.sku || '',
          description: item.product.description || '',
          arabicDescription: item.product.arabicDescription || '',
          features: item.product.features || [],
          inStock: item.product.inStock,
          rating: item.product.rating,
          reviewCount: item.product.reviewCount,
        },
        quantity: item.quantity,
        ...(item.selectedSize !== undefined ? { selectedSize: item.selectedSize } : {}),
        ...(item.selectedColor !== undefined ? { selectedColor: item.selectedColor } : {}),
        ...(item.selectedVariantId ? { selectedVariantId: item.selectedVariantId } : {}),
        ...(item.selectedSizeAr ? { selectedSizeAr: item.selectedSizeAr } : {}),
        ...(item.selectedColorAr ? { selectedColorAr: item.selectedColorAr } : {}),
      }));

      await placeOrder({
        customer: {
          name: trimmedName,
          phone: trimmedPhone,
          whatsapp: trimmedWhatsapp,
          city: trimmedCity,
          area: trimmedArea,
          detailedAddress: trimmedDetailedAddress,
          address: trimmedDetailedAddress,
          governorate: trimmedCity,
          notes: notes.trim() || '',
        },
        items: sanitizedCartItems,
        subtotal: cartSubtotal,
        deliveryCharge,
        deliveryMethod,
        total: cartTotal,
        paymentMethod,
        notes: notes.trim() || '',
      });
      setIsSubmitting(false);
      setDeliveryMethod(null);
      onClose();
    } catch (err) {
      setIsSubmitting(false);
      setErrorMsg(
        isAr ? 'حدث خطأ أثناء معالجة الطلب. يرجى المحاولة ثانية.' : 'Failed to process order. Please retry.'
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="bg-[#FFF9FB] w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border border-[#FCE4EC] my-auto max-h-[95vh] flex flex-col">
        {/* Modal Top Header */}
        <div className="p-4 sm:p-5 bg-white border-b border-[#FCE4EC] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#E57390] text-white flex items-center justify-center font-serif font-bold text-sm tracking-widest shadow-2xs">
              LS
            </div>
            <div>
              <h3 className="font-serif font-bold text-sm sm:text-base tracking-[0.15em] text-[#832F47] uppercase">
                {t('checkoutTitle')}
              </h3>
              <p className="text-[10px] text-[#C5A059] font-medium tracking-wide">
                {t('fastOmanDelivery')} 🇴🇲
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-stone-400 hover:text-[#832F47] hover:bg-[#FFF0F4] transition-colors"
            title={t('gotItClose')}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <form onSubmit={handlePlaceOrder} className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-5">
          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              ⚠️ {errorMsg}
            </div>
          )}

          {/* Section 1: Customer Contact Information */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-xs text-[#832F47] uppercase tracking-[0.15em] flex items-center gap-1.5">
              <span>{t('step1Title')}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                  {t('fullName')} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="checkout-name"
                  type="text"
                  required
                  placeholder={t('fullNamePlaceholder')}
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                  {t('phoneNumber')} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="checkout-phone"
                  type="tel"
                  required
                  placeholder={t('phoneNumberPlaceholder')}
                  value={phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20"
                />
              </div>
            </div>

            {/* WhatsApp field */}
            <div className="space-y-1.5 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sameAsPhone}
                  onChange={(e) => {
                    setSameAsPhone(e.target.checked);
                    if (e.target.checked) setWhatsapp(phone);
                  }}
                  className="w-4 h-4 text-[#E57390] rounded-sm accent-[#E57390]"
                />
                <span className="text-xs text-stone-600 font-normal">
                  {isAr
                    ? 'رقم الواتساب هو نفس رقم الهاتف للاتصال'
                    : 'WhatsApp number is the same as Phone number'}
                </span>
              </label>

              {!sameAsPhone && (
                <div>
                  <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                    {t('whatsappNumber')} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="checkout-whatsapp"
                    type="tel"
                    placeholder={t('whatsappNumberPlaceholder')}
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Delivery Address (Manual Inputs: City, Area, Detailed Address) */}
          <div className="space-y-3 pt-3 border-t border-[#FCE4EC]">
            <h4 className="font-serif font-bold text-xs text-[#832F47] uppercase tracking-[0.15em] flex items-center gap-1.5">
              <span>{isAr ? '2. عنوان التوصيل' : '2. Delivery Address'}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* 1. City */}
              <div>
                <label htmlFor="checkout-city" className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                  {isAr ? 'المدينة' : 'City'} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="checkout-city"
                  name="city"
                  type="text"
                  required
                  placeholder={isAr ? 'أدخل مدينتك' : 'Enter your city'}
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20 text-[#3B252E] placeholder:text-stone-400"
                />
              </div>

              {/* 2. Area */}
              <div>
                <label htmlFor="checkout-area" className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                  {isAr ? 'المنطقة' : 'Area'} <span className="text-rose-500">*</span>
                </label>
                <input
                  id="checkout-area"
                  name="area"
                  type="text"
                  required
                  placeholder={isAr ? 'أدخل منطقتك' : 'Enter your area'}
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20 text-[#3B252E] placeholder:text-stone-400"
                />
              </div>
            </div>

            {/* 3. Detailed Address */}
            <div>
              <label htmlFor="checkout-detailed-address" className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                {isAr ? 'العنوان التفصيلي' : 'Detailed Address'} <span className="text-rose-500">*</span>
              </label>
              <textarea
                id="checkout-detailed-address"
                name="detailedAddress"
                required
                rows={3}
                placeholder={
                  isAr
                    ? 'الشارع، البناية، رقم الشقة، معلم قريب...'
                    : 'Street, building, flat number, nearby landmark...'
                }
                value={detailedAddress}
                onChange={(e) => setDetailedAddress(e.target.value)}
                className="w-full text-xs sm:text-sm px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390] focus:ring-1 focus:ring-[#E57390]/20 text-[#3B252E] placeholder:text-stone-400 resize-y min-h-[72px]"
              />
            </div>
          </div>

          {/* Section 3: Delivery Method */}
          <div className="space-y-3 pt-3 border-t border-[#FCE4EC]">
            <h4 className="font-serif font-bold text-xs text-[#832F47] uppercase tracking-[0.15em]">
              {isAr ? '3. طريقة التوصيل' : '3. Delivery Method'}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                id="delivery-option-home"
                onClick={() => setDeliveryMethod('home')}
                className={`p-3.5 rounded-2xl border-2 transition-all flex items-center justify-between cursor-pointer ${
                  deliveryMethod === 'home'
                    ? 'border-[#E57390] bg-[#FFF0F4] shadow-xs'
                    : 'border-[#FCE4EC] bg-white hover:border-[#F8BBD0]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                      deliveryMethod === 'home'
                        ? 'border-[#E57390] bg-[#E57390]'
                        : 'border-stone-300 bg-white'
                    }`}
                  >
                    {deliveryMethod === 'home' && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                  <Home className="w-4 h-4 text-[#832F47]" />
                  <div>
                    <div className="text-xs font-semibold text-[#3B252E]">
                      {t('deliveryHomeTitle')}
                    </div>
                    <div className="text-[10px] text-stone-500">
                      {t('deliveryHomeDesc')}
                    </div>
                  </div>
                </div>
                <span className="font-serif font-bold text-xs text-[#832F47] whitespace-nowrap">
                  {formatOMR(settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2.0)}
                </span>
              </div>

              <div
                id="delivery-option-office"
                onClick={() => setDeliveryMethod('office')}
                className={`p-3.5 rounded-2xl border-2 transition-all flex items-center justify-between cursor-pointer ${
                  deliveryMethod === 'office'
                    ? 'border-[#E57390] bg-[#FFF0F4] shadow-xs'
                    : 'border-[#FCE4EC] bg-white hover:border-[#F8BBD0]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                      deliveryMethod === 'office'
                        ? 'border-[#E57390] bg-[#E57390]'
                        : 'border-stone-300 bg-white'
                    }`}
                  >
                    {deliveryMethod === 'office' && (
                      <div className="w-2 h-2 rounded-full bg-white" />
                    )}
                  </div>
                  <Building className="w-4 h-4 text-[#832F47]" />
                  <div>
                    <div className="text-xs font-semibold text-[#3B252E]">
                      {t('deliveryOfficeTitle')}
                    </div>
                    <div className="text-[10px] text-stone-500">
                      {t('deliveryOfficeDesc')}
                    </div>
                  </div>
                </div>
                <span className="font-serif font-bold text-xs text-[#832F47] whitespace-nowrap">
                  {formatOMR(settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1.0)}
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Payment Method (Bank Transfer Only) */}
          <div className="space-y-3 pt-3 border-t border-[#FCE4EC]">
            <div className="flex items-center justify-between">
              <h4 className="font-serif font-bold text-xs text-[#832F47] uppercase tracking-[0.15em] flex items-center gap-1.5">
                <Landmark className="w-4 h-4 text-[#832F47]" />
                <span>{isAr ? '4. طريقة الدفع (تحويل بنكي)' : '4. Payment Method (Bank Transfer)'}</span>
              </h4>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                {isAr ? 'الخيار الوحيد المعتمد' : 'Official Payment Method'}
              </span>
            </div>

            {/* Bank Transfer Details Card */}
            <div className="bg-[#FFF0F4] rounded-2xl border-2 border-[#E57390] p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#FCE4EC] pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-white border border-[#FCE4EC] flex items-center justify-center text-[#832F47] shadow-2xs">
                    <Landmark className="w-4 h-4 text-[#832F47]" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-[#3B252E]">
                      {settings.bankName || 'Bank Muscat (بنك مسقط)'}
                    </h5>
                    <p className="text-[10px] text-stone-500">
                      {isAr ? 'حساب بوتيك لاستيلا الرسمي' : 'Official LASTELLA Boutique Account'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-[#832F47] bg-white px-2 py-0.5 rounded-md border border-[#FCE4EC]">
                  {isAr ? 'تحويل بنكي' : 'Bank Transfer'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC]">
                  <span className="text-[10px] text-stone-400 block font-medium">
                    {isAr ? 'اسم المستفيد / الحساب:' : 'Account Holder Name:'}
                  </span>
                  <span className="font-bold text-[#3B252E] text-xs">
                    {settings.accountName || 'LASTELLA JEWELRY'}
                  </span>
                </div>

                {settings.accountNumber && (
                  <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-stone-400 block font-medium">
                        {isAr ? 'رقم الحساب البنكي:' : 'Bank Account Number:'}
                      </span>
                      <span className="font-mono font-bold text-[#832F47] text-xs">
                        {settings.accountNumber}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(settings.accountNumber || '');
                        setCopiedAcc(true);
                        setTimeout(() => setCopiedAcc(false), 2000);
                      }}
                      className="p-1.5 rounded-lg bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] transition-all cursor-pointer"
                      title={isAr ? 'نسخ رقم الحساب' : 'Copy account number'}
                    >
                      {copiedAcc ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                )}

                {settings.bankIban && (
                  <div className="bg-white p-2.5 rounded-xl border border-[#FCE4EC] sm:col-span-2">
                    <span className="text-[10px] text-stone-400 block font-medium">
                      {isAr ? 'رقم الآيبان (IBAN):' : 'IBAN:'}
                    </span>
                    <span className="font-mono font-bold text-[#832F47] text-xs break-all">
                      {settings.bankIban}
                    </span>
                  </div>
                )}
              </div>

              {/* Instructions */}
              <div className="bg-white/80 p-2.5 rounded-xl border border-[#FCE4EC] text-[11px] leading-relaxed text-stone-600">
                <p className="font-semibold text-[#832F47] mb-0.5">
                  {isAr ? '📌 تعليمات التحويل البنكي:' : '📌 Transfer Instructions:'}
                </p>
                <p>
                  {isAr
                    ? (settings.bankTransferInstructionsAr || 'يرجى تحويل مبلغ الطلب بدقة إلى الحساب البنكي، مع كتابة رقم الطلب في خانة الملاحظات/الوصف عند التحويل.')
                    : (settings.bankTransferInstructions || 'Please transfer the exact order amount to our bank account. Include your Order Number in the remarks.')}
                </p>
                <p className="mt-1 text-[10px] text-stone-500 italic">
                  {isAr
                    ? '⚠️ سيتم تسجيل الطلب بحالة "بانتظار التحويل البنكي"، ويتم تجهيز وشحن الطلب مباشرة بعد التحقق من استلام المبلغ.'
                    : '⚠️ Order will initially be marked "Pending Payment" and dispatched upon verification of receipt.'}
                </p>
              </div>
            </div>
          </div>

          {/* Section 5: Order Notes */}
          <div className="pt-3 border-t border-[#FCE4EC]">
            <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
              {t('orderNotes')}
            </label>
            <input
              id="checkout-notes"
              type="text"
              placeholder={t('orderNotesPlaceholder')}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
            />
          </div>

          {/* Order Items Review in Checkout */}
          <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-2.5">
            <h4 className="font-serif font-bold text-xs text-[#832F47] uppercase tracking-[0.15em]">
              {isAr ? 'القطع في هذا الطلب' : 'Items In This Order'} ({cart.length})
            </h4>
            <div className="divide-y divide-[#FCE4EC] max-h-48 overflow-y-auto">
              {cart.map((item, idx) => {
                const itemDisplayName =
                  isAr && item.product.arabicName ? item.product.arabicName : item.product.name;
                return (
                  <div key={idx} className="py-2 first:pt-0 last:pb-0 flex items-center justify-between text-xs gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={getOptimizedImageUrl(item.product.images[0], 100, 'auto', 'fit')}
                        alt={itemDisplayName}
                        className="w-10 h-10 rounded-lg object-cover bg-[#FFF0F4] shrink-0 border border-[#FCE4EC]"
                        loading="eager"
                        decoding="async"
                        width={40}
                        height={40}
                      />
                      <div className="min-w-0">
                        <p className="font-semibold text-[#3B252E] truncate">{itemDisplayName}</p>
                        <p className="text-[10px] text-stone-500 flex flex-wrap items-center gap-1 mt-0.5">
                          <span>{isAr ? 'الكمية:' : 'Qty:'} {item.quantity}</span>
                          {item.selectedSize && (
                            <span>• {isAr ? 'المقاس:' : 'Size:'} {isAr ? (item.selectedSizeAr || translateSizeToArabic(String(item.selectedSize))) : item.selectedSize}</span>
                          )}
                          {item.selectedColor && (
                            <span>
                              • {isAr ? 'اللون:' : 'Color:'}{' '}
                              {isAr
                                ? (item.selectedColorAr ||
                                    (item.selectedColor === 'Gold'
                                      ? 'ذهبي'
                                      : item.selectedColor === 'Silver'
                                      ? 'فضي'
                                      : item.selectedColor))
                                : item.selectedColor}
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-[#832F47] shrink-0 font-serif">
                      {formatOMR(item.product.price * item.quantity)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Breakdown Section */}
          <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-2 text-xs">
            <div className="flex justify-between text-stone-600">
              <span>
                {t('subtotal')} ({cart.length} {isAr ? 'قطع' : 'items'})
              </span>
              <span className="font-semibold text-[#3B252E]">{formatOMR(cartSubtotal)}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>
                {t('deliveryCharge')}
                {deliveryMethod
                  ? ` (${deliveryMethod === 'home' ? t('deliveryHomeTitle') : t('deliveryOfficeTitle')})`
                  : ''}
              </span>
              <span
                className={
                  deliveryMethod
                    ? 'font-semibold text-[#832F47]'
                    : 'text-xs text-stone-400 font-medium italic'
                }
              >
                {deliveryMethod
                  ? formatOMR(deliveryCharge)
                  : isAr
                  ? 'اختر طريقة التوصيل'
                  : 'Select delivery method'}
              </span>
            </div>
            <div className="pt-2 border-t border-[#FDE7ED] flex justify-between items-baseline text-sm">
              <span className="font-medium text-[#3B252E] tracking-wide">{t('total')}</span>
              <span className="font-serif font-bold text-xl text-[#832F47]">
                {formatOMR(cartTotal)}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2">
            <button
              id="btn-confirm-place-order"
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-full bg-[#E57390] hover:bg-[#D45E7C] text-white font-semibold text-xs sm:text-sm tracking-[0.15em] uppercase shadow-md active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#C5A059]" />
              <span>
                {isSubmitting
                  ? isAr
                    ? 'جاري إرسال وتأكيد الطلب...'
                    : 'Processing Order...'
                  : isAr
                  ? 'تأكيد الطلب والتحويل البنكي'
                  : t('placeOrderNow')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
