import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { HeroBanner } from './HeroBanner';
import { CategoryPills } from './CategoryPills';
import { TrustBadges } from './TrustBadges';
import { CustomerReviews } from './CustomerReviews';
import { InstaGallery } from './InstaGallery';
import { ProductCard } from '../common/ProductCard';
import { ProductListingContainer } from '../common/ProductListingContainer';
import { Search, Sparkles, ArrowRight, ArrowLeft, Flame } from 'lucide-react';

export const HomeView: React.FC = () => {
  const { products, setCurrentTab, setSelectedCategory, language, t } = useStore();
  const isAr = language === 'ar';

  const newArrivals = useMemo(() => products.filter((p) => p.isNewArrival).slice(0, 4), [products]);
  const bestSellers = useMemo(() => products.filter((p) => p.isBestSeller).slice(0, 4), [products]);
  const ringsCollection = useMemo(() => products.filter((p) => p.category === 'Rings').slice(0, 4), [products]);
  const brandBoxes = useMemo(() => products.filter((p) => p.category === 'Brand Boxes').slice(0, 2), [products]);

  const handleSearchFocus = () => {
    setCurrentTab('search');
  };

  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <div
      className="space-y-6 pb-12 animate-in fade-in duration-300"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Top Search Bar Widget */}
      <div className="relative pt-1">
        <div
          onClick={handleSearchFocus}
          className="w-full flex items-center gap-3 px-4 py-3 bg-white rounded-2xl border border-[#FCE4EC] subtle-card-shadow cursor-pointer hover:border-[#F8BBD0] transition-all group text-start"
        >
          <Search className="w-4 h-4 text-[#E57390] group-hover:text-[#832F47] transition-colors" />
          <span className="text-xs sm:text-sm text-stone-400 font-normal">
            {t('searchPlaceholder')}
          </span>
          <span className="ms-auto text-[10px] uppercase font-bold tracking-wider text-[#832F47] bg-[#FFF0F4] px-2.5 py-0.5 rounded-full border border-[#FCE4EC]">
            {isAr ? 'عُمان 🇴🇲' : 'OMAN 🇴🇲'}
          </span>
        </div>
      </div>

      {/* Hero Banner Carousel */}
      <HeroBanner />

      {/* Categories Horizontal Quick Scroll */}
      <CategoryPills />

      {/* Trust Badges - LASTELLA Guarantees */}
      <TrustBadges />

      {/* New Arrivals Section */}
      <section className="py-2">
        <div className="flex items-center justify-between mb-4">
          <div className="text-start">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#C5A059]" /> {isAr ? 'وصل حديثاً للمتجر' : 'FRESH IN STORE'}
            </span>
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-0.5">
              {t('newArrivals')}
            </h3>
          </div>
          <button
            id="btn-view-all-new-arrivals"
            onClick={() => {
              setSelectedCategory('New Arrivals');
              setCurrentTab('categories');
            }}
            className="flex items-center gap-1 text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors"
          >
            <span>{t('viewAll')}</span>
            <ArrowIcon className="w-3.5 h-3.5" />
          </button>
        </div>

        <ProductListingContainer id="home-new-arrivals-grid">
          {newArrivals.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      </section>

      {/* Best Sellers Section */}
      <section className="py-2">
        <div className="flex items-center justify-between mb-4">
          <div className="text-start">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#F06292] font-bold flex items-center gap-1">
              <Flame className="w-3 h-3 text-[#F06292]" /> {isAr ? 'الأكثر طلباً في عُمان' : 'MOST LOVED IN OMAN'}
            </span>
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-0.5">
              {t('bestSelling')}
            </h3>
          </div>
          <button
            id="btn-view-all-best-sellers"
            onClick={() => {
              setSelectedCategory('Best Selling');
              setCurrentTab('categories');
            }}
            className="flex items-center gap-1 text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors"
          >
            <span>{t('viewAll')}</span>
            <ArrowIcon className="w-3.5 h-3.5" />
          </button>
        </div>

        <ProductListingContainer id="home-best-sellers-grid">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      </section>

      {/* Rings Feature Showcase with Ring Sizes */}
      <section className="py-2">
        <div className="flex items-center justify-between mb-4">
          <div className="text-start">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
              {isAr ? 'المقاسات المتاحة 14، 15، 16، 17، 18، 19' : 'SIZES 14, 15, 16, 17, 18, 19'}
            </span>
            <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-0.5">
              {isAr ? 'تشكيلة الخواتم الملكية' : 'Signature Rings Collection'}
            </h3>
          </div>
          <button
            onClick={() => {
              setSelectedCategory('Rings');
              setCurrentTab('categories');
            }}
            className="flex items-center gap-1 text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors"
          >
            <span>{t('viewAll')}</span>
            <ArrowIcon className="w-3.5 h-3.5" />
          </button>
        </div>

        <ProductListingContainer id="home-rings-grid">
          {ringsCollection.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ProductListingContainer>
      </section>

      {/* Brand Boxes & Gifting Spotlight */}
      {brandBoxes.length > 0 && (
        <section className="py-4 bg-white rounded-3xl p-5 border border-[#FCE4EC] subtle-card-shadow text-start">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
            <div>
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
                {isAr ? 'فخامة الإهداء والتغليف' : 'UNBOXING LUXURY'}
              </span>
              <h3 className="font-serif text-lg sm:text-xl font-bold text-[#3B252E] mt-0.5">
                {isAr ? 'علب مجوهرات لاستيلا الفاخرة' : 'Signature LASTELLA Gift Boxes'}
              </h3>
            </div>
            <button
              onClick={() => {
                setSelectedCategory('Brand Boxes');
                setCurrentTab('categories');
              }}
              className="mt-2 sm:mt-0 text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors flex items-center gap-1"
            >
              <span>{isAr ? 'استكشفي علب الهدايا' : 'Explore Packaging'}</span>
              <ArrowIcon className="w-3 h-3" />
            </button>
          </div>

          <ProductListingContainer id="home-brand-boxes-grid" className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {brandBoxes.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </ProductListingContainer>
        </section>
      )}

      {/* Customer Reviews from Oman */}
      <CustomerReviews />

      {/* Instagram Lookbook */}
      <InstaGallery />
    </div>
  );
};
