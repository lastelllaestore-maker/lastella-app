import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Star, CheckCircle, Quote, MapPin } from 'lucide-react';

export const CustomerReviews: React.FC = () => {
  const { reviews, language, t } = useStore();
  const isAr = language === 'ar';

  const localizedReviews = reviews.map((rev) => {
    if (!isAr) return rev;
    let arabicComment = rev.comment;
    let arabicCustomer = rev.customerName;
    let arabicLocation = rev.location;

    if (rev.customerName.includes('Fatma')) {
      arabicCustomer = 'فاطمة البلوشي';
      arabicLocation = 'مسقط، سلطنة عُمان';
      arabicComment = 'الجودة خيالية وتفوق الوصف! لمعة الذهب عيار 18 مثل الذهب الأصلي تماماً، وعلبة الهدية مع إضاءة الـ LED خطفت قلوبنا.';
    } else if (rev.customerName.includes('Maryam')) {
      arabicCustomer = 'مريم العامري';
      arabicLocation = 'صلالة، سلطنة عُمان';
      arabicComment = 'أفضل متجر مجوهرات في عُمان! أرتدي السلسلة يومياً من شهرين ولم يتغير لونها مع الماء والعطور، والتوصيل سريع جداً.';
    } else if (rev.customerName.includes('Aisha')) {
      arabicCustomer = 'عائشة الحوسني';
      arabicLocation = 'صحار، سلطنة عُمان';
      arabicComment = 'طلبت طقم المناسبات وكان أرقى مما تخيلت. التغليف الملكي وتفاصيل الفصوص والبريق تجعلكِ تشعرين بالفخامة الحقيقية.';
    } else if (rev.customerName.includes('Reem')) {
      arabicCustomer = 'ريم المعشني';
      arabicLocation = 'نزوى، سلطنة عُمان';
      arabicComment = 'المقاسات دقيقة جداً بفضل دليل المقاسات وخدمة العملاء في الواتساب راقية ومتعاونة لأبعد حد. شكراً لاستيلا!';
    }

    return {
      ...rev,
      customerName: arabicCustomer,
      location: arabicLocation,
      comment: arabicComment,
    };
  });

  return (
    <div className="py-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-4">
        <div className="text-start">
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
            {isAr ? 'آراء عميلاتنا في عُمان' : 'CLIENT EXPERIENCES'}
          </span>
          <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-0.5">
            {isAr ? 'تجارب تنبض بالثقة والجمال' : 'Loved Across the Sultanate'}
          </h3>
        </div>
        <div className="flex items-center gap-1.5 mt-2 sm:mt-0 text-xs font-semibold text-stone-600">
          <div className="flex items-center text-[#C5A059]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-[#C5A059]" />
            ))}
          </div>
          <span>4.9 / 5.0 ({isAr ? '+500 عميلة سعيدة' : '500+ Happy Customers'})</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {localizedReviews.map((rev) => (
          <div
            key={rev.id}
            className="bg-white rounded-2xl border border-[#FCE4EC] p-5 shadow-2xs flex flex-col justify-between relative group hover:border-[#F8BBD0] transition-all text-start"
          >
            <Quote className="absolute top-4 end-4 w-7 h-7 text-[#FFF0F4] stroke-[1.5px] pointer-events-none" />

            <div>
              {/* Stars & Location */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-0.5 text-[#C5A059]">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#C5A059]" />
                  ))}
                </div>
                <span className="text-[11px] text-stone-400 font-medium">{rev.date}</span>
              </div>

              {/* Comment */}
              <p className="text-xs sm:text-sm text-[#3B252E] leading-relaxed mb-4">
                "{rev.comment}"
              </p>
            </div>

            {/* Author */}
            <div className="pt-3 border-t border-[#FDE7ED] flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-[#3B252E]">{rev.customerName}</h4>
                  {rev.verifiedPurchase && (
                    <span className="inline-flex items-center gap-0.5 text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-full font-medium border border-emerald-100">
                      <CheckCircle className="w-2.5 h-2.5 text-emerald-600" /> {isAr ? 'شراء مؤكد' : 'Verified'}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-[#C5A059] flex items-center gap-1 mt-0.5 font-medium">
                  <MapPin className="w-2.5 h-2.5" /> {rev.location}
                </p>
              </div>

              <span className="text-[10px] text-[#832F47] bg-[#FFF0F4] px-2 py-0.5 rounded-md font-medium max-w-[140px] truncate border border-[#FCE4EC]">
                {rev.productName}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
