import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCategory } from '../../types';
import { Sparkles, Flame, Gift, Layers, Disc, CircleDot } from 'lucide-react';
import { getCategoryTranslation } from '../../i18n/translations';
import braceletsCategoryImg from '../../assets/images/regenerated_image_1791484829558.jpg';
import banglesCategoryImg from '../../assets/images/regenerated_image_1791812675949.webp';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

export const CategoryPills: React.FC = () => {
  const { setSelectedCategory, setCurrentTab, selectedCategory, language, t } = useStore();

  const categories: { name: ProductCategory; icon: React.ReactNode; image: string }[] = [
    {
      name: 'New Arrivals',
      icon: <Sparkles className="w-4 h-4 text-[#C5A059]" />,
      image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=300&q=80',
    },
    {
      name: 'Necklaces',
      icon: <Disc className="w-4 h-4 text-[#832F47]" />,
      image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=300&q=80',
    },
    {
      name: 'Bracelets',
      icon: <CircleDot className="w-4 h-4 text-[#832F47]" />,
      image: braceletsCategoryImg,
    },
    {
      name: 'Bangles',
      icon: <CircleDot className="w-4 h-4 text-[#832F47]" />,
      image: banglesCategoryImg,
    },
    {
      name: 'Anklets',
      icon: <Sparkles className="w-4 h-4 text-[#832F47]" />,
      image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=300&q=80',
    },
    {
      name: 'Rings',
      icon: <CircleDot className="w-4 h-4 text-[#832F47]" />,
      image: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?auto=format&fit=crop&w=300&q=80',
    },
    {
      name: 'Brand Boxes',
      icon: <Gift className="w-4 h-4 text-[#832F47]" />,
      image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=300&q=80',
    },
    {
      name: 'Best Selling',
      icon: <Flame className="w-4 h-4 text-[#E5484D]" />,
      image: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?auto=format&fit=crop&w=300&q=80',
    },
  ];

  const handleSelectCategory = (cat: ProductCategory) => {
    setSelectedCategory(cat);
    setCurrentTab('categories');
  };

  return (
    <div className="py-2">
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="font-serif font-bold text-xs sm:text-sm tracking-[0.15em] uppercase text-[#3B252E] flex items-center gap-2">
          <span>{t('discoverCollections')}</span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#EFA8BA]"></span>
        </h3>
        <button
          onClick={() => {
            setSelectedCategory(null);
            setCurrentTab('categories');
          }}
          className="text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors"
        >
          {t('viewAll')} →
        </button>
      </div>

      <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-2 pt-1 px-1">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.name;
          const translatedName = getCategoryTranslation(cat.name, language);

          return (
            <button
              key={cat.name}
              id={`cat-pill-${cat.name.replace(/\s+/g, '-').toLowerCase()}`}
              onClick={() => handleSelectCategory(cat.name)}
              className={`flex flex-col items-center gap-2 group shrink-0 transition-transform active:scale-95`}
            >
              {/* Circular Avatar */}
              <div
                className={`w-16 h-16 sm:w-18 sm:h-18 rounded-full p-0.5 transition-all duration-300 ${
                  isSelected
                    ? 'ring-2 ring-[#E57390] scale-105 shadow-xs'
                    : 'ring-1 ring-[#FCE4EC] group-hover:ring-[#F8BBD0]'
                }`}
              >
                <div className="w-full h-full rounded-full overflow-hidden relative bg-[#FFF0F4]">
                  <img
                    src={getOptimizedImageUrl(cat.image, 140, 'auto', 'fit')}
                    alt={translatedName}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    loading="eager"
                    decoding="async"
                    width={72}
                    height={72}
                  />
                  <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-colors pointer-events-none" />
                </div>
              </div>

              {/* Title */}
              <span
                className={`text-[11px] font-medium tracking-tight text-center max-w-[84px] truncate transition-colors ${
                  isSelected ? 'text-[#832F47] font-bold' : 'text-[#3B252E] group-hover:text-[#832F47]'
                }`}
              >
                {translatedName}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
