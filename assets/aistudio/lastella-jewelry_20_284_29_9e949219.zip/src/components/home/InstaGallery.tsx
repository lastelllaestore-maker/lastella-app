import React from 'react';
import { INSTA_GALLERY } from '../../data/initialData';
import { Instagram, Heart, Sparkles } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

export const InstaGallery: React.FC = () => {
  const { setCurrentTab, setSelectedCategory, language, t } = useStore();
  const isAr = language === 'ar';

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-4">
        <div className="text-start">
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
            @LASTELLA_OMAN
          </span>
          <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#2D2D2D] mt-0.5 flex items-center gap-2">
            <span>{isAr ? 'إطلالات لاستيلا على انستقرام' : 'Instagram Lookbook'}</span>
            <Sparkles className="w-4 h-4 text-[#C5A059]" />
          </h3>
        </div>

        <a
          href="https://instagram.com"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-xs font-semibold text-[#832F47] hover:text-[#E57390] transition-colors"
        >
          <Instagram className="w-4 h-4 text-[#E57390]" />
          <span>{isAr ? 'تابعينا' : 'Follow Us'}</span>
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {INSTA_GALLERY.map((post) => (
          <div
            key={post.id}
            onClick={() => {
              setSelectedCategory('New Arrivals');
              setCurrentTab('categories');
            }}
            className="group relative rounded-2xl overflow-hidden aspect-square bg-[#FFF0F4] border border-[#FCE4EC] cursor-pointer hover:border-[#F8BBD0] transition-all shadow-2xs"
          >
            <img
              src={getOptimizedImageUrl(post.imageUrl, 400, 'auto', 'fit')}
              alt={post.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              loading="eager"
              decoding="async"
              width={200}
              height={200}
            />

            {/* Hover overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#2D161F]/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3 text-white text-start">
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className="text-[11px] text-[#FDE7ED]">{post.productName}</span>
                <span className="flex items-center gap-1 text-[10px] text-[#FFD1DC]">
                  <Heart className="w-3 h-3 fill-[#FFD1DC]" /> {post.likes}
                </span>
              </div>
              <p className="text-[9px] text-pink-100/80 truncate">{post.username}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
