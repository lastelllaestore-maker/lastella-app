import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Sparkles, Gift, Tag, ArrowRight, ArrowLeft } from 'lucide-react';

export const SpecialOffers: React.FC = () => {
  const { setSelectedCategory, setCurrentTab, language, t } = useStore();
  const isAr = language === 'ar';

  return (
    <div className="py-4">
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#FDE7ED] via-[#FCE4EC] to-[#F8D0DB] p-6 sm:p-8 text-[#3B252E] shadow-xs border border-[#F8BBD0] text-start">
        {/* Glow backdrop decorative circles */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-white/40 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-48 h-48 rounded-full bg-[#FFF0F4]/60 blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="max-w-md">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 border border-[#F8BBD0] text-[#832F47] text-[11px] font-bold tracking-wider uppercase mb-2 shadow-2xs">
              <Gift className="w-3.5 h-3.5 text-[#E57390]" />
              {isAr ? 'عرض بوتيك حصري' : 'SPECIAL BOUTIQUE OFFER'}
            </div>

            <h3 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#3B252E] mb-2">
              {isAr ? 'باقات الكومبو والأطقم الملكية' : 'Signature Combos & Sets'}
            </h3>
            <p className="text-xs sm:text-sm text-[#54303B] leading-relaxed font-normal mb-3">
              {isAr
                ? 'اشتري أي عقد مع إسوارة واحصلي على علبة مجوهرات مخملية فاخرة مجاناً مع التغليف الملكي الأنيق.'
                : 'Buy any Necklace + Bracelet Combo and receive a complimentary Luxury Velvet Keepsake Box. Limited quantities available in Oman!'}
            </p>

            <div className="flex items-center gap-4 text-xs font-semibold text-[#832F47]">
              <span className="flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-[#E57390]" /> {isAr ? 'وفري حتى 35%' : 'Save Up to 35% OFF'}
              </span>
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" /> {isAr ? 'تغليف هدايا مجاني في عُمان' : 'Free Oman Gift Wrap'}
              </span>
            </div>
          </div>

          <div className="flex flex-row md:flex-col gap-2.5 w-full md:w-auto">
            <button
              onClick={() => {
                setSelectedCategory('Combos');
                setCurrentTab('categories');
              }}
              className="flex-1 md:flex-none px-6 py-3 rounded-full bg-white hover:bg-[#FFF5F8] text-[#832F47] font-bold text-xs sm:text-sm tracking-wider uppercase shadow-xs active:scale-95 transition-all text-center flex items-center justify-center gap-2 border border-[#F8BBD0]"
            >
              <span>{isAr ? 'تصفح باقات الكومبو' : 'Explore Combos'}</span>
              {isAr ? <ArrowLeft className="w-4 h-4 text-[#832F47]" /> : <ArrowRight className="w-4 h-4 text-[#832F47]" />}
            </button>
            <button
              onClick={() => {
                setSelectedCategory('Jewelry Sets');
                setCurrentTab('categories');
              }}
              className="flex-1 md:flex-none px-5 py-3 rounded-full bg-[#832F47]/10 hover:bg-[#832F47]/20 border border-[#832F47]/20 text-[#832F47] font-semibold text-xs sm:text-sm tracking-wide active:scale-95 transition-all text-center"
            >
              {isAr ? 'أطقم الأعراس والمناسبات' : 'Bridal Sets Suite'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
