import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  User,
  Package,
  Heart,
  MapPin,
  MessageCircle,
  Plus,
  Trash2,
  Clock,
  CheckCircle,
  Truck,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Lock,
} from 'lucide-react';
import { OrderStatus, SavedAddress } from '../../types';
import { OMAN_GOVERNORATES } from '../../data/initialData';
import { StoreFooter } from '../common/StoreFooter';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

export const AccountView: React.FC = () => {
  const {
    profile,
    updateProfile,
    orders,
    formatOMR,
    setCurrentTab,
    generateGeneralWhatsAppUrl,
    generateWhatsAppOrderUrl,
    activeTrackingOrder,
    setActiveTrackingOrder,
    isAdminAuthenticated,
    setIsAdminLoginOpen,
    language,
    t,
  } = useStore();

  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'addresses'>('orders');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(
    activeTrackingOrder?.id || orders[0]?.id || null
  );

  // Address editing state
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newAddrTitle, setNewAddrTitle] = useState(isAr ? 'المنزل' : 'Home');
  const [newAddrName, setNewAddrName] = useState(profile.name || '');
  const [newAddrPhone, setNewAddrPhone] = useState(profile.phone || '+968 ');
  const [newAddrGov, setNewAddrGov] = useState(OMAN_GOVERNORATES[0]);
  const [newAddrArea, setNewAddrArea] = useState('Al Mouj / The Wave (الموج)');
  const [newAddrStreet, setNewAddrStreet] = useState('');

  // Profile editing
  const [name, setName] = useState(profile.name || '');
  const [phone, setPhone] = useState(profile.phone || '');
  const [whatsapp, setWhatsapp] = useState(profile.whatsapp || '');
  const [email, setEmail] = useState(profile.email || '');
  const [isSaved, setIsSaved] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      ...profile,
      name,
      phone,
      whatsapp,
      email,
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleSaveNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    const newAddress: SavedAddress = {
      id: `addr-${Date.now()}`,
      title: newAddrTitle,
      recipientName: newAddrName || profile.name,
      phone: newAddrPhone || profile.phone,
      governorate: newAddrGov,
      area: newAddrArea,
      streetAddress: newAddrStreet,
      isDefault: profile.addresses.length === 0,
    };
    updateProfile({
      ...profile,
      addresses: [...profile.addresses, newAddress],
    });
    setIsAddingAddress(false);
    setNewAddrStreet('');
  };

  const handleDeleteAddress = (id: string) => {
    updateProfile({
      ...profile,
      addresses: profile.addresses.filter((a) => a.id !== id),
    });
  };

  const handleSetDefaultAddress = (id: string) => {
    updateProfile({
      ...profile,
      addresses: profile.addresses.map((a) => ({
        ...a,
        isDefault: a.id === id,
      })),
    });
  };

  const statusSteps: { status: OrderStatus; label: string; icon: any }[] = [
    { status: 'Order Placed', label: isAr ? 'تم الاستلام' : 'Placed', icon: Clock },
    { status: 'Order Confirmed', label: isAr ? 'تم التأكيد' : 'Confirmed', icon: CheckCircle },
    { status: 'Preparing', label: isAr ? 'قيد التجهيز' : 'Preparing', icon: Package },
    { status: 'Out for Delivery', label: isAr ? 'جاري التوصيل' : 'Out for Delivery', icon: Truck },
    { status: 'Delivered', label: isAr ? 'تم التوصيل' : 'Delivered', icon: Sparkles },
  ];

  const getStepIndex = (s: OrderStatus) => {
    switch (s) {
      case 'Order Placed':
        return 0;
      case 'Order Confirmed':
        return 1;
      case 'Preparing':
        return 2;
      case 'Out for Delivery':
        return 3;
      case 'Delivered':
        return 4;
      case 'Cancelled':
        return -1;
      default:
        return 0;
    }
  };

  const getStatusLabel = (s: OrderStatus) => {
    switch (s) {
      case 'Order Placed':
        return isAr ? 'تم استلام الطلب' : 'Order Placed';
      case 'Order Confirmed':
        return isAr ? 'تم التأكيد' : 'Order Confirmed';
      case 'Preparing':
        return isAr ? 'قيد التجهيز والتغليف' : 'Preparing';
      case 'Out for Delivery':
        return isAr ? 'خرج للتوصيل' : 'Out for Delivery';
      case 'Delivered':
        return isAr ? 'تم التوصيل بنجاح' : 'Delivered';
      case 'Cancelled':
        return isAr ? 'تم إلغاء الطلب' : 'Cancelled';
      default:
        return s;
    }
  };

  return (
    <div
      className="space-y-5 pb-20 animate-in fade-in duration-200 max-w-4xl mx-auto"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Account Profile Header Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#FCE4EC] shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-14 h-14 rounded-2xl bg-[#E57390] text-white flex items-center justify-center font-serif font-bold text-xl shadow-xs">
            {profile.name ? profile.name.charAt(0).toUpperCase() : 'L'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E]">
                {profile.name || (isAr ? 'عميلة لاستيلا المتميزة' : 'LASTELLA Customer')}
              </h2>
              <span className="text-[10px] font-medium tracking-wider uppercase bg-[#FFF0F4] text-[#832F47] px-2.5 py-0.5 rounded-full border border-[#FCE4EC]">
                {isAr ? 'عضوة VIP' : 'VIP Member'}
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5" dir="ltr">
              {profile.phone ? `${profile.phone} • ${profile.email || 'VIP Member'}` : (isAr ? 'عضوية متميزة • سلطنة عُمان 🇴🇲' : 'Exclusive Membership • Oman 🇴🇲')}
            </p>
          </div>
        </div>

        {/* WhatsApp Support Direct Button */}
        <a
          href={generateGeneralWhatsAppUrl()}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2.5 bg-[#25D366] hover:bg-[#20BE5C] text-white text-xs font-semibold rounded-full shadow-xs active:scale-95 transition-all flex items-center justify-center gap-1.5 shrink-0"
        >
          <MessageCircle className="w-4 h-4 fill-white" />
          <span>{isAr ? 'مساعدة فورية عبر واتساب VIP' : 'VIP WhatsApp Concierge'}</span>
        </a>
      </div>

      {/* Account Navigation Tabs */}
      <div className="flex items-center gap-2 bg-white p-1 rounded-2xl border border-[#FCE4EC]">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'orders'
              ? 'bg-[#E57390] text-white shadow-xs'
              : 'text-stone-600 hover:text-[#832F47]'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>
            {t('myOrders')} ({orders.length})
          </span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'profile'
              ? 'bg-[#E57390] text-white shadow-xs'
              : 'text-stone-600 hover:text-[#832F47]'
          }`}
        >
          <User className="w-4 h-4" />
          <span>{t('personalInfo')}</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'addresses'
              ? 'bg-[#E57390] text-white shadow-xs'
              : 'text-stone-600 hover:text-[#832F47]'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>
            {t('savedAddresses')} ({profile.addresses.length})
          </span>
        </button>
      </div>

      {/* Tab 1: Orders & Live Status Tracking */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-3xl border border-[#FCE4EC] p-8 space-y-3">
              <Package className="w-10 h-10 text-stone-300 mx-auto" />
              <h3 className="font-serif text-lg font-bold text-[#3B252E]">{t('noOrdersYet')}</h3>
              <p className="text-xs text-stone-500">{t('noOrdersDesc')}</p>
              <button
                onClick={() => setCurrentTab('home')}
                className="px-5 py-2.5 bg-[#E57390] text-white text-xs font-semibold tracking-widest uppercase rounded-full hover:bg-[#D45E7C] transition-colors"
              >
                {t('startShopping')}
              </button>
            </div>
          ) : (
            orders.map((order) => {
              const isExpanded = expandedOrderId === order.id;
              const currentStepIdx = getStepIndex(order.status);

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl border border-[#FCE4EC] overflow-hidden shadow-2xs transition-all"
                >
                  {/* Order Card Summary Header */}
                  <div
                    onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer hover:bg-[#FFF9FB] transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-serif font-bold text-sm text-[#832F47] tracking-wide">
                          #{order.orderNumber}
                        </span>
                        <span className="text-stone-400 text-xs">•</span>
                        <span className="text-xs text-stone-500">
                          {new Date(order.createdAt).toLocaleDateString(
                            isAr ? 'ar-OM' : 'en-GB',
                            {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            }
                          )}
                        </span>
                        <span
                          className={`text-[10px] font-medium tracking-wide px-2.5 py-0.5 rounded-full ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : order.status === 'Cancelled'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC]'
                          }`}
                        >
                          {getStatusLabel(order.status)}
                        </span>
                      </div>
                      <p className="text-xs text-stone-600 mt-1">
                        {order.items.length} {isAr ? 'قطعة' : 'item(s)'} • {t('total')}:{' '}
                        {formatOMR(order.total)} (
                        {order.deliveryMethod === 'home'
                          ? t('deliveryHomeTitle')
                          : t('deliveryOfficeTitle')}
                        )
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs font-semibold text-[#832F47] hidden sm:inline">
                        {isExpanded
                          ? isAr
                            ? 'إخفاء التفاصيل'
                            : 'Hide Details'
                          : isAr
                          ? 'تتبع الطلب'
                          : 'Track Order'}
                      </span>
                      <div className="p-1 rounded-full bg-[#FFF0F4] text-[#832F47]">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Tracker & Order Details */}
                  {isExpanded && (
                    <div className="p-4 sm:p-6 border-t border-[#FCE4EC] bg-[#FFF9FB] space-y-5 animate-in fade-in duration-200">
                      {/* Live Tracking Visual Steps */}
                      {order.status === 'Cancelled' ? (
                        <div className="bg-rose-50 rounded-2xl p-4 border border-rose-200 text-rose-800 space-y-1">
                          <span className="font-serif font-bold text-xs uppercase tracking-wider block">
                            {isAr ? 'حالة الطلب: ملغي' : 'Order Status: Cancelled'}
                          </span>
                          <p className="text-xs text-rose-600">
                            {isAr
                              ? 'تم إلغاء هذا الطلب من قبل إدارة المتجر. لمزيد من المساعدة يرجى التواصل عبر واتساب.'
                              : 'This order was cancelled by boutique administration. Contact our VIP WhatsApp for assistance.'}
                          </p>
                        </div>
                      ) : (
                        <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-3">
                          <span className="text-xs font-serif font-bold text-[#832F47] uppercase tracking-[0.15em] block">
                            {isAr ? 'تتبع مسار الطلب المباشر:' : 'Real-time Order Tracking:'}
                          </span>

                          <div className="pt-2">
                            <div className="relative flex items-center justify-between">
                              {/* Line */}
                              <div className="absolute left-3 right-3 top-3.5 h-0.5 bg-[#FCE4EC] -z-0" />
                              <div
                                className="absolute left-3 top-3.5 h-0.5 bg-[#E57390] -z-0 transition-all duration-500"
                                style={{
                                  width: `${(Math.max(0, currentStepIdx) / (statusSteps.length - 1)) * 90}%`,
                                }}
                              />

                            {statusSteps.map((st, idx) => {
                              const isDone = idx <= currentStepIdx;
                              const isCurrent = idx === currentStepIdx;
                              const Icon = st.icon;

                              return (
                                <div
                                  key={st.status}
                                  className="flex flex-col items-center relative z-10"
                                >
                                  <div
                                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                                      isDone
                                        ? 'bg-[#E57390] text-white shadow-xs'
                                        : 'bg-white text-stone-300 border border-[#FCE4EC]'
                                    } ${isCurrent ? 'ring-4 ring-[#FFF0F4] scale-110' : ''}`}
                                  >
                                    <Icon className="w-3.5 h-3.5" />
                                  </div>
                                  <span
                                    className={`text-[9px] mt-1 font-medium text-center max-w-[55px] leading-tight ${
                                      isDone ? 'text-[#832F47]' : 'text-stone-400'
                                    }`}
                                  >
                                    {st.label}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}

                      {/* Items */}
                      <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-2 text-xs">
                        <h4 className="font-serif font-bold text-xs tracking-wider uppercase text-[#3B252E] mb-1">
                          {isAr ? 'القطع في هذا الطرد' : 'Items in this Package'}
                        </h4>
                        <div className="divide-y divide-[#FDE7ED]">
                          {order.items.map((item, idx) => {
                            const itemDisplayName =
                              isAr && item.product.arabicName
                                ? item.product.arabicName
                                : item.product.name;

                            return (
                              <div key={idx} className="py-2 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-[#FFF0F4]">
                                    <img
                                      src={getOptimizedImageUrl(item.product.images[0], 100, 'auto', 'fit')}
                                      alt={itemDisplayName}
                                      className="w-full h-full object-cover"
                                      loading="eager"
                                      decoding="async"
                                      width={40}
                                      height={40}
                                    />
                                  </div>
                                  <div>
                                    <p className="font-semibold text-[#3B252E]">{itemDisplayName}</p>
                                    <p className="text-[10px] text-stone-400">
                                      {isAr ? 'الكمية: ' : 'Qty: '}
                                      {item.quantity}{' '}
                                      {item.selectedSize
                                        ? `• ${isAr ? 'المقاس: ' : 'Size: '}${item.selectedSize} `
                                        : ''}
                                      {item.selectedColor
                                        ? `• ${isAr ? 'اللون: ' : 'Color: '}${
                                            item.selectedColor === 'Gold'
                                              ? isAr
                                                ? 'ذهبي'
                                                : 'Gold'
                                              : item.selectedColor === 'Silver'
                                              ? isAr
                                                ? 'فضي'
                                                : 'Silver'
                                              : item.selectedColor
                                          }`
                                        : ''}
                                    </p>
                                  </div>
                                </div>
                                <span className="font-serif font-bold text-[#832F47]">
                                  {formatOMR(item.product.price * item.quantity)}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Delivery Address & Notes */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] space-y-1">
                          <span className="font-serif font-bold text-[#C5A059] uppercase text-[10px] tracking-[0.15em]">
                            {isAr ? 'عنوان التوصيل' : 'Delivery Address'}
                          </span>
                          <p className="font-semibold text-[#3B252E]">{order.customer.name}</p>
                          <p className="text-stone-600">{order.customer.phone}</p>
                          {order.customer.city ? (
                            <>
                              <p className="text-[#832F47] font-semibold text-xs">
                                {order.customer.city} — {order.customer.area}
                              </p>
                              <p className="text-stone-600 text-[11px] leading-relaxed whitespace-pre-line bg-[#FFF9FB] p-2 rounded-xl border border-[#FDE7ED]">
                                {order.customer.detailedAddress || order.customer.address}
                              </p>
                            </>
                          ) : (
                            <>
                              <p className="text-[#832F47] font-medium">
                                {order.customer.area}{order.customer.governorate ? `، ${order.customer.governorate}` : ''}
                              </p>
                              <p className="text-stone-600">{order.customer.address}</p>
                            </>
                          )}
                        </div>

                        <div className="bg-white rounded-2xl p-4 border border-[#FCE4EC] flex flex-col justify-between">
                          <div>
                            <span className="font-serif font-bold text-[#C5A059] uppercase text-[10px] tracking-[0.15em]">
                              {t('orderSummary')}
                            </span>
                            <div className="mt-1 space-y-1 text-[11px] text-stone-600">
                              <div className="flex justify-between">
                                <span>{t('subtotal')}:</span>
                                <span>{formatOMR(order.subtotal)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>{t('deliveryCharge')}:</span>
                                <span>{formatOMR(order.deliveryCharge)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>{isAr ? 'طريقة الدفع:' : 'Payment Method:'}</span>
                                <span className="font-semibold text-stone-800">
                                  {order.paymentMethod === 'bank_transfer'
                                    ? isAr ? 'تحويل بنكي' : 'Bank Transfer'
                                    : order.paymentMethod}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span>{isAr ? 'حالة الدفع:' : 'Payment Status:'}</span>
                                <span className={`font-semibold ${
                                  order.paymentStatus === 'Paid' || order.paymentStatus === 'Payment Verified'
                                    ? 'text-emerald-700'
                                    : 'text-amber-700'
                                }`}>
                                  {order.paymentStatus === 'Paid' || order.paymentStatus === 'Payment Verified'
                                    ? isAr ? 'تم التحقق من الدفع ✓' : 'Payment Verified ✓'
                                    : isAr ? 'بانتظار التحويل البنكي' : 'Pending Payment'}
                                </span>
                              </div>
                              <div className="flex justify-between font-serif font-bold text-xs text-[#832F47] pt-1 border-t border-[#FDE7ED]">
                                <span>{t('total')}:</span>
                                <span>{formatOMR(order.total)}</span>
                              </div>
                            </div>
                          </div>

                          <a
                            href={generateWhatsAppOrderUrl({
                              customerName: order.customer.name,
                              phone: order.customer.phone,
                              items: order.items,
                              subtotal: order.subtotal,
                              delivery: order.deliveryCharge,
                              deliveryMethod: order.deliveryMethod,
                              total: order.total,
                              deliveryAddress: order.customer.city
                                ? `${order.customer.city}, ${order.customer.area}, ${order.customer.detailedAddress || order.customer.address}`
                                : `${order.customer.address}, ${order.customer.area}`,
                              city: order.customer.city,
                              area: order.customer.area,
                              detailedAddress: order.customer.detailedAddress || order.customer.address,
                              notes: isAr
                                ? `استفسار بخصوص الطلب رقم #${order.orderNumber}`
                                : `Inquiry regarding order #${order.orderNumber}`,
                            })}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-3 py-2 px-3 bg-[#25D366] text-white rounded-full font-semibold text-[11px] flex items-center justify-center gap-1 hover:bg-[#20BE5C] transition-colors"
                          >
                            <MessageCircle className="w-3.5 h-3.5 fill-white" />
                            <span>
                              {isAr
                                ? 'الاستفسار عن هذا الطلب بالواتساب'
                                : 'Ask About This Order on WhatsApp'}
                            </span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Tab 2: Personal Profile */}
      {activeTab === 'profile' && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-white rounded-3xl p-5 sm:p-6 border border-[#FCE4EC] space-y-4 shadow-2xs"
        >
          <h3 className="font-serif font-bold text-xs tracking-[0.15em] text-[#832F47] uppercase">
            {t('personalInfo')}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                {t('fullName')}
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                {t('phoneNumber')}
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                {t('whatsappNumber')}
              </label>
              <input
                type="tel"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#3B252E] mb-1 tracking-wide">
                {t('emailAddress')}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 bg-white border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
              />
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#E57390] hover:bg-[#D45E7C] text-white text-xs font-semibold tracking-widest uppercase rounded-full shadow-xs transition-all cursor-pointer"
            >
              {t('saveProfile')}
            </button>
            {isSaved && (
              <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                {isAr ? 'تم حفظ التعديلات بنجاح!' : 'Updated successfully!'}
              </span>
            )}
          </div>
        </form>
      )}

      {/* Tab 3: Saved Addresses */}
      {activeTab === 'addresses' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-xs tracking-[0.15em] text-[#832F47] uppercase">
              {isAr ? 'عناوين التوصيل المحفوظة في عُمان' : 'Saved Oman Addresses'}
            </h3>
            <button
              onClick={() => setIsAddingAddress(!isAddingAddress)}
              className="px-3.5 py-1.5 bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] text-xs font-semibold rounded-full border border-[#FCE4EC] flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('addNewAddress')}</span>
            </button>
          </div>

          {/* Add Address Form */}
          {isAddingAddress && (
            <form
              onSubmit={handleSaveNewAddress}
              className="bg-white rounded-3xl p-5 border border-[#FCE4EC] space-y-3 animate-in fade-in duration-200"
            >
              <h4 className="font-serif font-bold text-xs tracking-wider uppercase text-[#3B252E]">
                {isAr ? 'إضافة عنوان توصيل جديد' : 'New Delivery Location'}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-stone-600 mb-1">
                    {isAr ? 'اسم العنوان (مثل: المنزل، العمل)' : 'Label (e.g. Home, Office)'}
                  </label>
                  <input
                    type="text"
                    required
                    value={newAddrTitle}
                    onChange={(e) => setNewAddrTitle(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-stone-600 mb-1">
                    {t('governorate')}
                  </label>
                  <select
                    value={newAddrGov}
                    onChange={(e) => setNewAddrGov(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl"
                  >
                    {OMAN_GOVERNORATES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-stone-600 mb-1">
                    {t('areaCity')}
                  </label>
                  <input
                    type="text"
                    required
                    value={newAddrArea}
                    onChange={(e) => setNewAddrArea(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-stone-600 mb-1">
                  {t('streetAddress')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={t('streetAddressPlaceholder')}
                  value={newAddrStreet}
                  onChange={(e) => setNewAddrStreet(e.target.value)}
                  className="w-full text-xs px-3 py-2 bg-white border border-[#FCE4EC] rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingAddress(false)}
                  className="px-4 py-2 text-xs font-medium text-stone-500 hover:text-stone-800 cursor-pointer"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#E57390] text-white text-xs font-semibold rounded-full hover:bg-[#D45E7C] cursor-pointer"
                >
                  {t('saveAddress')}
                </button>
              </div>
            </form>
          )}

          {/* List */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {profile.addresses.map((addr) => (
              <div
                key={addr.id}
                className="bg-white rounded-2xl p-4 border border-[#FCE4EC] flex flex-col justify-between shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-semibold text-xs text-[#832F47] bg-[#FFF0F4] px-2.5 py-0.5 rounded-full border border-[#FCE4EC]">
                      {addr.title}
                    </span>
                    {addr.isDefault ? (
                      <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        {t('defaultAddress')}
                      </span>
                    ) : (
                      <button
                        onClick={() => handleSetDefaultAddress(addr.id)}
                        className="text-[10px] text-[#C5A059] hover:underline font-medium cursor-pointer"
                      >
                        {t('setDefault')}
                      </button>
                    )}
                  </div>

                  <p className="font-semibold text-xs text-[#3B252E]">{addr.recipientName}</p>
                  <p className="text-[11px] text-stone-500">{addr.phone}</p>
                  <p className="text-xs text-stone-700 mt-1">{addr.streetAddress}</p>
                  <p className="text-xs text-[#C5A059] font-medium">
                    {addr.area}، {addr.governorate}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-[#FDE7ED] flex justify-end">
                  <button
                    onClick={() => handleDeleteAddress(addr.id)}
                    className="text-stone-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                    title={t('deleteAddress')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Discreet Boutique & Staff Access Footer */}
      <StoreFooter />
    </div>
  );
};
