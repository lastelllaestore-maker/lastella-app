import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw, RotateCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public override state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[LASTELLA App Error]', error, errorInfo);
  }

  private handleReset = () => {
    try {
      localStorage.removeItem('lastella_products_v1');
      localStorage.removeItem('lastella_settings_v1');
      localStorage.removeItem('lastella_orders_v1');
      localStorage.removeItem('lastella_my_orders_v1');
      localStorage.removeItem('lastella_cart_v1');
      sessionStorage.clear();
    } catch (e) {
      console.error('Failed to clear cache', e);
    }
    window.location.href = window.location.origin + window.location.pathname;
  };

  private handleReload = () => {
    window.location.reload();
  };

  public override render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[80vh] flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white max-w-md w-full rounded-3xl p-6 sm:p-8 border border-[#FCE4EC] shadow-xl text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-[#FFF0F4] border border-[#FCE4EC] mx-auto flex items-center justify-center text-[#832F47] shadow-xs">
              <ShieldAlert className="w-8 h-8 text-[#832F47]" />
            </div>

            <div>
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
                LASTELLA BOUTIQUE
              </span>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#3B252E] mt-1">
                تنبيه أثناء عرض الصفحة
              </h2>
              <p className="text-xs text-stone-500 mt-1.5 leading-relaxed">
                حدث خطأ غير متوقع أثناء تحميل هذه الصفحة. يمكنكِ تحديث الصفحة أو إعادة ضبط الذاكرة المؤقتة.
              </p>
            </div>

            {this.state.error && (
              <div className="bg-[#FFF9FB] p-3 rounded-xl border border-[#FCE4EC] text-left text-[11px] font-mono text-rose-700 overflow-x-auto max-h-28" dir="ltr">
                {this.state.error.toString()}
              </div>
            )}

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={this.handleReload}
                className="w-full py-3 px-4 rounded-2xl bg-[#E57390] hover:bg-[#D45E7C] active:scale-98 text-white font-semibold text-xs tracking-wider uppercase shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
              >
                <RefreshCw className="w-4 h-4" />
                <span>إعادة تحديث الصفحة (Refresh)</span>
              </button>

              <button
                onClick={this.handleReset}
                className="w-full py-2.5 px-4 rounded-2xl bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] font-semibold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer min-h-[40px]"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة ضبط المتجر والمخزن المؤقت</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
