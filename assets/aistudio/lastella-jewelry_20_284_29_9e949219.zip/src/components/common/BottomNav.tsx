import React from 'react';
import { useStore, NavigationTab } from '../../context/StoreContext';
import {
  Home,
  Grid,
  Search,
  Heart,
  ShoppingBag,
  User,
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const {
    currentTab,
    setCurrentTab,
    cartCount,
    wishlistIds,
    setSelectedCategory,
    language,
    t,
  } = useStore();

  const isAr = language === 'ar';

  // Customer Navigation Items
  const customerNavItems = [
    {
      id: 'home' as NavigationTab,
      label: t('navHome'),
      icon: Home,
      action: () => {
        setSelectedCategory(null);
        setCurrentTab('home');
      },
    },
    {
      id: 'categories' as NavigationTab,
      label: t('navCategories'),
      icon: Grid,
      action: () => {
        setCurrentTab('categories');
      },
    },
    {
      id: 'search' as NavigationTab,
      label: t('navSearch'),
      icon: Search,
      action: () => {
        setCurrentTab('search');
      },
    },
    {
      id: 'wishlist' as NavigationTab,
      label: t('navWishlist'),
      icon: Heart,
      badge: wishlistIds.length > 0 ? wishlistIds.length : undefined,
      action: () => {
        setCurrentTab('wishlist');
      },
    },
    {
      id: 'cart' as NavigationTab,
      label: t('navCart'),
      icon: ShoppingBag,
      badge: cartCount > 0 ? cartCount : undefined,
      action: () => {
        setCurrentTab('cart');
      },
    },
    {
      id: 'account' as NavigationTab,
      label: t('navAccount'),
      icon: User,
      action: () => {
        setCurrentTab('account');
      },
    },
  ];

  // If currently in Admin Dashboard, do not render customer BottomNav so it never obstructs admin content
  if (currentTab === 'admin') {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-[#FCE4EC] py-1.5 px-3 pb-safe shadow-[0_-4px_20px_rgba(230,150,175,0.1)]">
      <div className="max-w-md mx-auto grid grid-cols-6 items-center">
        {customerNavItems.map((item) => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={item.action}
              className={`relative flex flex-col items-center justify-center py-1 transition-all group ${
                isActive ? 'text-[#832F47]' : 'text-stone-500 hover:text-[#832F47]'
              }`}
            >
              {/* Active soft blush pill highlight */}
              <div
                className={`relative p-1.5 rounded-2xl transition-all ${
                  isActive ? 'bg-[#FDE7ED] text-[#832F47] scale-105 shadow-2xs' : 'group-hover:bg-[#FFF0F4]'
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'stroke-[2.2px]' : 'stroke-[1.7px]'
                  } ${item.id === 'wishlist' && isActive ? 'fill-[#E57390] text-[#E57390]' : ''}`}
                />

                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-1 bg-[#E57390] text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full min-w-[16px] text-center shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[9px] xs:text-[10px] tracking-tight mt-0.5 transition-all truncate max-w-[48px] xs:max-w-none text-center ${
                  isActive ? 'font-bold text-[#832F47]' : 'font-medium text-stone-500'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
