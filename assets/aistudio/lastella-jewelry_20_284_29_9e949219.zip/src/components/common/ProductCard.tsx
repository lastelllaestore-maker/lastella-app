import React, { useState, useCallback, memo } from 'react';
import { Product } from '../../types';
import { useProductActions } from '../../context/StoreContext';
import { Heart, Plus, Sparkles, Check } from 'lucide-react';
import { RingSizeModal } from './RingSizeModal';
import { getCategoryTranslation } from '../../i18n/translations';
import { getOptimizedImageUrl } from '../../services/cloudinaryService';

interface ProductCardProps {
  product: Product;
  onOpenDetails?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = memo(({ product, onOpenDetails }) => {
  const {
    formatOMR,
    addToCart,
    showToast,
    toggleWishlist,
    isInWishlist,
    setSelectedProduct,
    language,
    t,
  } = useProductActions();

  const [isHovered, setIsHovered] = useState(false);
  const [isSizeModalOpen, setIsSizeModalOpen] = useState(false);
  const [isAddedRecently, setIsAddedRecently] = useState(false);

  const displayName = language === 'ar' && product.arabicName ? product.arabicName : product.name;
  const displayCategory = getCategoryTranslation(product.category, language);

  const inWishlist = isInWishlist(product.id);
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0;

  const handleCardClick = (e: React.MouseEvent) => {
    // Native browser click cleanly allows scrolling without false triggers
    if (onOpenDetails) {
      onOpenDetails(product);
    } else {
      setSelectedProduct(product);
    }
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.inStock === false) {
      showToast(
        language === 'ar'
          ? 'عذراً، هذه القطعة غير متوفرة حالياً للطلب'
          : 'Sorry, this product is currently unavailable for order'
      );
      return;
    }

    const hasVariants = !!(product.variants && product.variants.length > 0);
    const hasMultipleSizes = product.sizes && product.sizes.length > 1;
    const hasMultipleColors = product.colors && product.colors.length > 1;

    // If product has multiple variants or options, open details modal for customer selection
    if (hasVariants) {
      if (product.variants!.length > 1) {
        if (onOpenDetails) {
          onOpenDetails(product);
        } else {
          setSelectedProduct(product);
        }
        return;
      }
      // Single variant check
      const singleVar = product.variants![0];
      if (singleVar.available === false) {
        if (onOpenDetails) {
          onOpenDetails(product);
        } else {
          setSelectedProduct(product);
        }
        return;
      }
      addToCart(
        product,
        1,
        singleVar.sizeEn,
        singleVar.colorEn,
        singleVar.id,
        singleVar.sizeAr,
        singleVar.colorAr
      );
      setIsAddedRecently(true);
      setTimeout(() => setIsAddedRecently(false), 1500);
      return;
    }

    if (hasMultipleSizes || hasMultipleColors) {
      if (onOpenDetails) {
        onOpenDetails(product);
      } else {
        setSelectedProduct(product);
      }
      return;
    }

    if (product.category === 'Rings' && product.sizes && product.sizes.length > 0) {
      setIsSizeModalOpen(true);
      return;
    }

    const defaultSize = product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined;
    const defaultColor = product.colors && product.colors.length > 0 ? product.colors[0] : undefined;

    addToCart(product, 1, defaultSize, defaultColor);
    setIsAddedRecently(true);
    setTimeout(() => setIsAddedRecently(false), 1500);
  };

  const handleSizeSelected = (size: number) => {
    const defaultColor = product.colors && product.colors.length > 0 ? product.colors[0] : undefined;
    addToCart(product, 1, size, defaultColor);
    setIsAddedRecently(true);
    setTimeout(() => setIsAddedRecently(false), 1500);
  };

  return (
    <>
      <div
        id={`product-card-${product.id}`}
        onClick={handleCardClick}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="group relative bg-white rounded-2xl border border-[#FCE4EC] p-2 sm:p-3 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:border-[#F8BBD0] hover:-translate-y-0.5 cursor-pointer subtle-card-shadow text-start"
      >
        {/* Top Badges & Wishlist Action */}
        <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-[#FFF5F8] mb-2 sm:mb-2.5">
          {/* Main & Hover Image with direct eager loading and WebP optimization */}
          <img
            src={getOptimizedImageUrl(
              isHovered && product.images[1] ? product.images[1] : product.images[0],
              460,
              'auto',
              'fit'
            )}
            alt={displayName}
            className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
            loading="eager"
            decoding="async"
            width={240}
            height={240}
          />

          {/* Badges Container */}
          <div className="absolute top-2 start-2 flex flex-col gap-1 z-10">
            {product.inStock === false && (
              <span className="bg-rose-700 text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wider uppercase shadow-xs">
                {t('outOfStock')}
              </span>
            )}
            {product.isBestSeller && (
              <span className="bg-[#E57390] text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wider uppercase shadow-xs flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5 text-[#FFF0F4]" /> {t('bestSeller')}
              </span>
            )}
            {product.isNewArrival && !product.isBestSeller && (
              <span className="bg-[#C5A059] text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wider uppercase shadow-xs">
                {t('newArrival')}
              </span>
            )}
            {hasDiscount && (
              <span className="bg-[#F06292] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-xs">
                -{discountPercent}%
              </span>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            id={`btn-wishlist-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            className={`absolute top-2 end-2 p-2 rounded-full backdrop-blur-md transition-all active:scale-90 z-10 ${
              inWishlist
                ? 'bg-[#E57390] text-white shadow-md'
                : 'bg-white/90 text-[#832F47] hover:bg-white hover:text-[#E57390]'
            }`}
            aria-label={inWishlist ? t('removeFromWishlist') : t('addToWishlist')}
          >
            <Heart
              className={`w-4 h-4 transition-transform ${
                inWishlist ? 'fill-white stroke-white scale-110' : 'stroke-[2px]'
              }`}
            />
          </button>

          {/* Quick ring size guide pill if ring */}
          {product.category === 'Rings' && (
            <div className="absolute bottom-2 start-2 bg-white/95 backdrop-blur-xs text-[9px] font-semibold text-[#832F47] px-2 py-0.5 rounded-full border border-[#FCE4EC]">
              {language === 'ar' ? 'المقاسات: 14–19' : 'Sizes: 14–19'}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col flex-1 justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-[0.1em] text-[#C5A059] line-clamp-1">
              {displayCategory}
            </span>
            <h3 className="font-serif text-xs sm:text-sm font-semibold text-[#3B252E] line-clamp-2 leading-snug group-hover:text-[#832F47] transition-colors mt-0.5">
              {displayName}
            </h3>
          </div>

          {/* Price & Action Row */}
          <div className="mt-2.5 pt-2 border-t border-[#FDE7ED] flex items-center justify-between gap-1">
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1.5 flex-wrap">
                <span className="font-bold text-xs sm:text-sm text-[#3B252E]">
                  {formatOMR(product.price)}
                </span>
                {hasDiscount && (
                  <span className="text-[10px] text-stone-400 line-through">
                    {formatOMR(product.originalPrice!)}
                  </span>
                )}
              </div>
              {product.inStock === false ? (
                <span className="text-[9px] text-rose-600 font-semibold">{t('outOfStock')}</span>
              ) : (
                <span className="text-[9px] text-emerald-600 font-medium">{t('inStock')}</span>
              )}
            </div>

            {/* Quick Add Button */}
            <button
              id={`btn-add-cart-${product.id}`}
              onClick={handleQuickAdd}
              disabled={product.inStock === false}
              className={`p-2 rounded-xl text-xs font-semibold flex items-center justify-center transition-all shrink-0 min-w-[32px] min-h-[32px] ${
                product.inStock === false
                  ? 'bg-stone-100 text-stone-400 border border-stone-200 cursor-not-allowed opacity-60'
                  : isAddedRecently
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#FFF0F4] text-[#832F47] border border-[#FCE4EC] hover:bg-[#E57390] hover:text-white hover:border-[#E57390] active:scale-90 cursor-pointer'
              }`}
              title={product.inStock === false ? t('outOfStock') : t('addToCart')}
            >
              {isAddedRecently ? (
                <Check className="w-4 h-4" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Ring Size Sizing Modal */}
      <RingSizeModal
        isOpen={isSizeModalOpen}
        onClose={() => setIsSizeModalOpen(false)}
        onSelectSize={handleSizeSelected}
      />
    </>
  );
});

ProductCard.displayName = 'ProductCard';
