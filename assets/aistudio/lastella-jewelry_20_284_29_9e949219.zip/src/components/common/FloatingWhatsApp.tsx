import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { MessageCircle, X, Send } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const { generateGeneralWhatsAppUrl, settings, language } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [customQuery, setCustomQuery] = useState('');

  const isAr = language === 'ar';

  const quickPrompts = isAr
    ? [
        'هل يمكنني رؤية المزيد من صور الخواتم؟',
        'هل يتوفر توصيل إلى صلالة / صحار / كافة المحافظات؟',
        'كم يستغرق التوصيل داخل مسقط؟',
        'كيف أؤكد عملية التحويل البنكي لطلبي؟',
      ]
    : [
        'Can I see more pictures of rings?',
        'Do you deliver to Salalah / Sohar?',
        'How long is the delivery in Muscat?',
        'How do I complete my bank transfer payment?',
      ];

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuery.trim()) return;
    const url = generateGeneralWhatsAppUrl(customQuery);
    window.open(url, '_blank');
    setIsOpen(false);
    setCustomQuery('');
  };

  return (
    <div
      className={`fixed bottom-20 ${isAr ? 'left-4 items-start' : 'right-4 items-end'} z-40 flex flex-col`}
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Popover Bubble */}
      {isOpen && (
        <div className="mb-3 w-[calc(100vw-32px)] max-w-xs sm:w-80 bg-white rounded-2xl p-4 shadow-xl border border-[#FCE4EC] animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-[#FDE7ED]">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#25D366]/10 flex items-center justify-center text-[#25D366]">
                <MessageCircle className="w-5 h-5 fill-[#25D366]" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[#3B252E]">
                  {isAr ? 'خدمة عملاء LASTELLA' : 'LASTELLA Concierge'}
                </h4>
                <p className="text-[10px] text-[#25D366] font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#25D366] animate-pulse"></span>
                  {isAr ? 'متواجدون الآن • دعم واتساب مباشر' : 'Online • WhatsApp Support'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full text-stone-400 hover:text-stone-600 hover:bg-stone-100"
              aria-label="Close chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-stone-600 my-2.5 leading-relaxed">
            {isAr
              ? 'مرحباً بكِ في مجوهرات لاستيلا! 🌸 كيف يمكننا مساعدتكِ اليوم في اختيار قطعتكِ الفاخرة؟'
              : 'Welcome to LASTELLA! 🌸 How may our jewelry concierge assist you today?'}
          </p>

          {/* Quick options */}
          <div className="space-y-1.5 mb-3">
            {quickPrompts.map((prompt, idx) => (
              <a
                key={idx}
                href={generateGeneralWhatsAppUrl(prompt)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen(false)}
                className="block text-[11px] p-2 bg-[#FFF0F4] hover:bg-[#FCE4EC] text-[#832F47] font-medium rounded-lg border border-[#FCE4EC] transition-colors text-start"
              >
                💬 {prompt}
              </a>
            ))}
          </div>

          {/* Custom query input */}
          <form onSubmit={handleSendCustom} className="flex items-center gap-1.5 pt-2 border-t border-[#FDE7ED]">
            <input
              type="text"
              placeholder={isAr ? 'اكتبي استفساركِ هنا...' : 'Type your question...'}
              value={customQuery}
              onChange={(e) => setCustomQuery(e.target.value)}
              className="flex-1 text-xs px-3 py-1.5 bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl focus:outline-hidden focus:border-[#E57390]"
            />
            <button
              type="submit"
              className="p-2 bg-[#25D366] text-white rounded-xl hover:bg-[#20BE5C] transition-colors shrink-0"
              title={isAr ? 'إرسال عبر واتساب' : 'Open WhatsApp'}
            >
              <Send className={`w-3.5 h-3.5 ${isAr ? 'rotate-180' : ''}`} />
            </button>
          </form>

          <p className="text-[9px] text-center text-stone-400 mt-2">
            {isAr ? 'رد مباشر وسريع من مسقط:' : 'Direct response from Muscat:'} {settings.displayWhatsApp}
          </p>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        id="btn-floating-whatsapp"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3.5 py-2.5 bg-[#25D366] text-white rounded-full shadow-lg hover:bg-[#20bd5a] hover:shadow-xl active:scale-95 transition-all group"
        aria-label="Contact LASTELLA on WhatsApp"
      >
        <MessageCircle className="w-5 h-5 fill-white" />
        <span className="text-xs font-semibold tracking-wide hidden sm:inline">
          {isAr ? 'خدمة العملاء عبر واتساب' : 'Chat with WhatsApp Support'}
        </span>
      </button>
    </div>
  );
};
