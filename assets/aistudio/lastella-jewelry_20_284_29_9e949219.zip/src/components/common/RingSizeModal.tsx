import React from 'react';
import { X, Sparkles, CheckCircle2 } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { toArabicDigits } from '../../services/translationService';

interface RingSizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSize?: number | string;
  onSelectSize?: (size: number) => void;
}

export const RingSizeModal: React.FC<RingSizeModalProps> = ({
  isOpen,
  onClose,
  selectedSize,
  onSelectSize,
}) => {
  const { language, t } = useStore();
  if (!isOpen) return null;

  const isAr = language === 'ar';

  const sizeChart = [
    { size: 14, diameterMm: 17.2, circumferenceMm: 54.0, fit: isAr ? 'صغير / خنصر' : 'Small / Pinky / Petite' },
    { size: 15, diameterMm: 17.5, circumferenceMm: 55.0, fit: isAr ? 'صغير قياسي' : 'Standard Petite' },
    { size: 16, diameterMm: 17.8, circumferenceMm: 56.0, fit: isAr ? 'متوسط (الأكثر طلباً)' : 'Medium (Most Popular)' },
    { size: 17, diameterMm: 18.1, circumferenceMm: 57.0, fit: isAr ? 'متوسط / كبير' : 'Medium / Large' },
    { size: 18, diameterMm: 18.5, circumferenceMm: 58.0, fit: isAr ? 'كبير' : 'Large' },
    { size: 19, diameterMm: 18.8, circumferenceMm: 59.0, fit: isAr ? 'عريض / سبابة' : 'Statement / Index' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl border border-[#FCE4EC] text-start">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#FFF0F4] to-[#FCE4EC] border-b border-[#FCE4EC] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#C5A059]" />
            <h3 className="font-brand font-bold text-sm tracking-wider text-[#832F47]">
              {isAr ? 'دليل مقاسات خواتم لاستيلا' : 'LASTELLA RING SIZE GUIDE'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-white/80"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[75vh] overflow-y-auto">
          <p className="text-xs text-stone-600 mb-4 leading-relaxed">
            {isAr
              ? 'تعتمد جميع خواتم لاستيلا المقاسات المعتمدة في الخليج وأوروبا. اختاري مقاسكِ المفضل أو قومي بقياس القطر الداخلي لخاتمكِ الحالي:'
              : 'All LASTELLA rings follow standard European/Gulf sizing. Select your preferred size or measure the inside diameter of your existing ring:'}
          </p>

          {/* Table */}
          <div className="border border-[#FCE4EC] rounded-xl overflow-hidden mb-4">
            <div className="grid grid-cols-4 bg-[#FFF0F4] p-2.5 text-[11px] font-bold text-[#832F47] tracking-wide">
              <div>{isAr ? 'المقاس' : 'Size'}</div>
              <div>{isAr ? 'القطر' : 'Diameter'}</div>
              <div>{isAr ? 'المحيط' : 'Circumf.'}</div>
              <div className="text-end">{isAr ? 'اختيار' : 'Select'}</div>
            </div>
            <div className="divide-y divide-[#FDE7ED]">
              {sizeChart.map((row) => {
                const isSelected = selectedSize !== undefined && String(selectedSize) === String(row.size);
                return (
                  <div
                    key={row.size}
                    onClick={() => {
                      if (onSelectSize) {
                        onSelectSize(row.size);
                        onClose();
                      }
                    }}
                    className={`grid grid-cols-4 p-2.5 text-xs items-center cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#FFF0F4] font-semibold text-[#832F47]'
                        : 'hover:bg-[#FFF9FB] text-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-white border border-[#FCE4EC] flex items-center justify-center font-bold text-[11px] text-[#832F47]">
                        {isAr ? toArabicDigits(String(row.size)) : row.size}
                      </span>
                    </div>
                    <div>{isAr ? toArabicDigits(String(row.diameterMm)) : row.diameterMm} {isAr ? 'ملم' : 'mm'}</div>
                    <div>{isAr ? toArabicDigits(String(row.circumferenceMm)) : row.circumferenceMm} {isAr ? 'ملم' : 'mm'}</div>
                    <div className="text-end">
                      {isSelected ? (
                        <span className="inline-flex items-center gap-1 text-[10px] text-[#832F47] font-bold bg-white px-2 py-0.5 rounded-full border border-[#FCE4EC]">
                          <CheckCircle2 className="w-3 h-3 text-[#E57390]" /> {isAr ? 'تم الاختيار' : 'Selected'}
                        </span>
                      ) : (
                        <span className="text-[11px] text-[#C5A059] font-semibold hover:underline">
                          {isAr ? 'تحديد' : 'Choose'}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Sizing tip */}
          <div className="bg-[#FFF9FB] border border-[#FCE4EC] rounded-xl p-3.5 text-xs space-y-1.5 text-stone-600">
            <p className="font-bold text-[#832F47] flex items-center gap-1">
              💡 {isAr ? 'نصيحة لقياس دقيق:' : 'Quick Sizing Tip:'}
            </p>
            <p className="text-[11px] leading-relaxed">
              {isAr
                ? 'لفي شريطاً ورقياً رفيعاً أو خيطاً حول عقلة إصبعك، ضعي علامة عند نقطة الالتقاء، ثم قيسي الطول بالمسطرة بالمليمتر لمعرفة مقاس المحيط.'
                : 'Wrap a thin strip of paper or string around your finger knuckle, mark where it overlaps, and measure the length in millimeters to find your circumference.'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#FFF9FB] border-t border-[#FCE4EC] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#E57390] text-white text-xs font-semibold rounded-xl hover:bg-[#D45E7C] transition-colors"
          >
            {isAr ? 'تم' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
