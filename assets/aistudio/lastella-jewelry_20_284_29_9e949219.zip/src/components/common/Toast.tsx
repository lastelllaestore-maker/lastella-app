import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Sparkles } from 'lucide-react';

interface ToastProps {
  message?: string | null;
}

export const Toast: React.FC<ToastProps> = ({ message: propMessage }) => {
  const { toastMessage: storeMessage } = useStore();
  const activeMessage = propMessage !== undefined ? propMessage : storeMessage;

  if (!activeMessage) return null;

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-in fade-in slide-in-from-top-3 duration-200">
      <div className="bg-[#2D1B22]/95 backdrop-blur-md text-[#FFF0F3] px-4 py-2.5 rounded-full shadow-2xl border border-[#C5A059]/40 flex items-center gap-2 text-xs font-semibold tracking-wide">
        <Sparkles className="w-4 h-4 text-[#E6CA65] animate-spin" />
        <span>{activeMessage}</span>
      </div>
    </div>
  );
};
