import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Bell, MessageCircle, Sparkles, Languages } from 'lucide-react';
import brandLogoImg from '../../assets/images/regenerated_image_1791467100620.jpg';

export const Header: React.FC = () => {
  const {
    currentTab,
    setCurrentTab,
    setIsNotificationsOpen,
    unreadNotifsCount,
    generateGeneralWhatsAppUrl,
    settings,
    language,
    toggleLanguage,
    t,
  } = useStore();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#FCE4EC] shadow-xs pt-[env(safe-area-inset-top,0px)]">
      {/* Announcement Bar - Soft Rose Pink with White Text & Gold Sparkle */}
      <div className="bg-[#EFA8BA] text-white px-3 sm:px-4 py-1.5 text-[11px] sm:text-xs text-center font-medium tracking-wide flex items-center justify-center gap-1.5 overflow-hidden shadow-xs">
        <Sparkles className="w-3.5 h-3.5 text-[#FFF0F4] shrink-0" />
        <span className="truncate drop-shadow-2xs">{settings.announcementText?.trim() || t('announcement')}</span>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-2.5 sm:px-4 py-2 sm:py-2.5 flex items-center justify-between gap-2">
        {/* Brand Logo */}
        <button
          id="btn-brand-logo"
          onClick={() => setCurrentTab('home')}
          className="flex items-center text-start transition-transform active:scale-95 shrink-0"
          aria-label="Lastella Boutique Home"
        >
          <img
            src={brandLogoImg}
            alt="Lastella - BIG BRAND SMALL PRICE"
            className="w-[132px] xs:w-[142px] sm:w-[165px] h-[54px] xs:h-[58px] sm:h-[64px] object-contain object-center select-none"
            loading="eager"
            decoding="async"
          />
        </button>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Language Toggle Button */}
          <button
            id="btn-header-language-toggle"
            onClick={toggleLanguage}
            title={t('switchLanguage')}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-full bg-[#FFF0F4] hover:bg-[#FDE7ED] border border-[#FCE4EC] text-[#832F47] text-xs font-semibold active:scale-95 transition-all shadow-2xs min-h-[36px]"
          >
            <Languages className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
            <span className="font-medium text-[11px] hidden sm:inline">{t('langToggle')}</span>
            <span className="font-medium text-[11px] sm:hidden uppercase">{language === 'ar' ? 'EN' : 'ع'}</span>
          </button>

          {/* Quick WhatsApp Support */}
          <a
            id="btn-header-whatsapp"
            href={generateGeneralWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            title="Chat on WhatsApp"
            className="p-1.5 sm:p-2 rounded-full text-[#25D366] hover:bg-[#EBFBF0] active:scale-90 transition-all flex items-center justify-center min-h-[36px] min-w-[36px]"
          >
            <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 fill-[#25D366]/20" />
          </a>

          {/* Notifications */}
          <button
            id="btn-header-notifications"
            onClick={() => setIsNotificationsOpen(true)}
            className="relative p-1.5 sm:p-2 rounded-full text-[#3B252E] hover:bg-[#FFF0F4] active:scale-90 transition-all min-h-[36px] min-w-[36px] flex items-center justify-center"
            title={t('navNotifications')}
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5 text-[#832F47]" />
            {unreadNotifsCount > 0 && (
              <span className="absolute top-1 right-1 w-3.5 h-3.5 bg-[#E57390] text-white text-[8px] font-bold rounded-full flex items-center justify-center ring-1 ring-white">
                {unreadNotifsCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
