import React from 'react';

interface ProductListingContainerProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
}

/**
 * ProductListingContainer provides consistent grid layout with native browser/WebView
 * touch-action: pan-y for smooth 60fps scrolling without main-thread touch interception.
 */
export const ProductListingContainer: React.FC<ProductListingContainerProps> = ({
  children,
  className = 'grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4',
  id,
}) => {
  return (
    <div id={id} className={className}>
      {children}
    </div>
  );
};
