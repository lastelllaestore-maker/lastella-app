import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onDismiss?: () => void;
  minDurationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onDismiss,
  minDurationMs = 1200,
}) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsFadingOut(true);
      const dismissTimer = setTimeout(() => {
        setIsVisible(false);
        if (onDismiss) onDismiss();
      }, 400); // 400ms smooth fade-out transition
      return () => clearTimeout(dismissTimer);
    }, minDurationMs);

    return () => clearTimeout(timer);
  }, [minDurationMs, onDismiss]);

  if (!isVisible) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[99999] bg-white flex flex-col items-center justify-center select-none pointer-events-none transition-opacity duration-400 ease-out ${
        isFadingOut ? 'opacity-0' : 'opacity-100'
      }`}
      style={{
        paddingTop: 'env(safe-area-inset-top, 0px)',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
    >
      <div className="flex flex-col items-center justify-center max-w-xs sm:max-w-sm px-6 text-center animate-in fade-in zoom-in-95 duration-500">
        {/* Official LASTELLA Logo: Pink Crowned Swan + LASTELLA + BIG BRAND SMALL PRICE */}
        <img
          src="/lastella_official_logo.png"
          alt="LASTELLA - BIG BRAND SMALL PRICE"
          className="w-64 sm:w-72 max-w-full h-auto object-contain drop-shadow-xs"
          loading="eager"
          decoding="sync"
        />

        {/* Subtle, luxury soft pink loading shimmer pill */}
        <div className="mt-8 flex items-center gap-1.5 opacity-80">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E57390] animate-bounce [animation-delay:-0.3s]"></span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#E57390] animate-bounce [animation-delay:-0.15s]"></span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#E57390] animate-bounce"></span>
        </div>
      </div>
    </div>
  );
};
