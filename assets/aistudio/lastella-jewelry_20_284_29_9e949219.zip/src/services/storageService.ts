import { Product, Order, CartItem, AppNotification, UserProfile, StoreSettings, Banner, Review, OrderStatus, DeliveryMethod, Language } from '../types';
import { INITIAL_PRODUCTS, INITIAL_SETTINGS, INITIAL_BANNERS, INITIAL_REVIEWS } from '../data/initialData';
import { firebaseService } from './firebaseService';

const STORAGE_KEYS = {
  LANGUAGE: 'lastella_language_v1',
  PRODUCTS: 'lastella_products_v1',
  CART: 'lastella_cart_v1',
  WISHLIST: 'lastella_wishlist_v1',
  ORDERS: 'lastella_orders_v1',
  MY_ORDERS: 'lastella_my_orders_v1',
  NOTIFICATIONS: 'lastella_notifications_v1',
  PROFILE: 'lastella_profile_v1',
  SETTINGS: 'lastella_settings_v1',
  BANNERS: 'lastella_banners_v1',
  REVIEWS: 'lastella_reviews_v1',
  RECENT_SEARCHES: 'lastella_recent_searches_v1',
  DELIVERY_METHOD: 'lastella_delivery_method_v1',
  ADMIN_AUTH: 'lastella_admin_auth_v1',
};

// Initial notifications
const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    title: '✨ Welcome to LASTELLA Boutique!',
    message: 'Enjoy timeless elegance with 1-Year Warranty & fast delivery all over Oman.',
    type: 'arrival',
    timestamp: 'Just now',
    read: false,
  },
  {
    id: 'notif-2',
    title: '🎁 Ramadan & Festive Special Offer',
    message: 'Complimentary Signature LED Luxury Velvet Box on orders above 10.000 OMR.',
    type: 'offer',
    timestamp: '1 hour ago',
    read: false,
  },
];

// In-memory fallback cache for mobile webviews, incognito mode, or restricted environments
const memoryCache: Record<string, any> = {};

function safeGetCookie(name: string): string | null {
  try {
    if (typeof document === 'undefined') return null;
    const match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
    return match ? decodeURIComponent(match[3]) : null;
  } catch {
    return null;
  }
}

function safeSetCookie(name: string, value: string, maxAgeDays = 30): void {
  try {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=${maxAgeDays * 86400}; SameSite=Lax`;
  } catch {
    // ignore
  }
}

function safeRemoveCookie(name: string): void {
  try {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax`;
  } catch {
    // ignore
  }
}

export const storageService = {
  // PRODUCTS (Read-only performance & offline cache for Firestore Single Source of Truth)
  getCachedProducts(): Product[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          memoryCache[STORAGE_KEYS.PRODUCTS] = parsed;
          return parsed;
        }
      }
      if (memoryCache[STORAGE_KEYS.PRODUCTS] && Array.isArray(memoryCache[STORAGE_KEYS.PRODUCTS])) {
        return memoryCache[STORAGE_KEYS.PRODUCTS];
      }
      return [];
    } catch {
      return memoryCache[STORAGE_KEYS.PRODUCTS] || [];
    }
  },

  cacheProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      memoryCache[STORAGE_KEYS.PRODUCTS] = products;
    } catch (e) {
      console.warn('Failed to cache products locally', e);
    }
  },

  getProducts(): Product[] {
    return this.getCachedProducts();
  },

  saveProducts(products: Product[]): void {
    this.cacheProducts(products);
  },

  // Legacy wrappers forwarding directly to Firestore Single Source of Truth
  async addProduct(product: Omit<Product, 'id'>): Promise<Product> {
    return firebaseService.addProduct(product);
  },

  async updateProduct(updated: Product): Promise<void> {
    return firebaseService.updateProduct(updated);
  },

  async deleteProduct(id: string): Promise<void> {
    return firebaseService.deleteProduct(id);
  },

  // CART (Device-specific shopping session - NEVER shared globally or via Firestore)
  getCart(): CartItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CART);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  saveCart(cart: CartItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart locally', e);
    }
  },

  clearCart(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.CART);
    } catch {
      // ignore
    }
  },

  // WISHLIST (Device-specific shopping session - NEVER shared globally or via Firestore)
  getWishlist(): string[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.WISHLIST);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  },

  toggleWishlist(productId: string): string[] {
    const list = this.getWishlist();
    const exists = list.includes(productId);
    const updated = exists ? list.filter((id) => id !== productId) : [...list, productId];
    try {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to update wishlist', e);
    }
    return updated;
  },

  // CUSTOMER'S OWN ORDERS (Strictly isolated to this specific device/session)
  getMyOrders(): Order[] {
    try {
      // Clean up legacy multi-customer orders key to guarantee customer privacy
      localStorage.removeItem(STORAGE_KEYS.ORDERS);
      const stored = localStorage.getItem(STORAGE_KEYS.MY_ORDERS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  saveMyOrder(order: Order): void {
    try {
      const list = this.getMyOrders();
      const updated = [order, ...list.filter((o) => o.id !== order.id)];
      localStorage.setItem(STORAGE_KEYS.MY_ORDERS, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save my order locally', e);
    }
  },

  updateMyOrder(updatedOrder: Order): void {
    try {
      const list = this.getMyOrders();
      const index = list.findIndex((o) => o.id === updatedOrder.id);
      if (index !== -1) {
        list[index] = { ...list[index], ...updatedOrder };
      } else {
        list.unshift(updatedOrder);
      }
      localStorage.setItem(STORAGE_KEYS.MY_ORDERS, JSON.stringify(list));
    } catch (e) {
      console.warn('Failed to update my order locally', e);
    }
  },

  // ADMIN-ONLY CACHED ORDERS (Accessible in memory / sessionStorage ONLY when authenticated)
  getAdminCachedOrders(): Order[] {
    if (!this.isAdminAuthenticated()) {
      return [];
    }
    try {
      const session = sessionStorage.getItem('lastella_admin_orders_cache_v1');
      if (session) {
        const parsed = JSON.parse(session);
        if (Array.isArray(parsed)) return parsed;
      }
      return [];
    } catch {
      return [];
    }
  },

  cacheAdminOrders(orders: Order[]): void {
    if (!this.isAdminAuthenticated()) return;
    try {
      sessionStorage.setItem('lastella_admin_orders_cache_v1', JSON.stringify(orders));
    } catch (e) {
      console.warn('Failed to cache admin orders in session', e);
    }
  },

  getCachedOrders(): Order[] {
    if (this.isAdminAuthenticated()) {
      return this.getAdminCachedOrders();
    }
    return this.getMyOrders();
  },

  cacheOrders(orders: Order[]): void {
    if (this.isAdminAuthenticated()) {
      this.cacheAdminOrders(orders);
    }
  },

  getOrders(): Order[] {
    return this.getCachedOrders();
  },

  saveOrders(orders: Order[]): void {
    this.cacheOrders(orders);
  },

  createOrder(newOrderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>): Order {
    const randomSuffix = Math.random().toString(36).substring(2, 7).toUpperCase();
    const orderNum = `LST-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      ...newOrderData,
      id: `ord_${Date.now()}_${randomSuffix}`,
      orderNumber: orderNum,
      createdAt: new Date().toISOString(),
      status: 'Order Placed',
      paymentStatus: 'Pending Payment',
      paymentMethod: newOrderData.paymentMethod || 'bank_transfer',
      statusHistory: [
        {
          status: 'Order Placed',
          timestamp: new Date().toISOString(),
          note: 'Order submitted to LASTELLA Boutique Cloud - Bank Transfer Pending',
        },
      ],
    };
    return newOrder;
  },

  updateOrderStatus(_orderId: string, _status: OrderStatus, _note?: string): void {
    // Handled directly via firebaseService.updateOrderStatus
  },

  // NOTIFICATIONS
  getNotifications(): AppNotification[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      if (stored) return JSON.parse(stored);
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  },

  saveNotifications(notifs: AppNotification[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
    } catch (e) {
      console.error('Failed to save notifications', e);
    }
  },

  addNotification(notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>): AppNotification {
    const notifs = this.getNotifications();
    const item: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: 'Just now',
      read: false,
    };
    notifs.unshift(item);
    this.saveNotifications(notifs);
    return item;
  },

  markNotificationRead(id: string): void {
    const notifs = this.getNotifications().map((n) => (n.id === id ? { ...n, read: true } : n));
    this.saveNotifications(notifs);
  },

  markAllNotificationsRead(): void {
    const notifs = this.getNotifications().map((n) => ({ ...n, read: true }));
    this.saveNotifications(notifs);
  },

  // USER PROFILE
  getProfile(): UserProfile {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (stored) return JSON.parse(stored);
      const initialProfile: UserProfile = {
        id: `usr-${Date.now().toString(36)}`,
        name: '',
        phone: '',
        whatsapp: '',
        email: '',
        isGuest: true,
        addresses: [],
      };
      return initialProfile;
    } catch {
      return {
        id: 'usr-guest',
        name: '',
        phone: '',
        whatsapp: '',
        email: '',
        isGuest: true,
        addresses: [],
      };
    }
  },

  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile', e);
    }
  },

  // STORE SETTINGS (Offline performance cache)
  getCachedSettings(): StoreSettings {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (stored) return JSON.parse(stored);
      return INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  },

  cacheSettings(settings: StoreSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to cache settings locally', e);
    }
  },

  getSettings(): StoreSettings {
    return this.getCachedSettings();
  },

  saveSettings(settings: StoreSettings): void {
    this.cacheSettings(settings);
  },

  // BANNERS
  getBanners(): Banner[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.BANNERS);
      if (stored) return JSON.parse(stored);
      const banners = Array.isArray(INITIAL_BANNERS) ? INITIAL_BANNERS : Object.values(INITIAL_BANNERS).filter((b): b is Banner => typeof b === 'object' && b !== null && 'id' in b);
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
      return banners;
    } catch {
      return Array.isArray(INITIAL_BANNERS) ? INITIAL_BANNERS : [];
    }
  },

  saveBanners(banners: Banner[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
    } catch (e) {
      console.error('Failed to save banners', e);
    }
  },

  // REVIEWS
  getReviews(): Review[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.REVIEWS);
      if (stored) return JSON.parse(stored);
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(INITIAL_REVIEWS));
      return INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  },

  addReview(review: Omit<Review, 'id' | 'date'>): Review {
    const reviews = this.getReviews();
    const newRev: Review = {
      ...review,
      id: `rev-${Date.now()}`,
      date: 'Just now',
    };
    reviews.unshift(newRev);
    try {
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
    } catch (e) {
      console.error('Failed to save review', e);
    }
    return newRev;
  },

  // SEARCH HISTORY
  getRecentSearches(): string[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.RECENT_SEARCHES);
      return stored ? JSON.parse(stored) : ['Ring', 'Layered Necklace', 'Tennis Bracelet', 'Gold Set', 'Gift Box'];
    } catch {
      return ['Ring', 'Layered Necklace', 'Tennis Bracelet'];
    }
  },

  addRecentSearch(query: string): void {
    if (!query.trim()) return;
    const list = this.getRecentSearches().filter((s) => s.toLowerCase() !== query.trim().toLowerCase());
    list.unshift(query.trim());
    try {
      localStorage.setItem(STORAGE_KEYS.RECENT_SEARCHES, JSON.stringify(list.slice(0, 8)));
    } catch (e) {
      console.error('Failed to save recent search', e);
    }
  },

  clearRecentSearches(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.RECENT_SEARCHES);
    } catch (e) {
      console.error('Failed to clear recent searches', e);
    }
  },

  // DELIVERY PREFERENCE
  getDeliveryMethod(): DeliveryMethod | null {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.DELIVERY_METHOD);
      return stored === 'home' || stored === 'office' ? stored : null;
    } catch {
      return null;
    }
  },

  setDeliveryMethod(method: DeliveryMethod | null): void {
    try {
      if (method) {
        localStorage.setItem(STORAGE_KEYS.DELIVERY_METHOD, method);
      } else {
        localStorage.removeItem(STORAGE_KEYS.DELIVERY_METHOD);
      }
    } catch (e) {
      console.error('Failed to save delivery method', e);
    }
  },

  // ADMIN AUTHENTICATION
  isAdminAuthenticated(): boolean {
    // 1. Check in-memory cache
    if (memoryCache[STORAGE_KEYS.ADMIN_AUTH] === true) {
      return true;
    }

    try {
      // 2. Check localStorage
      const local = localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH);
      if (local === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      // 3. Check sessionStorage
      const session = sessionStorage.getItem('lastella_admin_session_v1');
      if (session === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      // 4. Check cookie fallback
      const cookieVal = safeGetCookie('lastella_admin_auth_v1');
      if (cookieVal === 'true') {
        memoryCache[STORAGE_KEYS.ADMIN_AUTH] = true;
        return true;
      }

      return false;
    } catch {
      return memoryCache[STORAGE_KEYS.ADMIN_AUTH] === true;
    }
  },

  setAdminAuthenticated(auth: boolean): void {
    memoryCache[STORAGE_KEYS.ADMIN_AUTH] = auth;

    try {
      if (auth) {
        localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
        sessionStorage.setItem('lastella_admin_session_v1', 'true');
        safeSetCookie('lastella_admin_auth_v1', 'true', 30);
      } else {
        localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
        sessionStorage.removeItem('lastella_admin_session_v1');
        safeRemoveCookie('lastella_admin_auth_v1');
      }
    } catch (e) {
      console.warn('[LASTELLA Storage] Storage access constrained, using memory session', e);
    }
  },

  verifyAdminPasscode(passcode: string): boolean {
    try {
      const cleanPass = passcode.trim();
      if (!cleanPass) return false;
      const settings = this.getSettings();
      const configuredCode = (settings.adminPasscode || '').trim();
      if (!configuredCode) {
        return false;
      }
      return cleanPass === configuredCode;
    } catch {
      return false;
    }
  },

  // LANGUAGE
  getLanguage(): Language {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language;
      if (stored === 'ar' || stored === 'en') {
        return stored;
      }
      // Default to Arabic
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, 'ar');
      return 'ar';
    } catch {
      return 'ar';
    }
  },

  saveLanguage(lang: Language): void {
    try {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    } catch (e) {
      console.error('Failed to save language', e);
    }
  },
};

