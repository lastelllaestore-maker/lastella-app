/**
 * LASTELLA Jewelry Translation Service
 * 
 * Provides natural, elegant Arabic translation specialized for luxury jewellery in the Sultanate of Oman.
 * Handles high-end brand transliterations (Cartier, Van Cleef & Arpels, Dior, Swarovski, Louis Vuitton, Bvlgari, Tiffany, Chanel),
 * gemstone terms, jewellery categories, cuts, and finishes.
 * 
 * Includes:
 * 1. Accurate linguistic vocabulary mapping for luxury fashion & fine jewellery in Oman.
 * 2. Fallback to public translation API (MyMemory) if available.
 * 3. Graceful failure protection: allows manual entry/override and never blocks product saving.
 */

// Luxury brand transliterations tailored for Arabian Gulf / Oman luxury boutiques
const BRAND_TRANSLITERATIONS: Record<string, string> = {
  'van cleef & arpels': 'فان كليف آند آربلز',
  'van cleef and arpels': 'فان كليف آند آربلز',
  'van cleef': 'فان كليف',
  'cartier': 'كارتييه',
  'dior': 'ديور',
  'swarovski': 'سواروفسكي',
  'louis vuitton': 'لويس فيتون',
  'lv': 'إل في (LV)',
  'bvlgari': 'بولغري',
  'bulgari': 'بولغري',
  'tiffany & co.': 'تيفاني آند كو',
  'tiffany & co': 'تيفاني آند كو',
  'tiffany': 'تيفاني',
  'chanel': 'شانيل',
  'gucci': 'غوتشي',
  'hermes': 'هيرميس',
  'hermès': 'هيرميس',
  'chopard': 'شوبارد',
  'messika': 'ميسيكا',
  'boucheron': 'بوشرون',
  'chaumet': 'شوميه',
  'piaget': 'بياجيه',
  'lastella': 'لاستيلا',
};

// Common jewellery vocabulary mapping for Omani & GCC luxury retail
const JEWELRY_VOCABULARY: Record<string, string> = {
  // Types
  'solitaire ring': 'خاتم سوليتير ملكي',
  'eternity ring': 'دبلة أبدية مرصعة',
  'stacking ring': 'خاتم مكدس ناعم',
  'engagement ring': 'خاتم خطوبة فاخر',
  'wedding band': 'دبلة زواج راقية',
  'ring': 'خاتم',
  'rings': 'خواتم',

  'tennis bracelet': 'سوار تنس ألماس',
  'charm bracelet': 'سوار تشارم جذاب',
  'chain bracelet': 'سوار جنزير أنيق',
  'cuff bracelet': 'سوار كف ملكي',
  'bangle bracelet': 'سوار بنجرة عصري',
  'bracelet': 'سوار',
  'bracelets': 'أساور',

  'bangles': 'بناجر',
  'bangle': 'بنجرة',

  'anklet': 'خلخال',
  'anklets': 'خلاخل',

  'tennis necklace': 'عقد تنس مرصع',
  'choker necklace': 'طوق تشوكر ساحر',
  'choker': 'طوق تشوكر',
  'pendant necklace': 'عقد بقلادة متدلية',
  'layered necklace': 'عقد طبقات ساحر',
  'chain necklace': 'سلسال جنزير',
  'necklace': 'عقد',
  'necklaces': 'عقود',
  'pendant': 'قلادة',
  'chain': 'سلسال',

  'drop earrings': 'أقراط متدلية راقية',
  'stud earrings': 'أقراط مسمار ناعمة',
  'hoop earrings': 'أقراط حلقية دائرية',
  'earrings': 'أقراط',
  'earring': 'قرط',

  'jewelry set': 'طقم مجوهرات فاخر',
  'jewellery set': 'طقم مجوهرات فاخر',
  'set': 'طقم فاخر',
  'combo': 'بكج وتنسيق متكامل',
  'gift box': 'علبة هدايا فاخرة',
  'brand box': 'علبة ماركة مخملية',
  'box': 'علبة فاخرة',

  // Gemstones & Materials
  'cubic zirconia': 'زركون سويسري براق',
  'zirconia': 'زركون لامع',
  'zircon': 'زركون',
  'diamond': 'ألماس',
  'diamonds': 'ألماس',
  'emerald': 'زمرد أخضر',
  'sapphire': 'ياقوت أزرق',
  'ruby': 'ياقوت أحمر',
  'pearl': 'لؤلؤ طبيعي',
  'freshwater pearl': 'لؤلؤ مياه عذبة',
  'baroque pearl': 'لؤلؤ باروك مميز',
  'mother of pearl': 'صدف أم اللؤلؤ',
  'onyx': 'عقيق أسود فاخر',
  'malachite': 'ملاكيت أخضر ملكي',
  'turquoise': 'فيروز طبيعي',
  'crystal': 'كريستال فاخر',
  'crystals': 'كريستالات',

  // Finishes & Qualities
  '18k gold plated': 'مطلي بالذهب عيار 18',
  '18k gold': 'ذهب عيار 18',
  '24k gold': 'ذهب عيار 24',
  'gold plated': 'مطلي بالذهب',
  'gold': 'ذهبي',
  'yellow gold': 'ذهب أصفر',
  'white gold': 'ذهب أبيض',
  'rose gold': 'ذهب وردي (روز غولد)',
  'silver': 'فضي نقي',
  'sterling silver': 'فضة إسترلينية 925',
  '925 silver': 'فضة 925',
  'stainless steel': 'ستيل مقاوم للماء',
  'titanium': 'تيتانيوم خفيف وفاخر',

  // Descriptors
  'luxury': 'فاخر',
  'royal': 'ملكي',
  'elegant': 'أنيق',
  'classic': 'كلاسيكي',
  'vintage': 'فينتاج راقي',
  'celestial': 'سماوي متلألئ',
  'sparkling': 'براق',
  'shimmering': 'لامع',
  'water resistant': 'مقاوم للماء',
  'tarnish free': 'مقاوم لتغير اللون',
  'waterproof': 'مقاوم للماء والعرق',
  'flower': 'وردة',
  'clover': 'ورقة البرسيم (كلوفر)',
  'four leaf clover': 'ورقة البرسيم الرباعية',
  'heart': 'قلب',
  'butterfly': 'فراشة رقيقة',
  'snake': 'أفعى ملكية',
  'love': 'الحب',
  'infinity': 'اللانهاية',
  'star': 'نجمة',
  'moon': 'هلال',
  'eye': 'عين الحماية',
  'evil eye': 'العين الزرقاء',
  'beaded': 'حبيبات ناعمة',
  'pavé': 'مرصع بحبات الزركون',
  'pave': 'مرصع بحبات الزركون',
};

/**
 * Translates an English jewelry product title to high-end natural Arabic.
 * Tries external translation service with timeout, and falls back to our curated
 * Omani jewellery lexicon and transliteration engine.
 */
export async function translateProductNameToArabic(englishName: string): Promise<string> {
  const cleanInput = englishName.trim();
  if (!cleanInput) return '';

  // 1. Try public translation API with strict 3-second timeout
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2800);

    const query = encodeURIComponent(cleanInput);
    const res = await fetch(`https://api.mymemory.translated.net/get?q=${query}&langpair=en|ar`, {
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (res.ok) {
      const data = await res.json();
      const translatedText = data?.responseData?.translatedText;
      if (
        translatedText &&
        typeof translatedText === 'string' &&
        /[\u0600-\u06FF]/.test(translatedText) &&
        !translatedText.toLowerCase().includes('query error') &&
        !translatedText.toLowerCase().includes('quota')
      ) {
        // Post-process to ensure luxury brand names remain pristine
        return polishArabicJewelryTitle(translatedText, cleanInput);
      }
    }
  } catch (err) {
    // API unavailable or timed out; smoothly fall back to our local lexicon
  }

  // 2. Intelligent Rule-Based Local Translation Engine
  return translateWithJewelryLexicon(cleanInput);
}

/**
 * Replaces or standardizes luxury brand transliterations in any translated text.
 */
function polishArabicJewelryTitle(arabicText: string, originalEnglish: string): string {
  let polished = arabicText.trim();

  // 1. Transliterate English luxury brand names that remained in Latin characters
  polished = polished
    .replace(/\bvan cleef\s*(?:&|and)?\s*arpels\b/gi, 'فان كليف آند آربلز')
    .replace(/\bvan cleef\b/gi, 'فان كليف')
    .replace(/\bcartier\b/gi, 'كارتييه')
    .replace(/\bdior\b/gi, 'ديور')
    .replace(/\bswarovski\b/gi, 'سواروفسكي')
    .replace(/\blouis vuitton\b/gi, 'لويس فيتون')
    .replace(/\blv\b/gi, 'إل في (LV)')
    .replace(/\bbvlgari\b|\bbulgari\b/gi, 'بولغري')
    .replace(/\btiffany\s*(?:&|and)?\s*(?:co\.?|company)?\b/gi, 'تيفاني آند كو')
    .replace(/\btiffany\b/gi, 'تيفاني')
    .replace(/\bchanel\b/gi, 'شانيل')
    .replace(/\bgucci\b/gi, 'غوتشي')
    .replace(/\bhermes\b|\bhermès\b/gi, 'هيرميس')
    .replace(/\bchopard\b/gi, 'شوبارد')
    .replace(/\bmessika\b/gi, 'ميسيكا')
    .replace(/\blastella\b/gi, 'لاستيلا');

  // 2. Standardize common Arabic variations into Omani/Gulf luxury boutique terminology
  polished = polished
    .replace(/\bكارتير\b/g, 'كارتييه')
    .replace(/\bسوارفسكي\b/g, 'سواروفسكي')
    .replace(/\bبولغاري\b/g, 'بولغري')
    .replace(/\bلويس فويتون\b/g, 'لويس فيتون');

  // 3. If the brand is LASTELLA and not already at the front
  const lowerOriginal = originalEnglish.toLowerCase();
  if (lowerOriginal.includes('lastella') && !polished.includes('لاستيلا')) {
    polished = `لاستيلا - ${polished}`;
  }

  // 4. Remove common machine-translation quirks, repeated whitespace and quotes
  polished = polished
    .replace(/\s+/g, ' ')
    .replace(/^["'«“\s]+|["'»”\s]+$/g, '')
    .trim();

  return polished;
}

/**
 * Curated translation engine that breaks down jewelry product titles and translates them
 * using terminology standard in the Muscat & Gulf jewellery retail industry.
 */
function translateWithJewelryLexicon(englishTitle: string): string {
  let remaining = englishTitle.trim();

  // 1. Extract and preserve brand prefix
  let brandPrefix = '';
  const lower = remaining.toLowerCase();

  for (const [brand, arBrand] of Object.entries(BRAND_TRANSLITERATIONS)) {
    const regex = new RegExp(`^${brand}\\s*[:-]?\\s*`, 'i');
    if (regex.test(remaining)) {
      brandPrefix = `${arBrand} `;
      remaining = remaining.replace(regex, '');
      break;
    }
  }

  // If LASTELLA is anywhere in title, note it
  const hasLastella = /\blastella\b/i.test(englishTitle);
  if (hasLastella && !brandPrefix) {
    brandPrefix = 'لاستيلا ';
    remaining = remaining.replace(/\blastella\b/gi, '').trim();
  }

  // 2. Detect category / main piece type
  let pieceType = '';
  const sortedVocab = Object.entries(JEWELRY_VOCABULARY).sort((a, b) => b[0].length - a[0].length);

  for (const [phrase, arPhrase] of sortedVocab) {
    const phraseRegex = new RegExp(`\\b${phrase}\\b`, 'i');
    if (phraseRegex.test(remaining)) {
      if (!pieceType) {
        pieceType = arPhrase;
      }
    }
  }

  // 3. Detect descriptors and finishes
  const detectedAttributes: string[] = [];
  for (const [phrase, arPhrase] of sortedVocab) {
    const phraseRegex = new RegExp(`\\b${phrase}\\b`, 'i');
    if (phraseRegex.test(remaining)) {
      if (arPhrase !== pieceType && !detectedAttributes.includes(arPhrase)) {
        detectedAttributes.push(arPhrase);
      }
    }
  }

  // If we matched piece type and attributes, construct an elegant Arabic title
  if (pieceType) {
    const mainTitle = [pieceType, ...detectedAttributes.slice(0, 3)].join(' ');
    const full = brandPrefix ? `${brandPrefix}- ${mainTitle}` : mainTitle;
    return full.replace(/\s+/g, ' ').trim();
  }

  // If the title is simple words, translate piece by piece
  const words = remaining.split(/\s+/);
  const translatedWords = words.map((w) => {
    const cleanWord = w.toLowerCase().replace(/[^a-z0-9]/g, '');
    return JEWELRY_VOCABULARY[cleanWord] || BRAND_TRANSLITERATIONS[cleanWord] || w;
  });

  const assembled = (brandPrefix ? `${brandPrefix}- ` : '') + translatedWords.join(' ');
  return assembled.replace(/\s+/g, ' ').trim();
}

/**
 * Common jewelry size dictionary for instant Arabic auto-translation.
 */
const SIZE_DICTIONARY: Record<string, string> = {
  'small': 'صغير',
  's': 'صغير',
  'medium': 'متوسط',
  'm': 'متوسط',
  'large': 'كبير',
  'l': 'كبير',
  'x-small': 'صغير جداً',
  'xsmall': 'صغير جداً',
  'xs': 'صغير جداً',
  'extra small': 'صغير جداً',
  'x-large': 'كبير جداً',
  'xlarge': 'كبير جداً',
  'xl': 'كبير جداً',
  'extra large': 'كبير جداً',
  'xxl': 'كبير جداً جداً',
  '2xl': 'كبير جداً جداً',
  'free size': 'مقاس قابل للتعديل',
  'freesize': 'مقاس قابل للتعديل',
  'one size': 'مقاس قابل للتعديل',
  'onesize': 'مقاس قابل للتعديل',
  'adjustable': 'مقاس قابل للتعديل',
  'standard': 'قياسي',
  'universal': 'موحد',
};

/**
 * Reusable utility that converts Western digits (0-9) to Eastern Arabic-Indic numerals (٠-٩)
 * and decimal points to Arabic decimal separators (٫).
 * Examples:
 * 0 → ٠, 1 → ١, 2 → ٢, 3 → ٣, 4 → ٤, 5 → ٥, 6 → ٦, 7 → ٧, 8 → ٨, 9 → ٩
 * 14 → ١٤, 15 → ١٥, 16 → ١٦, 17 → ١٧, 18 → ١٨, 19 → ١٩
 * 5.5 → ٥.٥ / ٥٫٥
 */
export function toArabicDigits(value: string): string {
  if (!value) return '';
  return value
    .replace(/[0-9]/g, (digit) => '٠١٢٣٤٥٦٧٨٩'[Number(digit)])
    .replace(/\./g, '٫');
}

/**
 * Translates English size input into natural Arabic.
 * - Converts numeric sizes (5, 6, 7, 14, 15, 16, 17, 18, 19, 5.5, etc.) to Arabic-Indic digits.
 * - Preserves existing text-size translations: Small → صغير, Medium → متوسط, Large → كبير, Free Size → مقاس قابل للتعديل.
 */
export function translateSizeToArabic(sizeEn: string): string {
  const trimmed = (sizeEn || '').trim();
  if (!trimmed) return '';

  // 1. Text sizes dictionary lookup (Small, Medium, Large, Free Size, etc.)
  const lower = trimmed.toLowerCase();
  if (SIZE_DICTIONARY[lower]) {
    return SIZE_DICTIONARY[lower];
  }

  // 2. Pure numeric or numeric ranges/decimals (e.g. "5", "6", "14", "16.5", "5.5", "14-16", "#7")
  if (/^#?\s*\d+(\.\d+)?(\s*[-/]\s*\d+(\.\d+)?)?\s*$/.test(trimmed)) {
    return toArabicDigits(trimmed.replace(/^#\s*/, ''));
  }

  // 3. Size with unit e.g. "16 cm" -> "١٦ سم", "7 inch" -> "٧ إنش"
  const unitMatch = trimmed.match(/^(\d+(?:\.\d+)?)\s*(cm|mm|inch|in)?$/i);
  if (unitMatch) {
    const num = toArabicDigits(unitMatch[1]);
    const unit = (unitMatch[2] || '').toLowerCase();
    if (unit === 'cm') return `${num} سم`;
    if (unit === 'mm') return `${num} ملم`;
    if (unit === 'inch' || unit === 'in') return `${num} إنش`;
    return num;
  }

  // 4. Any size with numbers (e.g. "No. 5" or "Size 14")
  if (/\d/.test(trimmed)) {
    return toArabicDigits(trimmed);
  }

  return trimmed;
}

/**
 * Common jewelry colors dictionary for instant Arabic auto-translation.
 */
const COLOR_DICTIONARY: Record<string, string> = {
  'gold': 'ذهبي',
  'royal gold': 'ذهبي ملكي',
  'yellow gold': 'ذهب أصفر',
  'silver': 'فضي',
  'radiant silver': 'فضي لامع',
  'rose gold': 'ذهبي وردي',
  'rosegold': 'ذهبي وردي',
  'pink gold': 'ذهب وردي',
  'white gold': 'ذهب أبيض',
  'black': 'أسود',
  'white': 'أبيض',
  'pink': 'وردي',
  'baby pink': 'وردي فاتح',
  'green': 'أخضر',
  'emerald green': 'أخضر زمردي',
  'emerald': 'زمردي',
  'blue': 'أزرق',
  'royal blue': 'أزرق ملكي',
  'navy': 'كحلي',
  'navy blue': 'كحلي',
  'sky blue': 'سماوي',
  'light blue': 'أزرق فاتح',
  'red': 'أحمر',
  'ruby red': 'ياقوتي أحمر',
  'ruby': 'ياقوتي',
  'burgundy': 'عنابي',
  'maroon': 'عنابي',
  'purple': 'بنفسجي',
  'violet': 'بنفسجي',
  'lavender': 'لافندر',
  'brown': 'بني',
  'yellow': 'أصفر',
  'grey': 'رمادي',
  'gray': 'رمادي',
  'beige': 'بيج',
  'champagne': 'شامبين',
  'sapphire': 'ياقوتي أزرق',
  'bronze': 'برونزي',
  'copper': 'نحاسي',
  'pearl': 'لؤلؤي',
  'pearl white': 'أبيض لؤلؤي',
  'mother of pearl': 'صدف',
  'turquoise': 'فيروزي',
  'coral': 'مرجاني',
  'amber': 'كهرماني',
  'transparent': 'شفاف',
  'clear': 'شفاف',
  'multicolor': 'متعدد الألوان',
  'multi-color': 'متعدد الألوان',
  'multi color': 'متعدد الألوان',
};

/**
 * Translates English color input into natural Arabic instantly.
 */
export function translateColorToArabic(colorEn: string): string {
  const trimmed = (colorEn || '').trim();
  if (!trimmed) return '';

  const lower = trimmed.toLowerCase();
  if (COLOR_DICTIONARY[lower]) {
    return COLOR_DICTIONARY[lower];
  }

  // Check composite (e.g. "Gold / Silver" or "Gold + Silver")
  if (lower.includes('/') || lower.includes('+') || lower.includes('&')) {
    const parts = lower.split(/[/+&]/).map((p) => p.trim());
    const translatedParts = parts.map((p) => COLOR_DICTIONARY[p] || p);
    return translatedParts.join(' + ');
  }

  return trimmed;
}

