import { auth, isUserAdmin, ADMIN_EMAILS } from './firebaseService';
import { storageService } from './storageService';

/**
 * Cloudinary Integration for LASTELLA Jewelry Boutique
 *
 * Cloud Name: qfm7lfjj
 * Upload Preset: lastella_products (Unsigned)
 * Endpoint: https://api.cloudinary.com/v1_1/qfm7lfjj/image/upload
 *
 * Note: Unsigned mode requires NO API Secret.
 * All image uploads return public HTTPS secure_url saved directly into Firestore.
 */

export const CLOUDINARY_CONFIG = {
  cloudName: 'qfm7lfjj',
  uploadPreset: 'lastella_products',
  uploadUrl: 'https://api.cloudinary.com/v1_1/qfm7lfjj/image/upload',
} as const;

/**
 * Generates an appropriately sized, auto-format, auto-quality responsive image URL.
 * - For Cloudinary URLs: dynamically injects transformation parameters (e.g. w_500,c_fill,q_auto,f_auto).
 * - For Unsplash URLs: adjusts query parameters (w, q, auto=format).
 * - For local/data URLs: returns original unchanged.
 */
export function getOptimizedImageUrl(
  url: string | undefined,
  width: number = 480,
  quality: string = 'auto',
  crop: 'fit' | 'fill' | 'pad' | 'limit' = 'fit'
): string {
  if (!url || typeof url !== 'string') return '';

  // Cloudinary image URL transformation
  if (url.includes('res.cloudinary.com') && url.includes('/image/upload/')) {
    // Avoid double transformation
    if (url.includes('/image/upload/w_') || url.includes('/image/upload/c_')) {
      return url;
    }
    const transform = `w_${width},c_${crop},q_${quality},f_auto`;
    return url.replace('/image/upload/', `/image/upload/${transform}/`);
  }

  // Unsplash image URL transformation
  if (url.includes('images.unsplash.com')) {
    try {
      const parsed = new URL(url);
      parsed.searchParams.set('w', String(width));
      parsed.searchParams.set('auto', 'format');
      parsed.searchParams.set('q', quality === 'auto' ? '85' : quality);
      parsed.searchParams.set('fit', crop === 'fill' ? 'crop' : 'max');
      return parsed.toString();
    } catch {
      return url;
    }
  }

  return url;
}

export type UploadState = 'idle' | 'ready' | 'uploading' | 'success' | 'error';

/**
 * Validates file type for JPG, JPEG, PNG, and WebP
 */
export function validateImageFile(file: File | Blob): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No image file provided' };
  }

  const type = file.type?.toLowerCase() || '';
  const validMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

  // Check MIME type
  if (type && validMimeTypes.includes(type)) {
    return { valid: true };
  }

  // Check file extension if available (e.g., from Android camera file picker)
  if ('name' in file && typeof file.name === 'string') {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext && ['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
      return { valid: true };
    }
  }

  return {
    valid: false,
    error: 'Invalid format. Only JPG, JPEG, PNG, and WebP images are supported.',
  };
}

/**
 * Optimizes and resizes an image before upload:
 * - Max 1200px on longest side (preserves aspect ratio)
 * - Compression quality 80–85% (default 0.82)
 * - Outputs clean WebP or JPEG Blob
 */
export async function processAndCompressImage(
  file: File | Blob,
  maxDimension = 1200,
  quality = 0.82
): Promise<{ blob: Blob; fileName: string }> {
  return new Promise((resolve, reject) => {
    // Generate clean filename
    const originalName = ('name' in file && typeof file.name === 'string')
      ? file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      : `jewelry-${Date.now()}.jpg`;

    // Server-side / Node fallback
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      resolve({ blob: file, fileName: originalName });
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Failed to load image for optimization'));
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Resize down to maxDimension preserving aspect ratio
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({ blob: file, fileName: originalName });
          return;
        }

        // Draw image smoothly
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Prefer webp, fallback to jpeg
        let outputType = 'image/webp';
        let extension = 'webp';

        canvas.toBlob(
          (blob) => {
            if (blob && blob.size > 0) {
              const baseName = originalName.substring(0, originalName.lastIndexOf('.')) || originalName;
              resolve({ blob, fileName: `${baseName}.${extension}` });
            } else {
              // Fallback to JPEG if WebP canvas is unsupported
              canvas.toBlob(
                (jpegBlob) => {
                  resolve({
                    blob: jpegBlob || file,
                    fileName: `${originalName.substring(0, originalName.lastIndexOf('.')) || originalName}.jpg`,
                  });
                },
                'image/jpeg',
                quality
              );
            }
          },
          outputType,
          quality
        );
      };

      img.src = (e.target?.result as string) || '';
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Uploads an optimized product image to Cloudinary using Unsigned preset.
 * Tracks upload progress via XMLHttpRequest.
 * Returns the HTTPS `secure_url`.
 */
export async function uploadProductImageToCloudinary(
  file: File | Blob,
  onProgress?: (percent: number) => void
): Promise<string> {
  // 1. Authorization check: Only verified admin (lastelllaestore@gmail.com)
  const currentUser = auth.currentUser;
  const isFirebaseAdmin = isUserAdmin(currentUser);
  const isStorageAdmin = storageService.isAdminAuthenticated();

  if (!isFirebaseAdmin && !isStorageAdmin) {
    throw new Error(
      'Authentication required: You must be signed in as the authorized store administrator (lastelllaestore@gmail.com) to upload images.'
    );
  }

  if (currentUser && !isFirebaseAdmin && !isStorageAdmin) {
    throw new Error(
      `Access Denied: Account "${currentUser.email || 'unauthorized'}" is not authorized. Required: ${ADMIN_EMAILS.join(', ')}`
    );
  }

  // 2. Validate format (JPG, JPEG, PNG, WebP)
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error || 'Invalid image file format');
  }

  const adminEmail = currentUser?.email || 'lastelllaestore@gmail.com';
  console.log('[Cloudinary Upload] Initiating upload:');
  console.log(`  - Raw size: ${file.size} bytes (${(file.size / 1024).toFixed(1)} KB)`);
  console.log(`  - Admin user: ${adminEmail}`);
  console.log(`  - Cloud Name: ${CLOUDINARY_CONFIG.cloudName}`);
  console.log(`  - Preset: ${CLOUDINARY_CONFIG.uploadPreset}`);

  onProgress?.(10);

  // 3. Optimize image before upload (max 1200px, 80-85% quality)
  const { blob, fileName } = await processAndCompressImage(file, 1200, 0.82);
  console.log(`  - Optimized size: ${blob.size} bytes (${(blob.size / 1024).toFixed(1)} KB)`);
  onProgress?.(25);

  // 4. Build FormData for unsigned Cloudinary upload
  const formData = new FormData();
  formData.append('file', blob, fileName);
  formData.append('upload_preset', CLOUDINARY_CONFIG.uploadPreset);

  // 5. Upload with real-time XMLHttpRequest progress
  return new Promise<string>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', CLOUDINARY_CONFIG.uploadUrl, true);
    xhr.timeout = 35000; // 35s timeout

    // Progress handler
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total > 0) {
        // Map upload progress from 25% to 95%
        const uploadPct = Math.round((event.loaded / event.total) * 70);
        const totalPct = Math.min(95, 25 + uploadPct);
        onProgress?.(totalPct);
        console.log(`[Cloudinary Progress] ${event.loaded}/${event.total} bytes (${totalPct}%)`);
      }
    };

    // Complete / response handler
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const response = JSON.parse(xhr.responseText);
          const secureUrl = response.secure_url;

          if (!secureUrl || typeof secureUrl !== 'string' || !secureUrl.startsWith('https://')) {
            throw new Error('Cloudinary response missing valid HTTPS secure_url');
          }

          console.log('[Cloudinary Success] Image uploaded successfully:', secureUrl);
          onProgress?.(100);
          resolve(secureUrl);
        } catch (err: any) {
          console.error('[Cloudinary Error] Failed to parse response:', xhr.responseText);
          reject(new Error(`Failed to parse Cloudinary response: ${err.message}`));
        }
      } else {
        let errorMsg = `Cloudinary upload failed with status ${xhr.status}`;
        try {
          const errorResponse = JSON.parse(xhr.responseText);
          if (errorResponse.error?.message) {
            errorMsg = `Cloudinary error: ${errorResponse.error.message}`;
          }
        } catch {
          // fallback to status
        }
        console.error('[Cloudinary Error]', errorMsg, xhr.responseText);
        reject(new Error(errorMsg));
      }
    };

    // Error handler
    xhr.onerror = () => {
      console.error('[Cloudinary Network Error] Upload failed due to network error');
      reject(new Error('Network error occurred during Cloudinary upload. Please check your connection.'));
    };

    // Timeout handler
    xhr.ontimeout = () => {
      console.error('[Cloudinary Timeout] Upload timed out after 35 seconds');
      reject(new Error('Cloudinary image upload timed out after 35 seconds.'));
    };

    // Send the request
    xhr.send(formData);
  });
}
