import { Order } from '../types';

/**
 * Cloudflare Worker Order Email Notification Service
 * Worker: lastella-orders-mail-v2
 * Sender: orders@lastella-jewelery.com
 * Recipient: orderslastella@gmail.com
 *
 * Security:
 * - Only sends { orderId, trackingToken }
 * - No client-provided customer details, prices or recipient emails are sent
 * - No server secrets exposed in client
 * - De-duplicated in-memory to prevent duplicate requests from React re-renders
 * - Non-blocking: Errors are logged, never preventing checkout or order placement
 */

// Exact Production Cloudflare Worker URL from Cloudflare dashboard:
export const PRODUCTION_WORKER_URL = 'https://lastella-orders-mail-v2.lastelllaestore.workers.dev/';

// Configurable via VITE_ORDER_EMAIL_WORKER_URL in development/preview, defaults to production Worker URL:
export const ORDER_EMAIL_WORKER_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_ORDER_EMAIL_WORKER_URL) ||
  PRODUCTION_WORKER_URL;

// In-memory set to prevent duplicate triggers for the same order during React lifecycle
const triggeredOrderIds = new Set<string>();

export interface OrderNotificationResult {
  dispatched: boolean;
  status?: number;
  message?: string;
  error?: string;
}

/**
 * Triggers the Cloudflare Worker email notification for a newly placed order.
 *
 * NOTE: Browser-triggered notifications are best-effort. If a customer immediately
 * closes their browser tab or device before the fetch completes, the background request
 * may be interrupted. For 100% mission-critical delivery, a Firestore database trigger
 * or server event is recommended in addition to this client trigger.
 */
export async function triggerOrderEmailNotification(
  order: Order
): Promise<OrderNotificationResult> {
  if (!order || !order.id) {
    return { dispatched: false, error: 'Missing order ID' };
  }

  // Prevent duplicate execution for the same order in the current session
  if (triggeredOrderIds.has(order.id)) {
    console.debug(`[OrderNotification] Order ${order.id} already triggered in this session. Skipping.`);
    return { dispatched: false, message: 'Duplicate trigger suppressed' };
  }

  // Mark as triggered immediately
  triggeredOrderIds.add(order.id);

  const payload = {
    orderId: order.id,
    trackingToken: order.trackingToken || '',
  };

  try {
    console.log(`[OrderNotification] Dispatching notification for order ${order.orderNumber} (${order.id})...`);

    // Use AbortController with 10-second timeout so requests do not hang
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(ORDER_EMAIL_WORKER_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // Interpret HTTP status codes correctly:
    // 200 OK: Email delivered or duplicate idempotently acknowledged
    // 202 Accepted: Email queued for delivery
    if (response.status === 200 || response.status === 202) {
      const data = await response.json().catch(() => ({}));
      console.log(`[OrderNotification] Email notification confirmed for order ${order.orderNumber}:`, data);
      return {
        dispatched: true,
        status: response.status,
        message: data.message || 'Notification accepted by Worker',
      };
    }

    // 4xx or 5xx response
    const errorText = await response.text().catch(() => 'No response body');
    console.warn(`[OrderNotification] Worker returned status ${response.status} for order ${order.orderNumber}: ${errorText}`);
    return {
      dispatched: false,
      status: response.status,
      error: `Worker returned ${response.status}: ${errorText}`,
    };
  } catch (err: any) {
    const isAbort = err?.name === 'AbortError';
    const message = isAbort ? 'Request timed out after 10s' : err?.message || 'Network error';
    console.warn(`[OrderNotification] Failed to reach email Worker for order ${order.orderNumber}: ${message}`);
    return {
      dispatched: false,
      error: message,
    };
  }
}
