import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  writeBatch,
  getDocFromServer,
} from 'firebase/firestore';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { Product, Order, StoreSettings, OrderStatus } from '../types';
import { INITIAL_PRODUCTS, INITIAL_SETTINGS } from '../data/initialData';
import { uploadProductImageToCloudinary, processAndCompressImage } from './cloudinaryService';

// Authorized Administrator Emails for LASTELLA Store (matches Firebase Auth)
export const ADMIN_EMAILS = ['lastelllaestore@gmail.com'];

// Helper to check if a Firebase user is an authorized administrator
export function isUserAdmin(user: User | null): boolean {
  if (!user || !user.email) return false;
  return ADMIN_EMAILS.includes(user.email.toLowerCase());
}

/**
 * Recursively sanitizes data before writing to Cloud Firestore.
 * Removes all properties with `undefined` values because Firestore strictly
 * rejects documents containing `undefined` with:
 * "FirebaseError: Function setDoc() called with invalid data. Unsupported field value: undefined"
 */
export function cleanForFirestore<T>(data: T): T {
  if (data === undefined) {
    return null as any;
  }
  if (data === null || typeof data !== 'object') {
    return data;
  }
  if (data instanceof Date) {
    return data.toISOString() as any;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => cleanForFirestore(item)) as any;
  }
  const cleaned: Record<string, any> = {};
  for (const [key, val] of Object.entries(data)) {
    if (val !== undefined) {
      cleaned[key] = cleanForFirestore(val);
    }
  }
  return cleaned as T;
}

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Cloud Services (Firestore & Auth only - Firebase Storage removed)
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Authentication Service for Admin verification
export const authService = {
  getAuthInstance() {
    return auth;
  },
  getCurrentUser(): User | null {
    return auth.currentUser;
  },
  isCurrentAdmin(): boolean {
    return isUserAdmin(auth.currentUser);
  },
  async signInAdminWithCredentials(
    email: string,
    passcodeOrPassword: string
  ): Promise<{ user: User; isAdmin: boolean }> {
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!ADMIN_EMAILS.includes(cleanEmail)) {
      throw new Error(
        `Access Denied: Account "${cleanEmail}" is not authorized. Authorized admin: ${ADMIN_EMAILS[0]}`
      );
    }
    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        cleanEmail,
        passcodeOrPassword
      );
      const user = userCredential.user;
      const admin = isUserAdmin(user);
      console.log('[LASTELLA Auth] Signed in as:', user.email, 'Admin verified:', admin);
      return { user, isAdmin: admin };
    } catch (err: any) {
      if (err?.code === 'auth/user-not-found') {
        // First-time setup: If admin user account does not exist in Firebase Auth yet, provision it
        try {
          const createdCredential = await createUserWithEmailAndPassword(
            auth,
            cleanEmail,
            passcodeOrPassword
          );
          const user = createdCredential.user;
          const admin = isUserAdmin(user);
          return { user, isAdmin: admin };
        } catch {
          throw err;
        }
      }
      throw err;
    }
  },
  async changeAdminPassword(
    currentPassword: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> {
    const currentUser = auth.currentUser;
    if (!currentUser || !currentUser.email) {
      throw new Error('You must be signed in as administrator to change credentials.');
    }
    if (!isUserAdmin(currentUser)) {
      throw new Error('Unauthorized: only store administrator can change credentials.');
    }
    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password/passcode must be at least 6 characters long.');
    }

    try {
      // 1. Re-authenticate user with current password
      const credential = EmailAuthProvider.credential(currentUser.email, currentPassword);
      await reauthenticateWithCredential(currentUser, credential);

      // 2. Update password in Firebase Authentication
      await updatePassword(currentUser, newPassword);
      console.log('[LASTELLA Auth] Admin password successfully updated in Firebase Auth!');
      return { success: true };
    } catch (err: any) {
      console.error('[LASTELLA Auth] Failed to update admin password:', err);
      let message = err?.message || 'Failed to update password';
      if (err?.code === 'auth/wrong-password' || err?.code === 'auth/invalid-credential') {
        message = 'Current password/passcode is incorrect.';
      } else if (err?.code === 'auth/weak-password') {
        message = 'Password is too weak. Must be at least 6 characters.';
      } else if (err?.code === 'auth/requires-recent-login') {
        message = 'Please log out and log back in before changing your credentials.';
      }
      return { success: false, error: message };
    }
  },
  async syncAdminFirebaseAuth(passcode: string): Promise<User | null> {
    try {
      const result = await this.signInAdminWithCredentials(ADMIN_EMAILS[0], passcode);
      return result.user;
    } catch {
      return auth.currentUser;
    }
  },
  async signOutAdmin(): Promise<void> {
    await signOut(auth);
    console.log('[LASTELLA Auth] Admin signed out from Firebase Auth');
  },
  subscribeAuth(callback: (user: User | null, isAdmin: boolean) => void) {
    return onAuthStateChanged(auth, (user) => {
      callback(user, isUserAdmin(user));
    });
  },
};


// Error Handling Infrastructure conforming to Skill requirements
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function isQuotaExceededError(error: unknown): boolean {
  if (!error) return false;
  const msg = (error instanceof Error ? error.message : String(error)).toLowerCase();
  return (
    msg.includes('quota exceeded') ||
    msg.includes('resource-exhausted') ||
    msg.includes('quota_exceeded') ||
    msg.includes('free daily read units')
  );
}

type QuotaListener = (exceeded: boolean, details?: string) => void;
const quotaListeners = new Set<QuotaListener>();

export function subscribeQuotaStatus(handler: QuotaListener): () => void {
  quotaListeners.add(handler);
  return () => quotaListeners.delete(handler);
}

let quotaExceededState = false;

export function getIsQuotaExceeded(): boolean {
  if (quotaExceededState) return true;
  if (typeof sessionStorage !== 'undefined') {
    return sessionStorage.getItem('lastella_firestore_quota_exceeded') === 'true';
  }
  return false;
}

export function notifyQuotaExceeded(details?: string): void {
  quotaExceededState = true;
  if (typeof sessionStorage !== 'undefined') {
    try {
      sessionStorage.setItem('lastella_firestore_quota_exceeded', 'true');
    } catch {
      // ignore
    }
  }
  quotaListeners.forEach((listener) => {
    try {
      listener(true, details);
    } catch {
      // ignore
    }
  });
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMessage = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: errMessage,
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
    },
    operationType,
    path,
  };
  if (isQuotaExceededError(error)) {
    console.warn('[LASTELLA Firestore Notice - Quota Exceeded]:', JSON.stringify(errInfo));
    notifyQuotaExceeded(errMessage);
  } else {
    console.error('[LASTELLA Firestore Error]:', JSON.stringify(errInfo));
  }
  return errInfo;
}

// Collections references
const PRODUCTS_COLLECTION = 'products';
const ORDERS_COLLECTION = 'orders';
const SETTINGS_COLLECTION = 'settings';
const BOUTIQUE_SETTINGS_DOC = 'boutique';

// Helper to parse Firestore REST API response fields into standard JSON objects
function parseFirestoreValue(v: any): any {
  if (!v || typeof v !== 'object') return v;
  if ('stringValue' in v) return v.stringValue;
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('integerValue' in v) return Number(v.integerValue);
  if ('booleanValue' in v) return Boolean(v.booleanValue);
  if ('nullValue' in v) return null;
  if ('arrayValue' in v) {
    return (v.arrayValue.values || []).map(parseFirestoreValue);
  }
  if ('mapValue' in v) {
    const res: Record<string, any> = {};
    const fields = v.mapValue.fields || {};
    for (const key of Object.keys(fields)) {
      res[key] = parseFirestoreValue(fields[key]);
    }
    return res;
  }
  return v;
}

function parseFirestoreDoc(docObj: any): any {
  if (!docObj || !docObj.fields) return null;
  const id = docObj.name ? docObj.name.split('/').pop() : '';
  const parsed: Record<string, any> = { id };
  for (const key of Object.keys(docObj.fields)) {
    parsed[key] = parseFirestoreValue(docObj.fields[key]);
  }
  return parsed;
}

// Resilient fallback query using standard Firestore REST API
async function queryCollectionRest(collectionId: string): Promise<any[]> {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents:runQuery?key=${firebaseConfig.apiKey}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId }],
        },
      }),
    });
    if (!response.ok) {
      throw new Error(`REST query for ${collectionId} returned HTTP ${response.status}`);
    }
    const results = await response.json();
    if (!Array.isArray(results)) return [];
    return results
      .filter((item: any) => item && item.document)
      .map((item: any) => parseFirestoreDoc(item.document))
      .filter(Boolean);
  } catch (err) {
    console.warn(`[FIRESTORE] REST query fallback for ${collectionId} failed:`, err);
    return [];
  }
}

async function getDocRest(collectionId: string, docId: string): Promise<any | null> {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents/${collectionId}/${docId}?key=${firebaseConfig.apiKey}`;
    const response = await fetch(url);
    if (!response.ok) return null;
    const docObj = await response.json();
    return parseFirestoreDoc(docObj);
  } catch (err) {
    console.warn(`[FIRESTORE] REST getDoc fallback for ${collectionId}/${docId} failed:`, err);
    return null;
  }
}

// Check connectivity on startup
async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('[FIRESTORE] Connected to Cloud Firestore successfully.');
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('[FIRESTORE] Client offline, will utilize offline and local cache.');
    } else if (isQuotaExceededError(error)) {
      console.warn('[FIRESTORE] Free tier daily quota reached. Will utilize local cache.');
      notifyQuotaExceeded(error instanceof Error ? error.message : String(error));
    }
  }
}
if (typeof window !== 'undefined') {
  testFirestoreConnection();
}

export const firebaseService = {
  // ONE-TIME SAFE MIGRATION
  // Genuinely empty database ONLY. Never overwrites existing Firestore database.
  // Stores a persistent Firestore migration marker so it NEVER runs again once completed.
  async runInitialMigration(): Promise<void> {
    const MIGRATION_DOC_ID = 'migration';
    const LOCAL_MIGRATION_FLAG_KEY = 'lastella_firestore_migration_done_v1';

    try {
      // 1. If this device has already confirmed migration, skip immediately
      if (typeof window !== 'undefined' && localStorage.getItem(LOCAL_MIGRATION_FLAG_KEY) === 'true') {
        return;
      }

      // 2. Check if Firestore migration marker document exists in settings collection
      const migrationRef = doc(db, SETTINGS_COLLECTION, MIGRATION_DOC_ID);
      let migrationExists = false;
      try {
        const migrationSnap = await getDoc(migrationRef);
        migrationExists = migrationSnap.exists();
      } catch (err) {
        if (isQuotaExceededError(err)) {
          console.warn('[FIRESTORE] Migration check skipped due to daily quota limit.');
          notifyQuotaExceeded();
          return;
        }
        const restDoc = await getDocRest(SETTINGS_COLLECTION, MIGRATION_DOC_ID);
        migrationExists = !!restDoc;
      }

      if (migrationExists) {
        if (typeof window !== 'undefined') {
          localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
        }
        return;
      }

      // 3. Check if Firestore products collection already contains ANY documents
      const existingProds = await this.getProducts();
      if (existingProds.length > 0) {
        // Products already exist in Cloud Firestore! Mark migration completed so it NEVER seeds defaults
        console.log(`[FIRESTORE] [PRODUCT] Existing catalog detected (${existingProds.length} items). Seeding permanently disabled.`);
        try {
          await setDoc(migrationRef, {
            completed: true,
            migratedAt: new Date().toISOString(),
            existingProductCount: existingProds.length,
            note: 'Existing Firestore database detected; initial seed permanently disabled.',
          });
        } catch {
          // ignore
        }
        if (typeof window !== 'undefined') {
          localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
        }
        return;
      }

      // 4. Genuinely blank Firestore database: seed initial catalog once
      console.log('[FIRESTORE] Genuinely empty Firestore detected. Seeding initial catalog once...');
      const batch = writeBatch(db);

      for (const product of INITIAL_PRODUCTS) {
        const productRef = doc(db, PRODUCTS_COLLECTION, product.id);
        batch.set(productRef, cleanForFirestore({
          ...product,
          createdAt: product.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }));
      }

      const settingsRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      batch.set(settingsRef, cleanForFirestore({
        ...INITIAL_SETTINGS,
        updatedAt: new Date().toISOString(),
      }), { merge: true });

      batch.set(migrationRef, cleanForFirestore({
        completed: true,
        migratedAt: new Date().toISOString(),
        seededProductCount: INITIAL_PRODUCTS.length,
        note: 'Initial catalog seeded into empty Firestore database.',
      }));

      await batch.commit();
      if (typeof window !== 'undefined') {
        localStorage.setItem(LOCAL_MIGRATION_FLAG_KEY, 'true');
      }
      console.log(`[FIRESTORE] [PRODUCT] Successfully initialized Firestore database with ${INITIAL_PRODUCTS.length} products! ✨`);
    } catch (e) {
      if (isQuotaExceededError(e)) {
        console.warn('[FIRESTORE] Migration check note: daily quota reached.');
        notifyQuotaExceeded();
      } else {
        console.warn('[FIRESTORE] Migration check note:', e);
      }
    }
  },

  // REAL-TIME SUBSCRIBERS
  subscribeProducts(callback: (products: Product[]) => void): () => void {
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [PRODUCT] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [PRODUCT] Attaching real-time onSnapshot listener for products');
    const q = query(collection(db, PRODUCTS_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const prods: Product[] = [];
        snapshot.forEach((d) => {
          prods.push({ id: d.id, ...(d.data() as Omit<Product, 'id'>) });
        });
        console.log(`[FIRESTORE] [PRODUCT] onSnapshot received ${prods.length} products`);
        callback(prods);
      },
      async (error) => {
        handleFirestoreError(error, OperationType.LIST, PRODUCTS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [PRODUCT] Free tier daily quota reached. Live sync paused, relying on cached data.');
          notifyQuotaExceeded();
          return;
        }
        // Fallback: If onSnapshot encounters connection or other issues, fetch current catalog via REST
        console.warn('[FIRESTORE] [PRODUCT] onSnapshot error, falling back to REST query');
        const fallbackProds = await queryCollectionRest(PRODUCTS_COLLECTION);
        if (fallbackProds.length > 0) {
          callback(fallbackProds as Product[]);
        }
      }
    );
  },

  subscribeOrders(callback: (orders: Order[]) => void): () => void {
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [ORDER] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [ORDER] Attaching real-time onSnapshot listener for orders');
    const q = query(collection(db, ORDERS_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const orders: Order[] = [];
        snapshot.forEach((d) => {
          orders.push({ id: d.id, ...(d.data() as Omit<Order, 'id'>) });
        });
        orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        console.log(`[FIRESTORE] [ORDER] onSnapshot received ${orders.length} orders`);
        callback(orders);
      },
      async (error) => {
        handleFirestoreError(error, OperationType.LIST, ORDERS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [ORDER] Free tier daily quota reached. Live sync paused, relying on cached data.');
          notifyQuotaExceeded();
          return;
        }
        const fallbackOrders = await queryCollectionRest(ORDERS_COLLECTION);
        if (fallbackOrders.length > 0) {
          fallbackOrders.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          callback(fallbackOrders as Order[]);
        }
      }
    );
  },

  /**
   * Real-time listener for a single specific order by canonical document ID.
   * Conforms to Firestore security rules: Allows customer to live-track only their own
   * order without permission errors, quota exhaustion, or exposing any other customer's order.
   */
  subscribeSingleOrder(orderId: string, callback: (order: Order | null) => void): () => void {
    if (!orderId || getIsQuotaExceeded()) {
      return () => {};
    }
    console.log(`[FIRESTORE] [ORDER-TRACKING] Attaching real-time onSnapshot listener for order: ${orderId}`);
    const orderDocRef = doc(db, ORDERS_COLLECTION, orderId);
    return onSnapshot(
      orderDocRef,
      (docSnapshot) => {
        if (docSnapshot.exists()) {
          const data = docSnapshot.data() as Omit<Order, 'id'>;
          callback({ id: docSnapshot.id, ...data });
        } else {
          callback(null);
        }
      },
      (error) => {
        console.warn(`[FIRESTORE] [ORDER-TRACKING] onSnapshot error on order ${orderId}:`, error);
        handleFirestoreError(error, OperationType.GET, `${ORDERS_COLLECTION}/${orderId}`);
      }
    );
  },

  subscribeSettings(callback: (settings: StoreSettings) => void): () => void {
    if (getIsQuotaExceeded()) {
      console.warn('[FIRESTORE] [SETTINGS] Free tier daily quota reached. Live sync paused, using local cache.');
      return () => {};
    }
    console.log('[FIRESTORE] [SETTINGS] Attaching real-time onSnapshot listener for boutique settings');
    const ref = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
    return onSnapshot(
      ref,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as StoreSettings;
          console.log('[FIRESTORE] [SETTINGS] onSnapshot received boutique settings');
          callback(data);
        }
      },
      async (error) => {
        handleFirestoreError(error, OperationType.GET, SETTINGS_COLLECTION);
        if (isQuotaExceededError(error)) {
          console.warn('[FIRESTORE] [SETTINGS] Free tier daily quota reached. Relying on cached settings.');
          notifyQuotaExceeded();
          return;
        }
        const fallbackSettings = await getDocRest(SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
        if (fallbackSettings) {
          callback(fallbackSettings as StoreSettings);
        }
      }
    );
  },

  // PRODUCTS CLOUD CRUD
  async getProducts(): Promise<Product[]> {
    console.log('[FIRESTORE] [PRODUCT] Fetching products from Firestore...');
    try {
      const snapshot = await getDocs(collection(db, PRODUCTS_COLLECTION));
      const prods: Product[] = [];
      snapshot.forEach((d) => {
        prods.push({ id: d.id, ...(d.data() as Omit<Product, 'id'>) });
      });
      console.log(`[FIRESTORE] [PRODUCT] Retrieved ${prods.length} products via SDK`);
      return prods;
    } catch (e) {
      console.warn('[FIRESTORE] [PRODUCT] SDK query failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.LIST, PRODUCTS_COLLECTION);
      if (isQuotaExceededError(e)) {
        return [];
      }
      const restProds = await queryCollectionRest(PRODUCTS_COLLECTION);
      console.log(`[FIRESTORE] [PRODUCT] Retrieved ${restProds.length} products via REST fallback`);
      return restProds as Product[];
    }
  },

  async addProduct(product: Omit<Product, 'id'>): Promise<Product> {
    const id = `lst-${Date.now().toString(36)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const fullProduct: Product = {
      ...product,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    console.log(`[FIRESTORE] [PRODUCT] Creating new product with canonical ID: ${id}`);
    try {
      await setDoc(doc(db, PRODUCTS_COLLECTION, id), cleanForFirestore(fullProduct));
      console.log(`[FIRESTORE] [PRODUCT] Successfully saved product ${id} to Firestore!`);
      return fullProduct;
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to create product ${id}:`, e);
      handleFirestoreError(e, OperationType.CREATE, `${PRODUCTS_COLLECTION}/${id}`);
      throw e;
    }
  },

  async updateProduct(product: Product): Promise<void> {
    if (!product || !product.id) {
      throw new Error('Cannot update product without a valid canonical Firestore document ID.');
    }
    const updated = {
      ...product,
      updatedAt: new Date().toISOString(),
    };
    console.log(`[FIRESTORE] [PRODUCT] Updating existing product: ${product.id}`);
    try {
      await setDoc(doc(db, PRODUCTS_COLLECTION, product.id), cleanForFirestore(updated), { merge: true });
      console.log(`[FIRESTORE] [PRODUCT] Successfully updated product ${product.id} in Firestore!`);
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to update product ${product.id}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${PRODUCTS_COLLECTION}/${product.id}`);
      throw e;
    }
  },

  async deleteProduct(productId: string): Promise<void> {
    if (!productId) {
      throw new Error('Cannot delete product without a valid canonical Firestore document ID.');
    }
    console.log(`[FIRESTORE] [PRODUCT] Deleting product document: ${productId}`);
    try {
      await deleteDoc(doc(db, PRODUCTS_COLLECTION, productId));
      console.log(`[FIRESTORE] [PRODUCT] Successfully deleted product ${productId} from Firestore!`);
    } catch (e) {
      console.error(`[FIRESTORE] [PRODUCT] Failed to delete product ${productId}:`, e);
      handleFirestoreError(e, OperationType.DELETE, `${PRODUCTS_COLLECTION}/${productId}`);
      throw e;
    }
  },

  // ORDERS CLOUD CRUD
  async getOrders(): Promise<Order[]> {
    console.log('[FIRESTORE] [ORDER] Fetching orders from Firestore...');
    try {
      const snapshot = await getDocs(collection(db, ORDERS_COLLECTION));
      const orders: Order[] = [];
      snapshot.forEach((d) => {
        orders.push({ id: d.id, ...(d.data() as Omit<Order, 'id'>) });
      });
      orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      console.log(`[FIRESTORE] [ORDER] Retrieved ${orders.length} orders via SDK`);
      return orders;
    } catch (e) {
      console.warn('[FIRESTORE] [ORDER] SDK query failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.LIST, ORDERS_COLLECTION);
      if (isQuotaExceededError(e)) {
        return [];
      }
      const restOrders = await queryCollectionRest(ORDERS_COLLECTION);
      restOrders.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      console.log(`[FIRESTORE] [ORDER] Retrieved ${restOrders.length} orders via REST fallback`);
      return restOrders as Order[];
    }
  },

  async createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>): Promise<Order> {
    const randomSuffix = Math.random().toString(36).substring(2, 7).toUpperCase();
    const trackingToken = `tok_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    const orderNum = `LST-${Math.floor(10000 + Math.random() * 90000)}`;
    const orderId = `ord_${Date.now()}_${randomSuffix}`;
    const newOrder: Order = {
      ...orderData,
      id: orderId,
      orderNumber: orderNum,
      trackingToken,
      createdAt: new Date().toISOString(),
      status: 'Order Placed',
      paymentStatus: 'Pending Payment',
      paymentMethod: orderData.paymentMethod || 'bank_transfer',
      statusHistory: [
        {
          status: 'Order Placed',
          timestamp: new Date().toISOString(),
          note: 'Order submitted via Bank Transfer - Pending Payment Verification',
        },
      ],
    };

    console.log(`[FIRESTORE] [ORDER] Writing new unique order ${orderId} (#${orderNum}) to Firestore...`);
    try {
      const sanitizedOrder = cleanForFirestore(newOrder);
      await setDoc(doc(db, ORDERS_COLLECTION, orderId), sanitizedOrder);
      console.log(`[FIRESTORE] [ORDER] Successfully wrote order ${orderId} to Firestore!`);
      return newOrder;
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to write order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.CREATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  async updateOrderStatus(orderId: string, status: OrderStatus, note?: string): Promise<void> {
    console.log(`[FIRESTORE] [ORDER] Updating status of order ${orderId} to ${status}`);
    try {
      const orderRef = doc(db, ORDERS_COLLECTION, orderId);
      let existingOrder: Order | null = null;
      try {
        const orderDoc = await getDoc(orderRef);
        if (orderDoc.exists()) {
          existingOrder = orderDoc.data() as Order;
        }
      } catch {
        existingOrder = await getDocRest(ORDERS_COLLECTION, orderId);
      }

      const statusHistory = existingOrder?.statusHistory || [];
      statusHistory.push({
        status,
        timestamp: new Date().toISOString(),
        note: note || `Status updated to ${status}`,
      });

      await updateDoc(orderRef, cleanForFirestore({
        status,
        statusHistory,
        updatedAt: new Date().toISOString(),
      }));
      console.log(`[FIRESTORE] [ORDER] Status of order ${orderId} updated to ${status}!`);
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to update status of order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  async updateOrderPaymentStatus(orderId: string, paymentStatus: 'Pending Payment' | 'Paid' | 'Payment Verified' | 'Refunded'): Promise<void> {
    console.log(`[FIRESTORE] [ORDER] Updating payment status of order ${orderId} to ${paymentStatus}`);
    try {
      const orderRef = doc(db, ORDERS_COLLECTION, orderId);
      await updateDoc(orderRef, cleanForFirestore({
        paymentStatus,
        updatedAt: new Date().toISOString(),
      }));
      console.log(`[FIRESTORE] [ORDER] Payment status of order ${orderId} updated to ${paymentStatus}!`);
    } catch (e) {
      console.error(`[FIRESTORE] [ORDER] Failed to update payment status of order ${orderId}:`, e);
      handleFirestoreError(e, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
      throw e;
    }
  },

  // SETTINGS CLOUD CRUD
  async getSettings(): Promise<StoreSettings> {
    console.log('[FIRESTORE] [SETTINGS] Fetching store settings from Firestore...');
    try {
      const docRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      const snapshot = await getDoc(docRef);
      if (snapshot.exists()) {
        console.log('[FIRESTORE] [SETTINGS] Successfully fetched settings via SDK');
        return snapshot.data() as StoreSettings;
      }
      return INITIAL_SETTINGS;
    } catch (e) {
      console.warn('[FIRESTORE] [SETTINGS] SDK fetch failed, evaluating error:', e);
      handleFirestoreError(e, OperationType.GET, `${SETTINGS_COLLECTION}/${BOUTIQUE_SETTINGS_DOC}`);
      if (isQuotaExceededError(e)) {
        return INITIAL_SETTINGS;
      }
      const restSettings = await getDocRest(SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      if (restSettings) {
        console.log('[FIRESTORE] [SETTINGS] Successfully fetched settings via REST');
        return restSettings as StoreSettings;
      }
      return INITIAL_SETTINGS;
    }
  },

  async saveSettings(settings: StoreSettings): Promise<void> {
    console.log('[FIRESTORE] [SETTINGS] Saving store settings to Firestore...');
    try {
      const docRef = doc(db, SETTINGS_COLLECTION, BOUTIQUE_SETTINGS_DOC);
      // Securely omit adminPasscode so plaintext credentials are never saved in Firestore
      const { adminPasscode, ...safeSettings } = settings;
      await setDoc(docRef, cleanForFirestore({
        ...safeSettings,
        updatedAt: new Date().toISOString(),
      }), { merge: true });
      console.log('[FIRESTORE] [SETTINGS] Successfully saved store settings in Firestore!');
    } catch (e) {
      console.error('[FIRESTORE] [SETTINGS] Failed to save store settings:', e);
      handleFirestoreError(e, OperationType.WRITE, `${SETTINGS_COLLECTION}/${BOUTIQUE_SETTINGS_DOC}`);
      throw e;
    }
  },

  // CLOUDINARY PRODUCT IMAGE UPLOADS (Unsigned preset: lastella_products)
  async uploadProductImage(
    file: File | Blob,
    onProgress?: (percent: number) => void
  ): Promise<string> {
    console.log('[CLOUDINARY] Uploading image via uploadProductImageToCloudinary');
    return uploadProductImageToCloudinary(file, onProgress);
  },
};

export { processAndCompressImage, uploadProductImageToCloudinary };

