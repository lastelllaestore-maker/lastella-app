import { useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext';

export function useMobileNative() {
  const {
    currentTab,
    setCurrentTab,
    selectedProduct,
    setSelectedProduct,
    isCheckoutOpen,
    setIsCheckoutOpen,
    isRingSizeGuideOpen,
    setIsRingSizeGuideOpen,
    isOrderSuccessOpen,
    setIsOrderSuccessOpen,
    isNotificationsOpen,
    setIsNotificationsOpen,
    isAdminLoginOpen,
    setIsAdminLoginOpen,
  } = useStore();

  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    // 1. Initialize Capacitor native plugins conditionally (works seamlessly in both Web browser & Native Android/iOS)
    const initPlugins = async () => {
      try {
        const { Capacitor } = await import('@capacitor/core');
        if (Capacitor.isNativePlatform()) {
          // Status Bar
          const { StatusBar, Style } = await import('@capacitor/status-bar');
          await StatusBar.setStyle({ style: Style.Dark });
          await StatusBar.setBackgroundColor({ color: '#FFFFFF' });

          // Splash Screen: fade out native splash cleanly
          const { SplashScreen } = await import('@capacitor/splash-screen');
          await SplashScreen.hide({ fadeOutDuration: 250 });
        }
      } catch (err) {
        console.debug('Capacitor native plugins not active in current environment:', err);
      }
    };

    initPlugins();

    // 2. Network listener
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if (!navigator.onLine) {
      setIsOffline(true);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // 4. Android Hardware Back Button Handling
  useEffect(() => {
    let cleanupAppListener: (() => void) | null = null;

    const setupBackButton = async () => {
      try {
        const { Capacitor } = await import('@capacitor/core');
        if (Capacitor.isNativePlatform()) {
          const { App: CapApp } = await import('@capacitor/app');

          const listener = await CapApp.addListener('backButton', ({ canGoBack }) => {
            // Prioritize closing any open modal overlays first
            if (selectedProduct) {
              setSelectedProduct(null);
              return;
            }
            if (isCheckoutOpen) {
              setIsCheckoutOpen(false);
              return;
            }
            if (isRingSizeGuideOpen) {
              setIsRingSizeGuideOpen(false);
              return;
            }
            if (isOrderSuccessOpen) {
              setIsOrderSuccessOpen(false);
              return;
            }
            if (isNotificationsOpen) {
              setIsNotificationsOpen(false);
              return;
            }
            if (isAdminLoginOpen) {
              setIsAdminLoginOpen(false);
              return;
            }

            // If on a sub-view / sub-tab, return to home view
            if (currentTab !== 'home') {
              setCurrentTab('home');
              return;
            }

            // If on home with no modal open, allow normal back or exit app
            if (canGoBack) {
              window.history.back();
            } else {
              CapApp.exitApp();
            }
          });

          cleanupAppListener = () => {
            listener.remove();
          };
        }
      } catch (err) {
        console.debug('Back button listener init skipped:', err);
      }
    };

    setupBackButton();

    return () => {
      if (cleanupAppListener) cleanupAppListener();
    };
  }, [
    currentTab,
    setCurrentTab,
    selectedProduct,
    setSelectedProduct,
    isCheckoutOpen,
    setIsCheckoutOpen,
    isRingSizeGuideOpen,
    setIsRingSizeGuideOpen,
    isOrderSuccessOpen,
    setIsOrderSuccessOpen,
    isNotificationsOpen,
    setIsNotificationsOpen,
    isAdminLoginOpen,
    setIsAdminLoginOpen,
  ]);

  return { isOffline };
}
