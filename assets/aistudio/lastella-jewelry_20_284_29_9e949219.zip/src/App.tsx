import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { RingSizeModal } from './components/common/RingSizeModal';
import { Toast } from './components/common/Toast';
import { HomeView } from './components/home/HomeView';
import { CategoriesView } from './components/categories/CategoriesView';
import { SearchView } from './components/search/SearchView';
import { WishlistView } from './components/wishlist/WishlistView';
import { CartView } from './components/cart/CartView';
import { CheckoutView } from './components/checkout/CheckoutView';
import { OrderSuccessModal } from './components/orders/OrderSuccessModal';
import { AccountView } from './components/account/AccountView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { NotificationsDrawer } from './components/notifications/NotificationsDrawer';
import { ProductDetailsModal } from './components/products/ProductDetailsModal';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { StoreFooter } from './components/common/StoreFooter';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { SplashScreen } from './components/common/SplashScreen';
import { useMobileNative } from './utils/useMobileNative';
import { WifiOff } from 'lucide-react';

const MainLayout: React.FC = () => {
  const {
    currentTab,
    selectedProduct,
    setSelectedProduct,
    isRingSizeGuideOpen,
    setIsRingSizeGuideOpen,
    isCheckoutOpen,
    setIsCheckoutOpen,
    isOrderSuccessOpen,
    setIsOrderSuccessOpen,
    toastMessage,
    language,
    isFirestoreQuotaExceeded,
    firestoreUpgradeUrl,
  } = useStore();

  const { isOffline } = useMobileNative();
  const isAr = language === 'ar';

  const renderActiveView = () => {
    switch (currentTab) {
      case 'home':
        return <HomeView />;
      case 'categories':
        return <CategoriesView />;
      case 'search':
        return <SearchView />;
      case 'wishlist':
        return <WishlistView />;
      case 'cart':
        return <CartView />;
      case 'account':
        return <AccountView />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF9F9] text-[#2D2D2D] flex flex-col font-sans selection:bg-[#F5DFE5] selection:text-[#5B2333] w-full max-w-full">
      {/* Offline Alert Bar */}
      {isOffline && (
        <div className="bg-amber-500 text-white text-xs px-4 py-2 flex items-center justify-center gap-2 sticky top-0 z-50 shadow-xs animate-in fade-in">
          <WifiOff className="w-4 h-4 shrink-0" />
          <span>
            {isAr
              ? 'أنتِ غير متصلة بالإنترنت حالياً. يتم عرض المنتجات المخزنة محلياً.'
              : 'You are currently offline. Displaying cached jewelry items.'}
          </span>
        </div>
      )}

      {/* Firestore Daily Free Tier Quota Exceeded Alert Bar */}
      {isFirestoreQuotaExceeded && (
        <div className="bg-gradient-to-r from-amber-700 via-amber-600 to-amber-700 text-white text-xs px-3 sm:px-4 py-2 sm:py-2.5 flex items-center justify-between gap-2 sm:gap-4 sticky top-0 z-50 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-sm shrink-0">⚠️</span>
            <p className="text-[11px] sm:text-xs leading-tight truncate sm:whitespace-normal">
              {isAr
                ? 'تم استنفاد حصة القراءة اليومية المجانية لفايربيس. المتجر يعمل حالياً بوضع الحفظ الاحتياطي. تتجدد الحصة تلقائياً غداً.'
                : 'Firestore daily free tier quota reached. Store is running on cached data. Quota resets tomorrow.'}
            </p>
          </div>
          <a
            href={firestoreUpgradeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="underline font-bold hover:text-amber-100 shrink-0 text-[10px] sm:text-xs whitespace-nowrap bg-amber-800/60 px-2 py-1 rounded transition-colors"
          >
            {isAr ? 'ترقية الحصة ↗' : 'Upgrade Quota ↗'}
          </a>
        </div>
      )}

      {/* Sticky Header */}
      <Header />

      {/* Main Container */}
      <main className={`flex-1 w-full max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 pt-2.5 sm:pt-3.5 ${currentTab === 'admin' ? 'pb-16 sm:pb-12' : 'pb-24 sm:pb-28'}`}>
        <ErrorBoundary>
          {renderActiveView()}
        </ErrorBoundary>
        {currentTab !== 'admin' && currentTab !== 'account' && <StoreFooter />}
      </main>

      {/* Floating Elements & Fixed Navigation */}
      {currentTab !== 'admin' && <FloatingWhatsApp />}
      {currentTab !== 'admin' && <BottomNav />}

      {/* Modals & Overlays */}
      <ProductDetailsModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />

      <RingSizeModal
        isOpen={isRingSizeGuideOpen}
        onClose={() => setIsRingSizeGuideOpen(false)}
      />

      <CheckoutView
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
      />

      <OrderSuccessModal
        isOpen={isOrderSuccessOpen}
        onClose={() => setIsOrderSuccessOpen(false)}
      />

      <NotificationsDrawer />

      <AdminLoginModal />

      {/* Dynamic Toast feedback */}
      <Toast message={toastMessage} />

      {/* Luxury Branded Startup Transition (Pink crowned swan, LASTELLA name, & tagline) */}
      <SplashScreen minDurationMs={1100} />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <StoreProvider>
        <MainLayout />
      </StoreProvider>
    </ErrorBoundary>
  );
}
