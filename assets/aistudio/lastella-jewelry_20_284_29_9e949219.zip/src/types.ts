export type Language = 'ar' | 'en';

export type ProductCategory = 
  | 'New Arrivals'
  | 'Necklaces'
  | 'Bracelets'
  | 'Bangles'
  | 'Anklets'
  | 'Rings'
  | 'Brand Boxes'
  | 'Best Selling'
  | 'Jewelry Sets'
  | 'Combos';

export interface ProductVariant {
  id: string;
  sizeEn?: string;
  sizeAr?: string;
  colorEn?: string;
  colorAr?: string;
  available: boolean;
}

export interface Product {
  id: string;
  name: string;
  arabicName?: string;
  category: ProductCategory;
  price: number; // in OMR
  originalPrice?: number; // for discount display
  images: string[];
  description: string;
  arabicDescription?: string;
  features: string[]; // e.g. "One Year Warranty", "Everyday Wear", "Color Resistant", "Water Resistant"
  sizes?: (string | number)[]; // e.g. ["14", "15", "16", "17", "18", "19"] or ["Small", "Medium", "Large"]
  colors?: string[]; // e.g. ["Gold", "Silver"]
  variants?: ProductVariant[]; // Dynamic Add Variant system
  materials?: string; // Optional (e.g. "18K Gold PVD Plated & AAA Cubic Zirconia")
  arabicMaterials?: string;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  inStock: boolean;
  stockCount?: number;
  rating: number;
  reviewCount: number;
  careInstructions?: string;
  arabicCareInstructions?: string;
  sku: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: number | string;
  selectedColor?: string;
  selectedVariantId?: string;
  selectedSizeAr?: string;
  selectedColorAr?: string;
}

export type DeliveryMethod = 'home' | 'office';

export interface DeliveryOption {
  id: DeliveryMethod;
  name: string;
  description: string;
  price: number; // 2.000 OMR or 1.000 OMR
  estimatedTime: string;
}

export type OrderStatus = 
  | 'Order Placed'
  | 'Order Confirmed'
  | 'Preparing'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export interface OrderCustomer {
  name: string;
  phone: string;
  whatsapp: string;
  city?: string;
  area: string;
  detailedAddress?: string;
  address: string;
  governorate?: string;
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customer: OrderCustomer;
  items: CartItem[];
  subtotal: number;
  deliveryCharge: number;
  deliveryMethod: DeliveryMethod;
  total: number;
  status: OrderStatus;
  paymentStatus?: 'Pending Payment' | 'Paid' | 'Payment Verified' | 'Refunded';
  statusHistory: {
    status: OrderStatus;
    timestamp: string;
    note?: string;
  }[];
  paymentMethod: 'bank_transfer' | 'cod' | 'whatsapp_transfer' | 'card';
  notes?: string;
  trackingToken?: string;
  updatedAt?: string;
}

export interface Review {
  id: string;
  customerName: string;
  location: string; // e.g. "Muscat", "Salalah", "Sohar"
  rating: number;
  date: string;
  comment: string;
  productName: string;
  verifiedPurchase: boolean;
  avatarUrl?: string;
  images?: string[];
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  tagline: string;
  buttonText: string;
  categoryLink?: ProductCategory;
  imageUrl: string;
  badge?: string;
  active: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'arrival' | 'offer' | 'collection';
  timestamp: string;
  read: boolean;
  linkTab?: string;
  orderId?: string;
}

export interface SavedAddress {
  id: string;
  title: string; // "Home", "Office", etc.
  recipientName: string;
  phone: string;
  city?: string;
  governorate?: string;
  area: string;
  streetAddress: string;
  isDefault: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  addresses: SavedAddress[];
  isGuest: boolean;
}

export interface StoreSettings {
  storeName: string;
  storePhone: string;
  whatsappNumber: string; // formatted without + for wa.me links, e.g. "96894882311"
  displayWhatsApp: string; // formatted with +, e.g. "+968 9123 4567"
  announcementText: string;
  homeDeliveryPrice: number;
  officeDeliveryPrice: number;
  currency: string;
  adminPasscode?: string;
  // Bank Transfer Configuration
  bankName?: string;
  accountName?: string;
  accountNumber?: string;
  bankIban?: string;
  bankTransferInstructions?: string;
  bankTransferInstructionsAr?: string;
}
