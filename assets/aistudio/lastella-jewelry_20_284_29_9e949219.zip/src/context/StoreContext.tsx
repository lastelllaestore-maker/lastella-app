import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  Product,
  ProductCategory,
  CartItem,
  Order,
  AppNotification,
  UserProfile,
  StoreSettings,
  DeliveryMethod,
  Review,
  Banner,
  Language,
} from '../types';
import { storageService } from '../services/storageService';
import { firebaseService, authService, subscribeQuotaStatus } from '../services/firebaseService';
import { TRANSLATIONS, TranslationKeys } from '../i18n/translations';
import { translateSizeToArabic } from '../services/translationService';
import { triggerOrderEmailNotification } from '../services/orderNotificationService';

export type NavigationTab = 'home' | 'categories' | 'search' | 'wishlist' | 'cart' | 'account' | 'admin';
export type AdminSubTab = 'orders' | 'products' | 'settings';

interface StoreContextType {
  // Language & Localization (Default Arabic)
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  isRTL: boolean;
  t: (key: TranslationKeys | string) => string;

  // Navigation
  currentTab: NavigationTab;
  setCurrentTab: (tab: NavigationTab) => void;
  adminSubTab: AdminSubTab;
  setAdminSubTab: (tab: AdminSubTab) => void;
  isAddProductModalOpen: boolean;
  setIsAddProductModalOpen: (open: boolean) => void;
  selectedCategory: ProductCategory | null;
  setSelectedCategory: (cat: ProductCategory | null) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  isRingSizeGuideOpen: boolean;
  setIsRingSizeGuideOpen: (open: boolean) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isOrderSuccessOpen: boolean;
  setIsOrderSuccessOpen: (open: boolean) => void;
  lastPlacedOrder: Order | null;
  setLastPlacedOrder: (order: Order | null) => void;
  activeTrackingOrder: Order | null;
  setActiveTrackingOrder: (order: Order | null) => void;

  // Products & Data
  products: Product[];
  banners: Banner[];
  reviews: Review[];
  settings: StoreSettings;
  updateSettings: (newSettings: StoreSettings) => Promise<void>;
  refreshProducts: () => void;
  refreshSettings: () => void;
  refreshBanners: () => void;
  refreshReviews: () => void;

  // Cart
  cart: CartItem[];
  deliveryMethod: DeliveryMethod | null;
  setDeliveryMethod: (method: DeliveryMethod | null) => void;
  addToCart: (
    product: Product,
    quantity?: number,
    selectedSize?: number | string,
    selectedColor?: string,
    selectedVariantId?: string,
    selectedSizeAr?: string,
    selectedColorAr?: string
  ) => void;
  updateCartQuantity: (
    productId: string,
    quantity: number,
    selectedSize?: number | string,
    selectedColor?: string,
    selectedVariantId?: string
  ) => void;
  removeFromCart: (
    productId: string,
    selectedSize?: number | string,
    selectedColor?: string,
    selectedVariantId?: string
  ) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  deliveryCharge: number;
  cartTotal: number;

  // Wishlist
  wishlistIds: string[];
  wishlistProducts: Product[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Orders
  orders: Order[];
  refreshOrders: () => void;
  placeOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>) => Promise<Order>;

  // User Profile
  profile: UserProfile;
  updateProfile: (profile: UserProfile) => void;

  // Notifications
  notifications: AppNotification[];
  unreadNotifsCount: number;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;

  // Helpers
  formatOMR: (amount: number) => string;
  generateWhatsAppOrderUrl: (orderInfo: {
    customerName: string;
    phone: string;
    items: CartItem[];
    subtotal: number;
    delivery: number;
    deliveryMethod?: DeliveryMethod | string | null;
    total: number;
    deliveryAddress?: string;
    city?: string;
    area?: string;
    detailedAddress?: string;
    notes?: string;
  }) => string;
  generateWhatsAppProductUrl: (product: Product, size?: number | string, color?: string) => string;
  generateGeneralWhatsAppUrl: (message?: string) => string;

  // Admin Authentication
  isAdminAuthenticated: boolean;
  isAdminLoginOpen: boolean;
  setIsAdminLoginOpen: (open: boolean) => void;
  adminUser: { email: string | null; uid: string | null } | null;
  loginAdminWithCredentials: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginAdmin: (passcode: string) => Promise<{ success: boolean; error?: string }>;
  changeAdminPassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  logoutAdmin: () => Promise<void>;

  // Toast
  toastMessage: string | null;
  showToast: (msg: string) => void;

  // Cloud Firestore Status
  isFirestoreQuotaExceeded: boolean;
  firestoreUpgradeUrl: string;
}

export interface ProductActionsContextType {
  addToCart: (
    product: Product,
    quantity?: number,
    selectedSize?: number | string,
    selectedColor?: string,
    selectedVariantId?: string,
    selectedSizeAr?: string,
    selectedColorAr?: string
  ) => void;
  showToast: (msg: string) => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  setSelectedProduct: (product: Product | null) => void;
  formatOMR: (amount: number) => string;
  language: Language;
  t: (key: TranslationKeys | string) => string;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);
export const ProductActionsContext = createContext<ProductActionsContextType | undefined>(undefined);

function detectTabFromLocation(): NavigationTab {
  if (typeof window === 'undefined') return 'home';
  try {
    // 1. Check Pathname (e.g., /admin, /admin/, /account)
    const path = window.location.pathname.toLowerCase();
    if (path.includes('/admin') || path.endsWith('/admin') || path.endsWith('/admin/')) {
      return 'admin';
    }
    if (path.includes('/account')) return 'account';
    if (path.includes('/cart')) return 'cart';
    if (path.includes('/wishlist')) return 'wishlist';
    if (path.includes('/search')) return 'search';
    if (path.includes('/categories')) return 'categories';

    // 2. Check Hash (e.g. #admin, #admin-products, #account, #cart)
    const hash = window.location.hash.replace('#', '').toLowerCase();
    if (hash.startsWith('admin')) {
      return 'admin';
    }
    if (['home', 'categories', 'search', 'wishlist', 'cart', 'account', 'admin'].includes(hash)) {
      return hash as NavigationTab;
    }

    // 3. Check Query params (e.g. ?tab=admin, ?admin=true, ?page=admin, ?view=admin)
    const params = new URLSearchParams(window.location.search);
    if (params.has('admin') || params.get('admin') === 'true' || params.get('admin') === '1') {
      return 'admin';
    }
    const tabParam = (params.get('tab') || params.get('page') || params.get('view'))?.toLowerCase();
    if (tabParam && ['home', 'categories', 'search', 'wishlist', 'cart', 'account', 'admin'].includes(tabParam)) {
      return tabParam as NavigationTab;
    }
  } catch (e) {
    console.warn('[LASTELLA Router] Location parse error', e);
  }
  return 'home';
}

function detectAdminSubTabFromLocation(): AdminSubTab {
  if (typeof window === 'undefined') return 'orders';
  try {
    const hash = window.location.hash.toLowerCase();
    if (hash.includes('product')) return 'products';
    if (hash.includes('setting')) return 'settings';
    if (hash.includes('order')) return 'orders';

    const params = new URLSearchParams(window.location.search);
    const sub = params.get('sub')?.toLowerCase();
    if (sub === 'products' || sub === 'settings' || sub === 'orders') {
      return sub as AdminSubTab;
    }
  } catch (e) {
    // ignore
  }
  return 'orders';
}

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation State with URL hash/pathname/query sync for mobile deep-linking & reload support
  const [currentTab, setCurrentTab] = useState<NavigationTab>(() => detectTabFromLocation());
  const [adminSubTab, setAdminSubTabState] = useState<AdminSubTab>(() => detectAdminSubTabFromLocation());
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);

  const setAdminSubTab = useCallback((sub: AdminSubTab) => {
    setAdminSubTabState(sub);
    setCurrentTab('admin');
    try {
      if (typeof window !== 'undefined') {
        window.location.hash = `admin-${sub}`;
      }
    } catch {
      // ignore
    }
  }, []);

  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isRingSizeGuideOpen, setIsRingSizeGuideOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrderSuccessOpen, setIsOrderSuccessOpen] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);
  const [activeTrackingOrder, setActiveTrackingOrder] = useState<Order | null>(null);

  // Sync tab with URL hash & history for mobile navigation & reload persistence
  useEffect(() => {
    try {
      if (typeof window !== 'undefined') {
        const currentHash = window.location.hash.replace('#', '');
        if (currentHash !== currentTab) {
          window.location.hash = currentTab;
        }
      }
    } catch {
      // ignore
    }
  }, [currentTab]);

  useEffect(() => {
    const handleUrlChange = () => {
      const detected = detectTabFromLocation();
      setCurrentTab((prev) => (prev !== detected ? detected : prev));
      const detectedSub = detectAdminSubTabFromLocation();
      setAdminSubTabState((prev) => (prev !== detectedSub ? detectedSub : prev));
    };

    window.addEventListener('hashchange', handleUrlChange);
    window.addEventListener('popstate', handleUrlChange);
    return () => {
      window.removeEventListener('hashchange', handleUrlChange);
      window.removeEventListener('popstate', handleUrlChange);
    };
  }, []);

  // Language State (Defaults to Arabic)
  const [language, setLanguageState] = useState<Language>(() => storageService.getLanguage());

  const isRTL = language === 'ar';

  const t = useCallback(
    (key: TranslationKeys | string): string => {
      return (TRANSLATIONS[language] as any)?.[key] || (TRANSLATIONS.ar as any)?.[key] || (key as string);
    },
    [language]
  );

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    storageService.saveLanguage(lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, []);

  const toggleLanguage = useCallback(() => {
    const next = language === 'ar' ? 'en' : 'ar';
    setLanguage(next);
  }, [language, setLanguage]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  // Storage synced state (initial placeholder cache only while Firestore connects)
  const [products, setProducts] = useState<Product[]>(() => storageService.getCachedProducts());
  const [banners, setBanners] = useState<Banner[]>(() => storageService.getBanners());
  const [reviews, setReviews] = useState<Review[]>(() => storageService.getReviews());
  const [settings, setSettings] = useState<StoreSettings>(() => storageService.getCachedSettings());
  const [cart, setCart] = useState<CartItem[]>(() => storageService.getCart());
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => storageService.getWishlist());
  
  // Isolated order data: Customer sees ONLY their own placed orders on this device; Admin sees all store orders
  const [customerOrders, setCustomerOrders] = useState<Order[]>(() => storageService.getMyOrders());
  const [adminOrders, setAdminOrders] = useState<Order[]>(() => storageService.getAdminCachedOrders());

  const [profile, setProfile] = useState<UserProfile>(() => storageService.getProfile());
  const [notifications, setNotifications] = useState<AppNotification[]>(() => storageService.getNotifications());
  const [recentSearches, setRecentSearches] = useState<string[]>(() => storageService.getRecentSearches());
  // Delivery Method: starts as null for each new checkout session (neither Home nor Office preselected)
  const [deliveryMethod, setDeliveryMethodState] = useState<DeliveryMethod | null>(null);

  // Search
  const [searchQuery, setSearchQuery] = useState('');

  // Admin Auth State: strictly verified via Firebase Authentication
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    const u = authService.getCurrentUser();
    return Boolean(u && authService.isCurrentAdmin());
  });
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [adminUser, setAdminUser] = useState<{ email: string | null; uid: string | null } | null>(() => {
    const u = authService.getCurrentUser();
    return u && authService.isCurrentAdmin() ? { email: u.email, uid: u.uid } : null;
  });

  // Current orders exposed to the app: Admin gets all orders; regular customer gets ONLY their own orders
  const orders = useMemo(() => {
    return isAdminAuthenticated ? adminOrders : customerOrders;
  }, [isAdminAuthenticated, adminOrders, customerOrders]);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Firestore Quota State & Upgrade Url
  const [isFirestoreQuotaExceeded, setIsFirestoreQuotaExceeded] = useState(false);
  const firestoreUpgradeUrl =
    'https://console.firebase.google.com/project/gen-lang-client-0637631484/firestore/databases/ai-studio-lastellajewelry-efd3dfa3-a01c-4ed6-b180-7ec71f8b8354/data?openUpgradeDialog=true';

  useEffect(() => {
    const unsub = subscribeQuotaStatus((exceeded) => {
      setIsFirestoreQuotaExceeded(exceeded);
      // Immediately fallback to cached data so the store doesn't display empty UI
      const cachedProds = storageService.getCachedProducts();
      if (cachedProds && cachedProds.length > 0) {
        setProducts(cachedProds);
      }
      if (isAdminAuthenticated) {
        const cachedAdmin = storageService.getAdminCachedOrders();
        if (cachedAdmin && cachedAdmin.length > 0) {
          setAdminOrders(cachedAdmin);
        }
      } else {
        setCustomerOrders(storageService.getMyOrders());
      }
      const cachedSettings = storageService.getCachedSettings();
      if (cachedSettings) {
        setSettings(cachedSettings);
      }
    });
    return () => unsub();
  }, [isAdminAuthenticated]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  // Subscribe to Firebase Auth state for verified Admin privileges (SINGLE SOURCE OF TRUTH)
  useEffect(() => {
    const unsubscribe = authService.subscribeAuth((user, isAdmin) => {
      if (user && isAdmin) {
        setAdminUser({ email: user.email || 'lastelllaestore@gmail.com', uid: user.uid });
        setIsAdminAuthenticated(true);
        storageService.setAdminAuthenticated(true);
      } else {
        setAdminUser(null);
        setIsAdminAuthenticated(false);
        storageService.setAdminAuthenticated(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const loginAdminWithCredentials = useCallback(
    async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
      const cleanEmail = (email || '').trim().toLowerCase();
      if (cleanEmail !== 'lastelllaestore@gmail.com') {
        const errorMsg =
          language === 'ar'
            ? 'تم رفض الوصول: هذا الحساب غير مصرح له بإدارة المتجر. المدير المعتمد: lastelllaestore@gmail.com'
            : 'Access Denied: Account is not authorized. Authorized admin: lastelllaestore@gmail.com';
        showToast(errorMsg);
        return { success: false, error: errorMsg };
      }

      if (!password || !password.trim()) {
        const errorMsg = language === 'ar' ? 'الرجاء إدخال كلمة المرور' : 'Please enter password';
        showToast(errorMsg);
        return { success: false, error: errorMsg };
      }

      try {
        const { user, isAdmin } = await authService.signInAdminWithCredentials(cleanEmail, password);
        if (isAdmin && user) {
          setIsAdminAuthenticated(true);
          storageService.setAdminAuthenticated(true);
          setAdminUser({ email: user?.email || cleanEmail, uid: user.uid });
          setIsAdminLoginOpen(false);
          setCurrentTab('admin');
          showToast(
            language === 'ar'
              ? `مرحباً! تم التحقق من حساب المدير 🔐 (${cleanEmail})`
              : `Authenticated as LASTELLA Manager 🔐 (${cleanEmail})`
          );
          return { success: true };
        }
        throw new Error('Not authorized');
      } catch (err: any) {
        let errMsg =
          language === 'ar'
            ? 'بيانات الدخول غير صحيحة. تم رفض الوصول.'
            : 'Incorrect credentials. Access Denied.';
        if (err?.code === 'auth/wrong-password' || err?.code === 'auth/invalid-credential') {
          errMsg = language === 'ar' ? 'كلمة المرور غير صحيحة. تم رفض الوصول.' : 'Incorrect password. Access Denied.';
        }
        showToast(errMsg);
        return { success: false, error: errMsg };
      }
    },
    [showToast, language]
  );

  const loginAdmin = useCallback(
    async (passcode: string): Promise<{ success: boolean; error?: string }> => {
      const cleanPass = (passcode || '').trim();
      if (!cleanPass) {
        const err = language === 'ar' ? 'الرجاء إدخال رمز المرور' : 'Please enter passcode';
        showToast(err);
        return { success: false, error: err };
      }

      try {
        const { user, isAdmin } = await authService.signInAdminWithCredentials('lastelllaestore@gmail.com', cleanPass);
        if (isAdmin && user) {
          setIsAdminAuthenticated(true);
          storageService.setAdminAuthenticated(true);
          setAdminUser({ email: user.email || 'lastelllaestore@gmail.com', uid: user.uid });
          setIsAdminLoginOpen(false);
          setCurrentTab('admin');
          showToast(language === 'ar' ? 'تم تسجيل الدخول بنجاح كمدير للمتجر 🔐' : 'Authenticated as LASTELLA Manager 🔐');
          return { success: true };
        }
        throw new Error('Not authorized');
      } catch (err: any) {
        const errMsg = language === 'ar' ? 'رمز المرور غير صحيح. تم رفض الوصول.' : 'Incorrect passcode. Access Denied.';
        showToast(errMsg);
        return { success: false, error: errMsg };
      }
    },
    [showToast, language]
  );

  const changeAdminPassword = useCallback(
    async (currentPassword: string, newPassword: string): Promise<{ success: boolean; error?: string }> => {
      return authService.changeAdminPassword(currentPassword, newPassword);
    },
    []
  );

  const logoutAdmin = useCallback(async () => {
    try {
      await authService.signOutAdmin();
    } catch (e) {
      console.warn('Firebase signout note:', e);
    }
    setAdminUser(null);
    setIsAdminAuthenticated(false);
    storageService.setAdminAuthenticated(false);
    setAdminOrders([]);
    setCurrentTab('home');
    showToast('Admin logged out successfully');
  }, [showToast]);


  // Initial load & Real-Time Cloud Firestore Sync (SINGLE SOURCE OF TRUTH)
  useEffect(() => {
    // 1. Initial immediate local hydration for instant render from cache
    setProducts(storageService.getCachedProducts());
    setBanners(storageService.getBanners());
    setReviews(storageService.getReviews());
    setSettings(storageService.getCachedSettings());
    setCart(storageService.getCart());
    setWishlistIds(storageService.getWishlist());
    setCustomerOrders(storageService.getMyOrders());
    setAdminOrders(storageService.getAdminCachedOrders());
    setProfile(storageService.getProfile());
    setNotifications(storageService.getNotifications());
    setRecentSearches(storageService.getRecentSearches());

    // 2. Safe one-time migration check: only seeds if Firestore is genuinely empty and never migrated
    firebaseService.runInitialMigration().catch((err) => {
      console.warn('[LASTELLA Firebase] Initial migration check notice:', err);
    });

    // 3. Real-Time Cloud Firestore Listener for Products (FIRESTORE IS AUTHORITATIVE)
    const unsubProducts = firebaseService.subscribeProducts((cloudProducts) => {
      setProducts(cloudProducts);
      storageService.cacheProducts(cloudProducts);

      // Keep cart items inStock & pricing synchronized in real-time across devices
      setCart((prevCart) => {
        let changed = false;
        const updated = prevCart.map((item) => {
          const fresh = cloudProducts.find((p) => p.id === item.product.id);
          if (fresh && (fresh.inStock !== item.product.inStock || fresh.price !== item.product.price)) {
            changed = true;
            return {
              ...item,
              product: {
                ...item.product,
                inStock: fresh.inStock,
                price: fresh.price,
                name: fresh.name,
                arabicName: fresh.arabicName,
              },
            };
          }
          return item;
        });
        if (changed) {
          storageService.saveCart(updated);
          return updated;
        }
        return prevCart;
      });
    });

    // 4. Real-Time Cloud Firestore Listener for Boutique Settings (FIRESTORE IS AUTHORITATIVE)
    const unsubSettings = firebaseService.subscribeSettings((cloudSettings) => {
      if (cloudSettings) {
        setSettings(cloudSettings);
        storageService.cacheSettings(cloudSettings);
      }
    });

    return () => {
      unsubProducts();
      unsubSettings();
    };
  }, []);

  // Real-Time Orders Listener: Only attached when admin is verified (conforms to Firebase Skill & Privacy)
  useEffect(() => {
    if (!isAdminAuthenticated) {
      setAdminOrders([]);
      return;
    }
    const unsubOrders = firebaseService.subscribeOrders((cloudOrders) => {
      setAdminOrders(cloudOrders);
      storageService.cacheAdminOrders(cloudOrders);
    });
    return () => unsubOrders();
  }, [isAdminAuthenticated]);

  // Stable list of customer order IDs to avoid listener churn
  const customerOrderIds = useMemo(() => {
    return customerOrders.map((o) => o.id).filter(Boolean).join(',');
  }, [customerOrders.length, customerOrders[0]?.id]);

  // Real-Time Customer Order Tracking Listener:
  // Listens to Firestore updates for this customer's active orders in real time.
  // Each order is listened to individually by its canonical document ID.
  // When an admin changes the status in Firestore, customer sees the updated status immediately.
  useEffect(() => {
    if (isAdminAuthenticated || !customerOrderIds) {
      return;
    }

    const orderIdList = customerOrderIds.split(',').filter(Boolean);
    const unsubs: (() => void)[] = [];

    // For active/recent orders on this device, attach real-time single-order listeners
    orderIdList.forEach((orderId) => {
      const unsub = firebaseService.subscribeSingleOrder(orderId, (freshOrder) => {
        if (!freshOrder) return;
        setCustomerOrders((prevList) => {
          const idx = prevList.findIndex((o) => o.id === freshOrder.id);
          if (idx === -1) return prevList;
          const current = prevList[idx];
          if (
            current.status === freshOrder.status &&
            current.paymentStatus === freshOrder.paymentStatus &&
            current.updatedAt === freshOrder.updatedAt
          ) {
            return prevList;
          }
          const nextList = [...prevList];
          const merged = { ...current, ...freshOrder };
          nextList[idx] = merged;
          storageService.updateMyOrder(merged);
          return nextList;
        });

        // Also update lastPlacedOrder and activeTrackingOrder in real time if matched
        setLastPlacedOrder((prev) => (prev && prev.id === freshOrder.id ? { ...prev, ...freshOrder } : prev));
        setActiveTrackingOrder((prev) => (prev && prev.id === freshOrder.id ? { ...prev, ...freshOrder } : prev));
      });
      unsubs.push(unsub);
    });

    return () => {
      unsubs.forEach((unsub) => {
        try {
          unsub();
        } catch {
          // Ignore cleanup errors
        }
      });
    };
  }, [isAdminAuthenticated, customerOrderIds]);

  // Sync helpers (queries directly from Cloud Firestore)
  const refreshProducts = useCallback(async () => {
    try {
      const prods = await firebaseService.getProducts();
      setProducts(prods);
      storageService.cacheProducts(prods);
    } catch {
      // ignore
    }
  }, []);

  const refreshSettings = useCallback(async () => {
    try {
      const s = await firebaseService.getSettings();
      setSettings(s);
      storageService.cacheSettings(s);
    } catch {
      // ignore
    }
  }, []);

  const updateSettings = useCallback(async (newSettings: StoreSettings) => {
    setSettings(newSettings);
    storageService.cacheSettings(newSettings);
    storageService.saveSettings(newSettings);
    try {
      await firebaseService.saveSettings(newSettings);
    } catch (e) {
      console.warn('[StoreContext] Failed to persist settings to Firestore:', e);
      throw e;
    }
  }, []);

  const refreshBanners = useCallback(() => {
    setBanners(storageService.getBanners());
  }, []);

  const refreshReviews = useCallback(() => {
    setReviews(storageService.getReviews());
  }, []);

  const refreshOrders = useCallback(async () => {
    if (isAdminAuthenticated) {
      try {
        const ords = await firebaseService.getOrders();
        setAdminOrders(ords);
        storageService.cacheAdminOrders(ords);
      } catch {
        // ignore
      }
    } else {
      setCustomerOrders(storageService.getMyOrders());
    }
  }, [isAdminAuthenticated]);

  const setDeliveryMethod = useCallback((method: DeliveryMethod | null) => {
    setDeliveryMethodState(method);
    storageService.setDeliveryMethod(method);
  }, []);

  // Cart operations
  const addToCart = useCallback(
    (
      product: Product,
      quantity = 1,
      selectedSize?: number | string,
      selectedColor?: string,
      selectedVariantId?: string,
      selectedSizeAr?: string,
      selectedColorAr?: string
    ) => {
      // Respect Availability Checkbox: Prevent ordering unavailable/out-of-stock products
      if (product.inStock === false) {
        showToast(
          language === 'ar'
            ? 'عذراً، هذه القطعة غير متوفرة حالياً للطلب'
            : 'Sorry, this product is currently unavailable for order'
        );
        return;
      }

      // Check variant availability if variant is specified or matched
      if (selectedVariantId && product.variants && product.variants.length > 0) {
        const variant = product.variants.find((v) => v.id === selectedVariantId);
        if (variant && variant.available === false) {
          showToast(
            language === 'ar'
              ? 'عذراً، هذا الخيار غير متوفر حالياً في المخزن'
              : 'Sorry, this option is currently out of stock'
          );
          return;
        }
      }

      // Resolve fallback variant values if not explicitly provided
      let resolvedVariantId = selectedVariantId;
      let resolvedSize = selectedSize;
      let resolvedColor = selectedColor;
      let resolvedSizeAr = selectedSizeAr;
      let resolvedColorAr = selectedColorAr;

      if (!resolvedVariantId && product.variants && product.variants.length > 0) {
        const match = product.variants.find((v) => {
          const sMatch = !v.sizeEn || String(v.sizeEn) === String(resolvedSize ?? '');
          const cMatch = !v.colorEn || String(v.colorEn) === String(resolvedColor ?? '');
          return sMatch && cMatch;
        });
        if (match) {
          if (match.available === false) {
            showToast(
              language === 'ar'
                ? 'عذراً، هذا الخيار غير متوفر حالياً في المخزن'
                : 'Sorry, this option is currently out of stock'
            );
            return;
          }
          resolvedVariantId = match.id;
          resolvedSize = resolvedSize ?? match.sizeEn;
          resolvedColor = resolvedColor ?? match.colorEn;
          resolvedSizeAr = resolvedSizeAr ?? match.sizeAr;
          resolvedColorAr = resolvedColorAr ?? match.colorAr;
        }
      }

      if (resolvedSize === undefined && product.sizes && product.sizes.length === 1) {
        resolvedSize = product.sizes[0];
      }
      if (resolvedColor === undefined && product.colors && product.colors.length === 1) {
        resolvedColor = product.colors[0];
      }

      setCart((prevCart) => {
        const existingIndex = prevCart.findIndex((item) => {
          if (item.product.id !== product.id) return false;
          if (resolvedVariantId && item.selectedVariantId) {
            return item.selectedVariantId === resolvedVariantId;
          }
          return (
            String(item.selectedSize ?? '') === String(resolvedSize ?? '') &&
            String(item.selectedColor ?? '') === String(resolvedColor ?? '')
          );
        });

        let updated: CartItem[];
        if (existingIndex > -1) {
          updated = [...prevCart];
          updated[existingIndex] = {
            ...updated[existingIndex],
            quantity: updated[existingIndex].quantity + quantity,
          };
        } else {
          const newItem: CartItem = {
            product,
            quantity,
            ...(resolvedSize !== undefined ? { selectedSize: resolvedSize } : {}),
            ...(resolvedColor !== undefined ? { selectedColor: resolvedColor } : {}),
            ...(resolvedVariantId ? { selectedVariantId: resolvedVariantId } : {}),
            ...(resolvedSizeAr ? { selectedSizeAr: resolvedSizeAr } : {}),
            ...(resolvedColorAr ? { selectedColorAr: resolvedColorAr } : {}),
          };
          updated = [...prevCart, newItem];
        }

        storageService.saveCart(updated);
        return updated;
      });

      showToast(`Added "${product.name.slice(0, 24)}..." to Cart 🛍️`);
    },
    [language, showToast]
  );

  const updateCartQuantity = useCallback(
    (
      productId: string,
      quantity: number,
      selectedSize?: number | string,
      selectedColor?: string,
      selectedVariantId?: string
    ) => {
      setCart((prevCart) => {
        let updated: CartItem[];
        const isMatch = (item: CartItem) => {
          if (item.product.id !== productId) return false;
          if (selectedVariantId && item.selectedVariantId) {
            return item.selectedVariantId === selectedVariantId;
          }
          return (
            String(item.selectedSize ?? '') === String(selectedSize ?? '') &&
            String(item.selectedColor ?? '') === String(selectedColor ?? '')
          );
        };

        if (quantity <= 0) {
          updated = prevCart.filter((item) => !isMatch(item));
        } else {
          updated = prevCart.map((item) => {
            if (isMatch(item)) {
              return { ...item, quantity };
            }
            return item;
          });
        }
        storageService.saveCart(updated);
        return updated;
      });
    },
    []
  );

  const removeFromCart = useCallback(
    (
      productId: string,
      selectedSize?: number | string,
      selectedColor?: string,
      selectedVariantId?: string
    ) => {
      setCart((prevCart) => {
        const isMatch = (item: CartItem) => {
          if (item.product.id !== productId) return false;
          if (selectedVariantId && item.selectedVariantId) {
            return item.selectedVariantId === selectedVariantId;
          }
          return (
            String(item.selectedSize ?? '') === String(selectedSize ?? '') &&
            String(item.selectedColor ?? '') === String(selectedColor ?? '')
          );
        };

        const updated = prevCart.filter((item) => !isMatch(item));
        storageService.saveCart(updated);
        return updated;
      });
    },
    []
  );

  const clearCart = useCallback(() => {
    setCart([]);
    storageService.saveCart([]);
    setDeliveryMethodState(null);
    storageService.setDeliveryMethod(null);
  }, []);

  const cartCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  const cartSubtotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  }, [cart]);

  // Delivery Charge: Returns 0 when no delivery method is selected yet. Never applies free delivery.
  const deliveryCharge = useMemo(() => {
    if (cart.length === 0 || !deliveryMethod) return 0;
    const homePrice = settings.homeDeliveryPrice !== undefined ? settings.homeDeliveryPrice : 2.0;
    const officePrice = settings.officeDeliveryPrice !== undefined ? settings.officeDeliveryPrice : 1.0;
    return deliveryMethod === 'office' ? officePrice : homePrice;
  }, [cart.length, deliveryMethod, settings.homeDeliveryPrice, settings.officeDeliveryPrice]);

  const cartTotal = useMemo(() => {
    return cartSubtotal + (deliveryMethod ? deliveryCharge : 0);
  }, [cartSubtotal, deliveryCharge, deliveryMethod]);

  // Wishlist
  const toggleWishlist = useCallback((productId: string) => {
    const updated = storageService.toggleWishlist(productId);
    setWishlistIds(updated);
    const inWish = updated.includes(productId);
    const prod = products.find((p) => p.id === productId);
    if (prod) {
      showToast(inWish ? `Saved to Wishlist ❤️` : `Removed from Wishlist`);
    }
  }, [products, showToast]);

  const isInWishlist = useCallback(
    (productId: string) => {
      return wishlistIds.includes(productId);
    },
    [wishlistIds]
  );

  const wishlistProducts = useMemo(() => {
    return products.filter((p) => wishlistIds.includes(p.id));
  }, [products, wishlistIds]);

  // Orders (Single Source of Truth: written directly to Cloud Firestore)
  const placeOrder = useCallback(
    async (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status' | 'statusHistory'>) => {
      try {
        const order = await firebaseService.createOrder(orderData);
        setLastPlacedOrder(order);
        setActiveTrackingOrder(order);
        setCustomerOrders((prev) => [order, ...prev.filter((o) => o.id !== order.id)]);
        storageService.saveMyOrder(order);
        clearCart();
        setIsCheckoutOpen(false);
        setIsOrderSuccessOpen(true);

        storageService.addNotification({
          title: `🛍️ Order #${order.orderNumber} Placed!`,
          message: `Your order for ${order.items.length} item(s) totalling ${order.total.toFixed(3)} OMR has been received.`,
          type: 'order',
          orderId: order.id,
          linkTab: 'account',
        });
        setNotifications(storageService.getNotifications());

        // Asynchronously notify Cloudflare Worker without blocking checkout UI or WhatsApp ordering
        void triggerOrderEmailNotification(order).catch((err) => {
          console.warn('[StoreContext] Non-blocking email dispatch note:', err);
        });

        return order;
      } catch (err: any) {
        console.error('[StoreContext] placeOrder error:', err);
        showToast(language === 'ar' ? 'فشل إرسال الطلب. يرجى المحاولة ثانية.' : 'Failed to place order. Please retry.');
        throw err;
      }
    },
    [clearCart, language, showToast]
  );

  // Profile
  const updateProfile = useCallback((newProfile: UserProfile) => {
    setProfile(newProfile);
    storageService.saveProfile(newProfile);
  }, []);

  // Notifications
  const markNotificationRead = useCallback((id: string) => {
    storageService.markNotificationRead(id);
    setNotifications(storageService.getNotifications());
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    storageService.markAllNotificationsRead();
    setNotifications(storageService.getNotifications());
  }, []);

  const unreadNotifsCount = useMemo(() => {
    return notifications.filter((n) => !n.read).length;
  }, [notifications]);

  // Search history
  const addRecentSearch = useCallback((query: string) => {
    storageService.addRecentSearch(query);
    setRecentSearches(storageService.getRecentSearches());
  }, []);

  const clearRecentSearches = useCallback(() => {
    storageService.clearRecentSearches();
    setRecentSearches([]);
  }, []);

  // Currency Formatter (OMR in English, ر.ع. in Arabic)
  const formatOMR = useCallback((amount: number) => {
    const val = Number(amount || 0).toFixed(3);
    return language === 'ar' ? `${val} ر.ع.` : `${val} OMR`;
  }, [language]);

  // WhatsApp Order URL Generator (Bilingual)
  const generateWhatsAppOrderUrl = useCallback(
    (orderInfo: {
      customerName: string;
      phone: string;
      items: CartItem[];
      subtotal: number;
      delivery: number;
      deliveryMethod?: DeliveryMethod | string | null;
      total: number;
      deliveryAddress?: string;
      city?: string;
      area?: string;
      detailedAddress?: string;
      notes?: string;
    }) => {
      const waNumber = settings.whatsappNumber || '96894882311';
      let message = '';

      if (language === 'ar') {
        const methodTitle =
          orderInfo.deliveryMethod === 'office'
            ? 'استلام من المكتب'
            : orderInfo.deliveryMethod === 'home'
            ? 'توصيل للمنزل'
            : '';

        message = `✨ *طلب جديد من مجوهرات لاستيلا LASTELLA* ✨\n\n`;
        message += `*اسم الزبونة:* ${orderInfo.customerName}\n`;
        message += `*رقم الهاتف:* ${orderInfo.phone}\n\n`;
        message += `*تفاصيل القطع المطلوبة:*\n`;

        orderInfo.items.forEach((item, idx) => {
          const name = item.product.arabicName || item.product.name;
          const sizeDisplay = item.selectedSizeAr || (item.selectedSize ? translateSizeToArabic(String(item.selectedSize)) : item.selectedSize);
          const colorDisplay =
            item.selectedColorAr ||
            (item.selectedColor === 'Gold'
              ? 'ذهبي'
              : item.selectedColor === 'Silver'
              ? 'فضي'
              : item.selectedColor);
          const sizeStr = sizeDisplay ? ` (المقاس: ${sizeDisplay})` : '';
          const colorStr = colorDisplay ? ` (اللون: ${colorDisplay})` : '';
          message += `${idx + 1}. ${name}${sizeStr}${colorStr}\n   الكمية: ${item.quantity} × ${formatOMR(item.product.price)} = ${formatOMR(item.product.price * item.quantity)}\n`;
        });

        message += `\n*المجموع الفرعي:* ${formatOMR(orderInfo.subtotal)}\n`;
        message += `*رسوم التوصيل${methodTitle ? ` (${methodTitle})` : ''}:* ${formatOMR(orderInfo.delivery)}\n`;
        message += `*المجموع الكلي:* ${formatOMR(orderInfo.total)}\n\n`;
        if (orderInfo.city && orderInfo.area && orderInfo.detailedAddress) {
          message += `*المدينة:* ${orderInfo.city}\n`;
          message += `*المنطقة:* ${orderInfo.area}\n`;
          message += `*العنوان التفصيلي:* ${orderInfo.detailedAddress}\n`;
        } else {
          message += `*عنوان التوصيل:* ${orderInfo.deliveryAddress || ''}\n`;
        }
        if (orderInfo.notes) {
          message += `*ملاحظات إضافية:* ${orderInfo.notes}\n`;
        }
        message += `\nشكراً لاختياركِ مجوهرات لاستيلا الفاخرة! 💎🇴🇲`;
      } else {
        const methodTitleEn =
          orderInfo.deliveryMethod === 'office'
            ? 'Office Delivery'
            : orderInfo.deliveryMethod === 'home'
            ? 'Home Delivery'
            : '';

        message = `✨ *LASTELLA Jewelry Order* ✨\n\n`;
        message += `*Customer Name:* ${orderInfo.customerName}\n`;
        message += `*Phone:* ${orderInfo.phone}\n\n`;
        message += `*Products:*\n`;

        orderInfo.items.forEach((item, idx) => {
          const sizeStr = item.selectedSize ? ` (Size: ${item.selectedSize})` : '';
          const colorStr = item.selectedColor ? ` (Color: ${item.selectedColor})` : '';
          message += `${idx + 1}. ${item.product.name}${sizeStr}${colorStr}\n   Qty: ${item.quantity} × ${formatOMR(item.product.price)} = ${formatOMR(item.product.price * item.quantity)}\n`;
        });

        message += `\n*Subtotal:* ${formatOMR(orderInfo.subtotal)}\n`;
        message += `*Delivery Fee${methodTitleEn ? ` (${methodTitleEn})` : ''}:* ${formatOMR(orderInfo.delivery)}\n`;
        message += `*Total:* ${formatOMR(orderInfo.total)}\n\n`;
        if (orderInfo.city && orderInfo.area && orderInfo.detailedAddress) {
          message += `*City:* ${orderInfo.city}\n`;
          message += `*Area:* ${orderInfo.area}\n`;
          message += `*Detailed Address:* ${orderInfo.detailedAddress}\n`;
        } else {
          message += `*Delivery Address:* ${orderInfo.deliveryAddress || ''}\n`;
        }
        if (orderInfo.notes) {
          message += `*Notes:* ${orderInfo.notes}\n`;
        }
        message += `\nThank you for choosing LASTELLA Luxury Jewelry! 💎🇴🇲`;
      }

      return `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;
    },
    [formatOMR, language, settings.whatsappNumber]
  );

  const generateWhatsAppProductUrl = useCallback(
    (product: Product, size?: number | string, color?: string) => {
      const waNumber = settings.whatsappNumber || '96894882311';
      let message = '';
      if (language === 'ar') {
        const prodName = product.arabicName || product.name;
        message = `مرحباً مجوهرات لاستيلا 🌸\nأود الاستفسار والطلب للقطعة التالية:\n\n`;
        message += `💎 *${prodName}*\n`;
        message += `الرمز: ${product.sku}\n`;
        message += `السعر: ${formatOMR(product.price)}\n`;
        if (size) {
          message += `المقاس المطلوب: ${size}\n`;
        }
        if (color) {
          message += `اللون المطلوب: ${color}\n`;
        }
        message += `\nهل القطعة جاهزة للشحن والتوصيل السريع داخل عُمان؟`;
      } else {
        message = `Hello LASTELLA! 🌸\nI would like to inquire/order:\n\n`;
        message += `💎 *${product.name}*\n`;
        message += `SKU: ${product.sku}\n`;
        message += `Price: ${formatOMR(product.price)}\n`;
        if (size) {
          message += `Size: ${size}\n`;
        }
        if (color) {
          message += `Color: ${color}\n`;
        }
        message += `\nPlease let me know if it is ready for fast delivery in Oman.`;
      }

      return `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;
    },
    [formatOMR, language, settings.whatsappNumber]
  );

  const generateGeneralWhatsAppUrl = useCallback(
    (customMsg?: string) => {
      const waNumber = settings.whatsappNumber || '96894882311';
      const msg =
        customMsg ||
        (language === 'ar'
          ? `مرحباً مجوهرات لاستيلا 🌸 لدي استفسار بخصوص تشكيلة المجوهرات والتوصيل في عُمان.`
          : `Hello LASTELLA Boutique! 🌸 I have a question regarding your jewelry collection in Oman.`);
      return `https://wa.me/${waNumber}?text=${encodeURIComponent(msg)}`;
    },
    [language, settings.whatsappNumber]
  );

  // Dedicated memoized value for product cards to isolate catalog items from unrelated context updates
  const productActionsValue = useMemo<ProductActionsContextType>(
    () => ({
      addToCart,
      showToast,
      toggleWishlist,
      isInWishlist,
      setSelectedProduct,
      formatOMR,
      language,
      t,
    }),
    [addToCart, showToast, toggleWishlist, isInWishlist, setSelectedProduct, formatOMR, language, t]
  );

  return (
    <StoreContext.Provider
      value={{
        language,
        setLanguage,
        toggleLanguage,
        isRTL,
        t,

        currentTab,
        setCurrentTab,
        selectedCategory,
        setSelectedCategory,
        selectedProduct,
        setSelectedProduct,
        isRingSizeGuideOpen,
        setIsRingSizeGuideOpen,
        isNotificationsOpen,
        setIsNotificationsOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isOrderSuccessOpen,
        setIsOrderSuccessOpen,
        lastPlacedOrder,
        setLastPlacedOrder,
        activeTrackingOrder,
        setActiveTrackingOrder,

        products,
        banners,
        reviews,
        settings,
        updateSettings,
        refreshProducts,
        refreshSettings,
        refreshBanners,
        refreshReviews,

        cart,
        deliveryMethod,
        setDeliveryMethod,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        deliveryCharge,
        cartTotal,

        wishlistIds,
        wishlistProducts,
        toggleWishlist,
        isInWishlist,

        orders,
        refreshOrders,
        placeOrder,

        profile,
        updateProfile,

        notifications,
        unreadNotifsCount,
        markNotificationRead,
        markAllNotificationsRead,

        searchQuery,
        setSearchQuery,
        recentSearches,
        addRecentSearch,
        clearRecentSearches,

        formatOMR,
        generateWhatsAppOrderUrl,
        generateWhatsAppProductUrl,
        generateGeneralWhatsAppUrl,

        isAdminAuthenticated,
        isAdminLoginOpen,
        setIsAdminLoginOpen,
        adminUser,
        loginAdminWithCredentials,
        loginAdmin,
        changeAdminPassword,
        logoutAdmin,

        adminSubTab,
        setAdminSubTab,
        isAddProductModalOpen,
        setIsAddProductModalOpen,

        toastMessage,
        showToast,

        isFirestoreQuotaExceeded,
        firestoreUpgradeUrl,
      }}
    >
      <ProductActionsContext.Provider value={productActionsValue}>
        {children}
      </ProductActionsContext.Provider>
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};

export const useProductActions = () => {
  const context = useContext(ProductActionsContext);
  if (!context) {
    throw new Error('useProductActions must be used within a StoreProvider');
  }
  return context;
};
