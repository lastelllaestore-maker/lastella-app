package com.lastella.jewelry

import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity()
