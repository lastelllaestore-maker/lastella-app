# Proguard rules for LASTELLA Mobile App
-keep public class * extends com.getcapacitor.Plugin
-keep class com.getcapacitor.** { *; }
-dontwarn com.getcapacitor.**

# Keep models and webview interfaces
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keepattributes *Annotation*
-keepattributes JavascriptInterface
-keepattributes EnclosingMethod
-keepattributes Signature
-keepattributes InnerClasses

# AndroidX Core & Splashscreen
-keep class androidx.core.splashscreen.** { *; }
-dontwarn androidx.core.splashscreen.**
