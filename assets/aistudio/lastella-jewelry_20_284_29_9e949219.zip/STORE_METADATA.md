# 🌟 LASTELLA Luxury Jewelry — App Store & Google Play Release Package

This document contains all production metadata, store listings, permissions declarations, asset specifications, and step-by-step release procedures for submitting the **LASTELLA** mobile application to the **Google Play Store** and **Apple App Store**.

---

## 📱 1. App Identifiers & Core Metadata

| Parameter | Android (Google Play) | iOS (Apple App Store) |
| :--- | :--- | :--- |
| **App Name** | LASTELLA | LASTELLA |
| **Full Title (AR)** | LASTELLA | مجوهرات لاستيلا الفاخرة | LASTELLA Luxury Jewelry Oman |
| **Package / Bundle Identifier** | `com.lastella.jewelry` | `com.lastella.jewelry` |
| **Version (Marketing)** | `1.0.0` | `1.0.0` |
| **Build Number / VersionCode** | `1` | `1` |
| **Target SDK / Deployment** | Android 16 (API Level 36) | iOS 14.0+ (Universal iPhone & iPad) |
| **Min SDK** | Android 7.0 (API Level 24) | iOS 14.0 |
| **Primary Category** | Shopping (تسوق) | Shopping (تسوق) |
| **Secondary Category** | Lifestyle (أسلوب حياة) | Lifestyle |
| **Content Rating** | PEGI 3 / Everyone (جميع الفئات) | 4+ |
| **Primary Market** | Sultanate of Oman (سلطنة عُمان) | Sultanate of Oman & GCC |
| **Supported Languages** | Arabic (العربية - Default), English | Arabic, English |
| **Default Currency** | OMR (ر.ع - Omani Rial) | OMR (ر.ع) |

---

## 🛍️ 2. Store Listings & Marketing Copy

### 🇦🇪 / 🇴🇲 Arabic Store Listing (Default)

#### **عنوان التطبيق (App Title - Max 30 chars)**:
`LASTELLA - مجوهرات لاستيلا عُمان`

#### **الوصف القصير (Short Description - Max 80 chars)**:
`تسوقي أرقى المجوهرات الفاخرة المطلية بالذهب عيار 18 المقاومة للماء في سلطنة عُمان`

#### **الوصف الكامل (Full Description - Max 4000 chars)**:
```text
مرحباً بكِ في بوتيك LASTELLA الرسمي — وجهتكِ الأولى لأرقى تشكيلات المجوهرات الفاخرة والعصرية في سلطنة عُمان.

نقدم لكِ بريقاً يدوم وأناقة لا تنتهي مع قطع مختارة بعناية، مطلية بالذهب عيار 18 ومصممة بأعلى معايير الجودة لتكون مقاومة للماء والبهتان ومناسبة لإطلالتكِ اليومية والمناسبات الخاصة.

✨ مميزات تجربة التسوق مع LASTELLA:
• تشكيلات حصرية ومتجددة: عقود وسلاسل، خواتم مرصعة، أساور راقية، حلقان أنيقة، وأطقم ملكية كاملة.
• جودة مضمونة وضمان ذهبي: جميع القطع مطلية بذهب عيار 18 ومقاومة للماء والصدأ مع ضمان شامل لمدة سنة.
• دليل قياس الخواتم التفاعلي: اختاري مقاسكِ الدقيق بكل ثقة وبسهولة تامة عبر هاتفكِ.
• توصيل سريع وموثوق: توصيل لباب منزلكِ في محافظة مسقط خلال 24-48 ساعة، ولبقية محافظات سلطنة عُمان (ظفار، الباطنة، الداخلية، الشرقية، الظاهرة، البريمي، مسندم، الوسطى) خلال 2-4 أيام عمل.
• شحن مجاني للطلبات المؤهلة فوق 15 ريال عُماني.
• خيارات دفع ودية وآمنة: الدفع عند الاستلام، التحويل البنكي الفوري، والدفع ببطاقات الخصم/الائتمان.
• طلب فوري وسلس عبر الواتساب: إتمام الطلب وتنسيق التوصيل مباشرة بضغطة زر واحدة مع فريق خدمة عملاء VIP.
• تتبع الطلبات المباشر: تابعي مراحل تجهيز طلبكِ وشحنه خطوة بخطوة.
• عروض وتخفيضات موسمية حصرية لمستخدمات التطبيق.

💎 لأنكِ تستحقين البريق الأبدي، حمّلي تطبيق LASTELLA الآن ودللي إطلالتكِ بلمسة من الفخامة!
```

---

### 🇬🇧 English Store Listing

#### **App Title (Max 30 chars)**:
`LASTELLA: Luxury Jewelry Oman`

#### **Short Description (Max 80 chars)**:
`Shop luxury 18K gold-plated waterproof fashion jewelry in the Sultanate of Oman.`

#### **Promotional Text (App Store - Max 170 chars)**:
`Discover eternal brilliance with LASTELLA. Premium 18K gold-plated, waterproof jewelry with 1-year warranty and fast delivery across Oman.`

#### **Full Description (Max 4000 chars)**:
```text
Welcome to the official LASTELLA Luxury Jewelry mobile boutique — Oman's premier destination for exquisite, high-fashion jewelry pieces.

Crafted with premium materials and triple-plated in radiant 18K gold, our collection is 100% waterproof, tarnish-resistant, and hypoallergenic — made to shine with you every single day.

✨ WHY YOU WILL LOVE LASTELLA:
• Curated Luxury Catalog: Explore trending necklaces, sparkling crystal rings, delicate bracelets, statement earrings, and full royal gift sets.
• Guaranteed Quality: Premium 18K gold plating with an official 1-Year color and tarnish-free warranty.
• Interactive Ring Size Guide: Find your exact international ring size directly on your phone with zero guesswork.
• Fast Oman-Wide Delivery: 24-48 hour delivery in Muscat Governorate, and 2-4 business days across all 11 Oman governorates (Dhofar, Al Batinah, Al Dakhiliyah, Al Sharqiyah, Al Dhahirah, Al Buraimi, Musandam, Al Wusta).
• Free Delivery on qualifying orders over 15 OMR.
• Flexible & Safe Checkout: Cash on Delivery (COD), Instant Bank Transfer, and Credit/Debit Cards.
• 1-Click WhatsApp Concierge: Instant checkout and dedicated VIP styling support via WhatsApp.
• Live Order Tracking: Real-time progress updates from order placement to doorstep delivery.
• Exclusive App Perks: Seasonal flash deals, gift packaging options, and curated lookbooks.

Download the LASTELLA app today and elevate your everyday elegance!
```

#### **Keywords (App Store - Max 100 chars comma-separated)**:
`jewelry,oman,gold,rings,necklaces,bracelets,earrings,shopping,boutique,muscat,fashion,accessories`

---

## 🎨 3. Store Visual Asset Specifications

| Asset | Dimensions / Requirements | Format |
| :--- | :--- | :--- |
| **App Icon (Google Play & App Store)** | `1024 x 1024 px` (No alpha/transparency on iOS, square, 72/300 DPI) | PNG / Vector SVG provided in `/public/icon.svg` |
| **Google Play Feature Graphic** | `1024 x 500 px` (Centered logo, soft pink & gold branding) | PNG / JPEG |
| **iOS iPhone Screenshots (6.7" Display)** | `1290 x 2796 px` or `1284 x 2778 px` (iPhone 16 Pro Max / 15 Pro Max) | PNG |
| **iOS iPhone Screenshots (6.5" Display)** | `1242 x 2688 px` (iPhone 11 Pro Max / XS Max) | PNG |
| **iOS iPad Screenshots (12.9" Display)** | `2048 x 2732 px` (iPad Pro 6th Gen) | PNG |
| **Android Phone Screenshots** | Minimum `1080 x 1920 px` or `1080 x 2400 px` (16:9 or 20:9 ratio) | PNG / JPEG |

---

## 🛡️ 4. Privacy, Security & Compliance Declarations

### URLs for Store Submission:
- **Privacy Policy URL**: `https://lastella.om/privacy-policy.html` (also available in-app)
- **Terms of Service URL**: `https://lastella.om/terms.html`
- **Support / Contact Email**: `lastelllaestore@gmail.com`
- **Support WhatsApp**: `+968 9488 2311`

### Data Safety & Privacy Manifest:
- **Data Collected**:
  - Name, Phone Number, Physical Delivery Address (Used solely for App Functionality & Order Delivery).
- **Data Sharing**:
  - No personal data sold or shared with advertising data brokers.
  - Delivery details shared only with Oman courier logistics partners.
- **Apple Privacy Manifest**: Configured in `ios/App/App/PrivacyInfo.xcprivacy` with `NSPrivacyTracking = false`.
- **Encryption Declaration**: `ITSAppUsesNonExemptEncryption = false` (Standard HTTPS encryption only).

---

## 🚀 5. How to Build & Generate Release Packages

### 🤖 Android (Generating Production `.aab` for Google Play Console):

1. **Build web assets & sync to Android project**:
   ```bash
   npm run cap:sync
   ```

2. **Generate a Production Keystore (One-time setup)**:
   ```bash
   keytool -genkey -v -keystore lastella-release-key.jks -alias lastella-key -keyalg RSA -keysize 2048 -validity 10000
   ```

3. **Build Release Android App Bundle (.aab)**:
   ```bash
   cd android
   ./gradlew bundleRelease
   ```
   *Output file location:* `android/app/build/outputs/bundle/release/app-release.aab`

4. **Upload to Google Play Console**:
   - Go to Google Play Console → Select App **LASTELLA** → **Production** (or Internal Testing) → **Create new release** → Upload `app-release.aab`.

---

### 🍏 iOS (Building for TestFlight & App Store Connect):

1. **Build web assets & sync to iOS project**:
   ```bash
   npm run cap:sync
   ```

2. **Open the project in Xcode (on macOS)**:
   ```bash
   npx cap open ios
   ```

3. **Configure Code Signing**:
   - In Xcode, select the **App** target → **Signing & Capabilities**.
   - Select your **Apple Developer Team**.
   - Bundle Identifier is preset to: `com.lastella.jewelry`.

4. **Archive & Distribute**:
   - Select **Any iOS Device (arm64)** as the target.
   - Go to **Product** → **Archive**.
   - Once archived, click **Distribute App** → **App Store Connect** → **Upload**.
   - Open **App Store Connect** → Submit for Review / TestFlight.
