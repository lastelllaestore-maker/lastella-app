#!/usr/bin/env bash
set -e

echo "=============================================================================="
echo "      LASTELLA JEWELRY - AUTOMATED ANDROID APK BUILD SCRIPT (BASH)"
echo "=============================================================================="
echo ""
echo "[*] Step 1/5: Cleaning stale web build and assets..."
rm -rf dist
rm -rf android/app/src/main/assets/public/*

echo "[*] Step 2/5: Compiling latest source code with Vite (npm run build)..."
npm run build

if [ ! -f "dist/index.html" ]; then
    echo "[!] ERROR: dist/index.html not found after build!"
    exit 1
fi
echo "    [OK] Latest preview source compiled successfully to dist/"

echo ""
echo "[*] Step 3/5: Syncing latest build into Capacitor Android project..."
npx cap sync android
echo "    [OK] Capacitor synchronized latest dist assets into android/app/src/main/assets/public"

echo ""
echo "[*] Step 4/5: Building Android APK with Gradle..."
(cd android && ./gradlew assembleDebug)

echo ""
echo "[*] Step 5/5: Verifying generated APK..."
mkdir -p apk
SOURCE_APK="android/app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$SOURCE_APK" ]; then
    cp "$SOURCE_APK" "apk/LASTELLA-latest.apk"
    cp "$SOURCE_APK" "LASTELLA-latest.apk"
    echo "=============================================================================="
    echo "[SUCCESS] Android APK built successfully from the latest preview code!"
    echo "=============================================================================="
    echo "Primary APK Location: $(pwd)/LASTELLA-latest.apk"
    echo "Archive APK Location: $(pwd)/apk/LASTELLA-latest.apk"
    echo "Gradle Path:          $(pwd)/$SOURCE_APK"
    echo "=============================================================================="
else
    echo "[!] Notice: Gradle step finished. Check $SOURCE_APK"
fi
