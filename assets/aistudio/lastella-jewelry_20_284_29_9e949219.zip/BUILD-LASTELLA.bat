@echo off
setlocal enabledelayedexpansion

echo ==============================================================================
echo       LASTELLA JEWELRY - AUTOMATED ANDROID APK BUILD SCRIPT
echo ==============================================================================
echo.
echo [*] Step 1/5: Cleaning stale web build and assets...
if exist "dist" (
    echo     - Removing old dist folder...
    rmdir /s /q "dist"
)
if exist "android\app\src\main\assets\public" (
    echo     - Removing old Android web assets...
    rmdir /s /q "android\app\src\main\assets\public"
)

echo.
echo [*] Step 2/5: Compiling latest source code with Vite (npm run build)...
call npm run build
if %ERRORLEVEL% NEQ 0 (
    echo [!] ERROR: "npm run build" failed!
    echo     Please check for TypeScript or bundling errors above.
    pause
    exit /b %ERRORLEVEL%
)

if not exist "dist\index.html" (
    echo [!] ERROR: dist\index.html not found after build!
    pause
    exit /b 1
)
echo     [OK] Latest preview source compiled successfully to dist/

echo.
echo [*] Step 3/5: Syncing latest build into Capacitor Android project...
call npx cap sync android
if %ERRORLEVEL% NEQ 0 (
    echo [!] ERROR: "npx cap sync android" failed!
    pause
    exit /b %ERRORLEVEL%
)
echo     [OK] Capacitor synchronized latest dist assets into android/app/src/main/assets/public

echo.
echo [*] Step 4/5: Building Android APK with Gradle...
cd android
if not exist "gradlew.bat" (
    echo [!] ERROR: gradlew.bat not found in android directory!
    cd ..
    pause
    exit /b 1
)

call gradlew.bat assembleDebug
set GRADLE_STATUS=%ERRORLEVEL%
cd ..

if %GRADLE_STATUS% NEQ 0 (
    echo.
    echo [!] Gradle APK build failed (error code %GRADLE_STATUS%).
    echo     Note: Ensure that JDK 17+ and the Android SDK are installed,
    echo     or open the "android" folder in Android Studio and run Build APK.
    pause
    exit /b %GRADLE_STATUS%
)

echo.
echo [*] Step 5/5: Verifying generated APK and copying to root...
if not exist "apk" mkdir "apk"

set "SOURCE_APK=android\app\build\outputs\apk\debug\app-debug.apk"
set "DEST_APK=apk\LASTELLA-latest.apk"
set "ROOT_APK=LASTELLA-latest.apk"

if exist "%SOURCE_APK%" (
    copy /y "%SOURCE_APK%" "%DEST_APK%" >nul
    copy /y "%SOURCE_APK%" "%ROOT_APK%" >nul
    echo.
    echo ==============================================================================
    echo [SUCCESS] Android APK built successfully from the latest preview code!
    echo ==============================================================================
    echo.
    echo Primary APK Location:
    echo   %CD%\%ROOT_APK%
    echo.
    echo Backup Archive Location:
    echo   %CD%\%DEST_APK%
    echo.
    echo Gradle Output Location:
    echo   %CD%\%SOURCE_APK%
    echo.
    echo You can now install this APK directly onto your Android device or share it!
    echo ==============================================================================
) else (
    echo [!] WARNING: Build command finished, but %SOURCE_APK% was not found.
)

pause
