# 📱 LASTELLA Jewelry — Android APK & AAB Generation Guide | دليل إنشاء تطبيق الأندرويد

This guide provides 4 different methods to generate an **APK** (for direct phone installation) and **AAB** (for Google Play Store) for your **LASTELLA Luxury Jewelry** app.

---

## 🌟 Method 1: Android Studio (Official & Most Recommended)
*Best if you have a PC or Mac and want to test on your phone or publish to Google Play.*

### Step 1: Download / Export the Project
1. In the **Google AI Studio** top toolbar, click the menu (`...` or Settings icon).
2. Click **"Export to ZIP"** (or **"Export to GitHub"**).
3. Extract the downloaded ZIP file to a folder on your computer.

### Step 2: Open in Android Studio
1. Download and install [Android Studio](https://developer.android.com/studio) (free).
2. Open Android Studio and click **Open**.
3. Select the **`android`** folder inside the extracted project (e.g. `lastella-app/android`).
4. Wait 1–2 minutes for Android Studio to sync Gradle and download SDK components.

### Step 3: Generate the APK File
1. In the top menu bar, click:
   ```text
   Build  ➡️  Build Bundle(s) / APK(s)  ➡️  Build APK(s)
   ```
2. When the build finishes (usually ~30–60 seconds), a notification will pop up in the bottom-right corner:
   > *"APK(s) generated successfully for 1 module"*
3. Click the blue **"locate"** link in that pop-up to open the folder containing your APK!
   - The file will be named **`app-debug.apk`** located at:
     ```text
     android/app/build/outputs/apk/debug/app-debug.apk
     ```

### Step 4: Install on Your Phone
- Send `app-debug.apk` to your Android phone via WhatsApp, Telegram, Google Drive, or USB.
- Tap the file on your phone and tap **Install** (if prompted, allow "Install from unknown sources").
- Done! The LASTELLA app will be installed on your phone with the luxury branding, splash screen, and bottom navigation.

### Step 5: (Optional) Google Play Store Release (`.aab`)
1. Click **Build ➡️ Generate Signed Bundle / APK...**
2. Choose **Android App Bundle** (`.aab`).
3. Choose or create your keystore signing key.
4. Click **Release** ➡️ **Create**.
5. Upload the resulting `.aab` file to the [Google Play Console](https://play.google.com/console).

---

## ⚡ Method 2: Free Cloud Build via GitHub Actions (No Local Setup Required)
*No need to install Android Studio or Java! GitHub builds the APK for you in the cloud.*

1. Export the project to a **GitHub repository** (or push this repository to GitHub).
2. Go to your repository on [GitHub.com](https://github.com).
3. Click on the **"Actions"** tab at the top.
4. You will see the **"Build LASTELLA Android APK"** workflow running automatically.
5. Once it completes with a green checkmark (takes ~2 minutes), click on the workflow run.
6. Scroll down to the **Artifacts** section at the bottom.
7. Click **`lastella-jewelry-debug-apk`** to download your ready-to-install APK file directly to your computer or phone!

---

## 🌐 Method 3: Instant 1-Minute APK via PWABuilder (Easiest / 0 Tools)
*Built by Microsoft, 100% free, generates a production APK in under 2 minutes directly from the web.*

1. Copy your published store URL:
   ```text
   https://ais-pre-dgc4b3mcbcqnzd55adfeaa-508800288768.europe-west3.run.app
   ```
   *(or your custom domain if configured)*
2. Visit **[PWABuilder.com](https://www.pwabuilder.com)**.
3. Paste the URL and click **Start**.
4. Click **Package For Stores** ➡️ Select **Android**.
5. Click **Generate** and choose:
   - **Download APK** (for direct phone install), or
   - **Download Android App Bundle** (for Google Play Store).
6. Download and install immediately.

---

## 💻 Method 4: Command Line Build (Terminal)
*If you already have Node.js, Java JDK 17/21, and Android SDK installed on your system:*

```bash
# 1. Build the web app and sync with Capacitor
npm run build
npx cap sync android

# 2. Enter android directory
cd android

# 3. Build APK
# On macOS / Linux:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```

The APK file will be available at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🇸🇦 دليل مبسط باللغة العربية (خطوات إنشاء ملف APK)

### الطريقة الأولى: عبر برنامج Android Studio (الأفضل والأشمل)
1. **تنزيل المشروع**: من القائمة العلوية في Google AI Studio، اضغط على النقاط الثلاث واختر **"Export to ZIP"**.
2. **فك الضغط**: افتح المجلد واذهب إلى برنامج **Android Studio** (مجاني).
3. **فتح المشروع**: اختر **Open** ثم حدد مجلد **`android`** داخل المشروع.
4. **إنشاء الـ APK**: من القائمة العلوية اضغط:
   `Build` ➡️ `Build Bundle(s) / APK(s)` ➡️ `Build APK(s)`
5. بعد ثوانٍ ستظهر رسالة بالأسفل فيها كلمة **`locate`**، اضغط عليها وسيفتح لك مجلد الملف:
   `app-debug.apk`
6. أرسل الملف لهاتفك عبر واتساب أو درايف وثبّته مباشرة.

### الطريقة الثانية: عبر موقع PWABuilder (الأسرع خلال دقيقة واحدة وبدون أي برامج)
1. انسخ رابط المتجر المنشور.
2. ادخل موقع **[PWABuilder.com](https://www.pwabuilder.com)**.
3. ضع الرابط واضغط **Start**.
4. اختر **Package for Stores** ثم **Android**.
5. اضغط **Generate** وحمّل ملف الـ APK أو حزمة Google Play جاهزة للتثبيت فوراً.
